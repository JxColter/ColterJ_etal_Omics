#!/usr/bin/env python3
"""Agitation and oxygen focused plotting workflow v1.2.

Standalone plotting script using completed analysis/1_4_1/primary_collapsed outputs.
Generates 300 DPI PNG files only under agitation_oxygen_1_2/.

V1.2 changes
- Restores an independent focused pooled 150 vs 100 RPM comparison.
- Retains independent focused 150 vs 120 and 120 vs 100 RPM plots.
- Restricts the 150 vs 100 pooled/D2/D4 heatmap and paired plot to genes most
  relevant to pluripotent phenotype, developmental competence, chromatin state,
  and future differentiation response.
- Uses pooled, normoxic D2, and normoxic D4 agitation contrasts.
- Expands figure margins so axis labels are not clipped.
- Retains the oxygen pooled/D2/D4 heatmap.
"""
from __future__ import annotations
import argparse,json,warnings
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
from matplotlib.lines import Line2D
warnings.filterwarnings("ignore",category=RuntimeWarning)

BASE=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
ROOT=BASE/"analysis"/"1_4_1"/"primary_collapsed"
DPI=300;FDR=.05;FC=.2;LARGE=float(np.log2(1.5))
UP="#B2182B";DOWN="#2166AC";GREY="#8A8A8A";POOLED="#6A3D9A";D2="#4DAF4A";D4="#E6AB02"

# Agitation-responsive genes selected for direct relevance to pluripotent state,
# developmental competence, chromatin/transcriptional regulation, and lineage bias.
PLURIPOTENT_PHENOTYPE_GENES=[
 "HMGA1","NODAL","ALPP","ALPG",
 "EMX1","SOX12","KLF7","SNAI3","CUX1",
 "FOXO3","BCL2L1","BBC3","TP53I3",
 "MRNIP","ALKBH2"
]
OXYGEN_GENES=["PDK1","COX11","LPCAT3","SRR","FZD2","GRM5","PKDCC","KLF7","CLIC5","JAKMIP2","PXN","SLC4A5","EDIL3","CTSB","TCP1","PDCD4","HEXIM1","HEXIM2","PDE4C","HIF1A-AS2","NETO1-DT","AATBC"]

def args():
 p=argparse.ArgumentParser();p.add_argument("--input",type=Path,default=ROOT);p.add_argument("--output",type=Path);p.add_argument("--top-focused",type=int,default=20);return p.parse_args()
def style():
 mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":28,"axes.titlesize":38,"axes.titleweight":"bold","axes.labelsize":34,"axes.labelweight":"bold","xtick.labelsize":25,"ytick.labelsize":25,"axes.linewidth":2.8,"xtick.major.width":2.8,"ytick.major.width":2.8,"savefig.dpi":DPI});sns.set_style("ticks")
def save(fig,p):p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.45);plt.close(fig)
def load(root,name):
 p=root/"differential_expression"/name/"all_tested_genes.csv"
 if not p.exists():raise FileNotFoundError(p)
 d=pd.read_csv(p,dtype={"gene_id":str});d["gene_symbol"]=d.gene_symbol.fillna(d.gene_id).astype(str).str.upper();d["sig"]=d.adjusted_p_value.lt(FDR)&d.log2FC.abs().ge(FC);d["large"]=d.adjusted_p_value.lt(FDR)&d.log2FC.abs().ge(LARGE);return d.sort_values("adjusted_p_value").drop_duplicates("gene_symbol").set_index("gene_symbol")
def legend(out):
 fig,ax=plt.subplots(figsize=(12,2.8));ax.axis("off");ax.legend([Line2D([0],[0],marker="o",color="w",markerfacecolor=POOLED,markersize=16),Line2D([0],[0],marker="o",color="w",markerfacecolor=D2,markersize=16),Line2D([0],[0],marker="o",color="w",markerfacecolor=D4,markersize=16)],["Pooled","Day 2","Day 4"],loc="center",ncol=3,frameon=False,prop={"size":24,"weight":"bold"});save(fig,out/"legends"/"temporal")
 fig,ax=plt.subplots(figsize=(9,2.8));ax.axis("off");ax.legend([Line2D([0],[0],marker="o",color="w",markerfacecolor=UP,markersize=16),Line2D([0],[0],marker="o",color="w",markerfacecolor=DOWN,markersize=16)],["Higher in numerator","Lower in numerator"],loc="center",ncol=2,frameon=False,prop={"size":24,"weight":"bold"});save(fig,out/"legends"/"effect_direction")
def focused(root,out,contrast,title,n):
 d=load(root,contrast);z=d[d.sig].sort_values("adjusted_p_value").head(n).sort_values("log2FC");z.reset_index().to_csv(out/"source_data"/f"{contrast}_focused.csv",index=False)
 if z.empty:return
 fig,ax=plt.subplots(figsize=(15,max(9,.75*len(z)+5)));y=np.arange(len(z));ax.scatter(z.log2FC,y,s=np.where(z.large,170,110),c=np.where(z.log2FC>=0,UP,DOWN),alpha=.80,edgecolor="white",lw=1);ax.axvline(0,c="black",lw=2);ax.set_yticks(y);ax.set_yticklabels(z.index,fontsize=27,fontweight="bold");ax.set_xlabel("Log2 fold change",labelpad=28);ax.set_title(title,pad=30);ax.margins(x=.22);sns.despine(ax=ax);fig.subplots_adjust(left=.32,bottom=.22,right=.96,top=.88);save(fig,out/"focused_agitation"/contrast)
def merged(root,names,genes):
 rows=[]
 for label,name in names:
  d=load(root,name);q=d.reindex(genes)
  for gene in genes:
   if gene not in q.index:continue
   r=q.loc[gene];rows.append(dict(gene_symbol=gene,time=label,log2FC=r.log2FC,adjusted_p_value=r.adjusted_p_value,moderate=bool(r.sig) if pd.notna(r.sig) else False))
 return pd.DataFrame(rows)
def temporal_heatmap(root,out,prefix,names,genes,title):
 t=merged(root,names,genes);t.to_csv(out/"source_data"/f"{prefix}_effects.csv",index=False);order=[x[0] for x in names];mat=t.pivot(index="gene_symbol",columns="time",values="log2FC").reindex(index=genes,columns=order).dropna(how="all");sig=t.pivot(index="gene_symbol",columns="time",values="moderate").reindex(index=mat.index,columns=mat.columns).fillna(False)
 fig,ax=plt.subplots(figsize=(12,max(9,.78*len(mat)+5)));lim=max(1,float(np.nanmax(abs(mat.values))));sns.heatmap(mat,cmap="vlag",center=0,vmin=-lim,vmax=lim,cbar=False,linewidths=.8,linecolor="white",ax=ax)
 for i,g in enumerate(mat.index):
  for j,c in enumerate(mat.columns):
   if sig.loc[g,c]:ax.text(j+.5,i+.5,"*",ha="center",va="center",fontsize=21,fontweight="bold")
 ax.set_title(title,pad=30);ax.set_xlabel("");ax.set_ylabel("");ax.tick_params(axis="x",rotation=0,labelsize=28);ax.tick_params(axis="y",rotation=0,labelsize=25);[q.set_fontweight("bold") for q in ax.get_xticklabels()+ax.get_yticklabels()];fig.subplots_adjust(left=.30,bottom=.16,right=.96,top=.89);save(fig,out/"temporal"/f"{prefix}_heatmap")
def temporal_paired(root,out,prefix,names,genes,title):
 t=merged(root,names,genes);order=[x[0] for x in names];p=t.pivot(index="gene_symbol",columns="time",values="log2FC").reindex(index=genes,columns=order).dropna(how="all");p=p.loc[p.abs().max(axis=1).sort_values().index];colors={"Pooled":POOLED,"Day 2":D2,"Day 4":D4};fig,ax=plt.subplots(figsize=(16,max(9,.72*len(p)+5)))
 for i,(g,r) in enumerate(p.iterrows()):
  vals=r.dropna();ax.plot(vals.values,[i]*len(vals),c=GREY,lw=3,alpha=.16)
  for lab,val in vals.items():ax.scatter(val,i,s=190,c=colors[lab],alpha=.68,edgecolor="white",lw=1,zorder=3)
 ax.axvline(0,c="black",lw=2);ax.set_yticks(range(len(p)));ax.set_yticklabels(p.index,fontsize=25,fontweight="bold");ax.set_xlabel("Log2 fold change",labelpad=26);ax.set_title(title,pad=30);ax.margins(x=.18);sns.despine(ax=ax);fig.subplots_adjust(left=.27,bottom=.18,right=.96,top=.88);save(fig,out/"temporal"/f"{prefix}_paired")
def main():
 a=args();out=a.output or a.input/"agitation_oxygen_1_2";out.mkdir(parents=True,exist_ok=True);(out/"source_data").mkdir(exist_ok=True);style()
 focused(a.input,out,"150_vs_100_RPM_pooled","150 versus 100 RPM",a.top_focused);focused(a.input,out,"150_vs_120_RPM_pooled","150 versus 120 RPM",a.top_focused);focused(a.input,out,"120_vs_100_RPM_pooled","120 versus 100 RPM",a.top_focused)
 ag=[("Pooled","150_vs_100_RPM_pooled"),("Day 2","Normoxia_150_vs_100_RPM_D2"),("Day 4","Normoxia_150_vs_100_RPM_D4")];ox=[("Pooled","Normoxia_vs_Hypoxia_pooled"),("Day 2","Normoxia_vs_Hypoxia_D2"),("Day 4","Normoxia_vs_Hypoxia_D4")]
 temporal_heatmap(a.input,out,"agitation_150_vs_100_pluripotent_phenotype",ag,PLURIPOTENT_PHENOTYPE_GENES,"150 versus 100 RPM: regulators of pluripotent phenotype and developmental competence");temporal_paired(a.input,out,"agitation_150_vs_100_pluripotent_phenotype",ag,PLURIPOTENT_PHENOTYPE_GENES,"150 versus 100 RPM: pooled and temporal regulatory effects");temporal_heatmap(a.input,out,"oxygen",ox,OXYGEN_GENES,"Oxygen-response persistence and timing");legend(out)
 (out/"manifest.json").write_text(json.dumps({"version":"1.2","focused_agitation":["150 vs 100","150 vs 120","120 vs 100"],"150_vs_100_temporal_gene_selection":"pluripotent phenotype, developmental competence, chromatin/genome maintenance, and survival-state regulators","D2_D4_scope":"normoxia-stratified agitation contrasts","output":"300 DPI PNG only"},indent=2));print(f"Agitation/oxygen v1.2 complete: {out}")
if __name__=="__main__":main()
