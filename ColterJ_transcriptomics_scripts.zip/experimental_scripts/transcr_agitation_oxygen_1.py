#!/usr/bin/env python3
"""Focused agitation and oxygen publication workflow v1.

Reads completed transcriptomics analysis 1.4.1 primary-collapsed outputs.
No differential-expression statistics are recomputed. Generates 300 DPI PNG
files only under <primary_collapsed>/agitation_oxygen_1/.

Agitation analyses
- Primary pooled 150 vs 100 RPM module heatmaps and horizontal condition bars.
- Focused pooled 150 vs 120 RPM response.
- Pooled 120 vs 100 RPM response.
- Pooled/D2/D4 DEG-count summary for all agitation-rate contrasts.
- Coupled, upregulated, and downregulated ORA for 150 vs 100 RPM.

Oxygen analyses
- Pooled Normoxia vs Hypoxia module heatmaps and horizontal condition bars.
- Pooled, D2, and D4 effect comparison for selected genes.
- Pooled/D2/D4 DEG-count summary.
- Coupled, upregulated, and downregulated ORA for pooled oxygen effects.

Condition-expression bars show biological-sample mean log2 CPM +/- SD. Asterisks
use adjusted P values from the corresponding completed DESeq2 contrast.
"""
from __future__ import annotations
import argparse,json,re,warnings
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from scipy.stats import hypergeom
from statsmodels.stats.multitest import multipletests
warnings.filterwarnings("ignore",category=RuntimeWarning)

BASE=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
ROOT=BASE/"analysis"/"1_4_1"/"primary_collapsed"
DPI=300;FDR=.05;FC=.2;LARGE=float(np.log2(1.5))
LIGHT="#E6E6E6";LIGHT_EDGE="#A6A6A6";CHARCOAL="#3A3A3A";DARK_EDGE="#202020"
UP="#B2182B";DOWN="#2166AC";GREY="#8A8A8A"
POOLED="#6A3D9A";DAY2="#4DAF4A";DAY4="#984EA3"

AGITATION_MODULES={
 "Adhesion and architecture":["CDH2","PKP3","AJM1","LLGL1","TUBA1A","TUBA4B","ACTN1","ZYX","ARHGEF19","ARHGAP39","GMIP","PLEKHG5"],
 "Growth-factor signaling":["ERBB3","PDGFA","AXL","SRC","MAPK7","IRS2","EPHA1","GRB7","PRKCZ"],
 "Survival and checkpoints":["BCL2L1","FOXO3","BCL6","FAS","BBC3","TP53I3","ING1"],
 "Metabolic allocation":["GYS1","HMGCR","FDFT1","SIRT4","PANK1","PYCR1","NDUFAF3","SLC25A44","GPAT2","HSD17B12","PSAT1"],
 "Genome maintenance":["ERCC1","MRNIP","RAD1","RAD54L","TONSL","MUTYH","WEE1","CDC25C","CDC34","CCNG1"],
 "Developmental regulation":["EMX1","SOX12","KLF7","SNAI3","HMGA1","CUX1","HMX2","NHLH2","MSC","DEAF1","NODAL","ALPP","ALPG"]}
OXYGEN_MODULES={
 "Metabolic adaptation":["PDK1","COX11","LPCAT3","SRR"],
 "Developmental signaling":["FZD2","GRM5","PKDCC","KLF7"],
 "Membrane and adhesion":["CLIC5","JAKMIP2","PXN","SLC4A5","EDIL3"],
 "Protein turnover":["CTSB","TCP1","PDCD4"],
 "Transcriptional control":["HEXIM1","HEXIM2","PDE4C","HIF1A-AS2","NETO1-DT","AATBC"]}
OXYGEN_TEMP=list(dict.fromkeys(g for x in OXYGEN_MODULES.values() for g in x))

def args():
 p=argparse.ArgumentParser();p.add_argument("--input",type=Path,default=ROOT);p.add_argument("--output",type=Path);p.add_argument("--ora-library",default="GO_Biological_Process_2023");p.add_argument("--ora-top-significant",type=int,default=12);p.add_argument("--ora-nonsignificant",type=int,default=4);return p.parse_args()
def style():
 mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":28,"axes.titlesize":38,"axes.titleweight":"bold","axes.labelsize":34,"axes.labelweight":"bold","xtick.labelsize":25,"ytick.labelsize":25,"legend.fontsize":24,"axes.linewidth":2.8,"xtick.major.width":2.8,"ytick.major.width":2.8,"savefig.dpi":DPI});sns.set_style("ticks")
def save(fig,p):p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.16);plt.close(fig)
def safe(x):return re.sub(r"[^A-Za-z0-9_]+","_",str(x)).strip("_")
def load_de(root,name):
 p=root/"differential_expression"/name/"all_tested_genes.csv"
 if not p.exists():raise FileNotFoundError(p)
 d=pd.read_csv(p,dtype={"gene_id":str});d["gene_symbol"]=d.gene_symbol.fillna(d.gene_id).astype(str).str.upper();d["sig"]=d.adjusted_p_value.lt(FDR)&d.log2FC.abs().ge(FC);d["large"]=d.adjusted_p_value.lt(FDR)&d.log2FC.abs().ge(LARGE);d["direction"]=np.where(d.log2FC>=0,"Up","Down");return d.sort_values("adjusted_p_value").drop_duplicates("gene_symbol")
def parse_sample(x):
 raw=str(x);core=re.sub(r"_S\d+_L\d{3}_\d+(?:\.tabular)?$","",raw,flags=re.I);core=re.sub(r"_dup$","",core,flags=re.I).lower()
 if re.fullmatch(r"c\d+",core):return dict(sample_id=raw,stage="Initial",oxygen="Initial",rpm="Initial",day=0,replicate=int(re.search(r"\d+",core).group()))
 m=re.fullmatch(r"([hn])(100|120|150)d(2|4)s(\d+)",core,re.I)
 if not m:raise ValueError(f"Cannot parse count-column sample: {raw}")
 o,r,d,n=m.groups();return dict(sample_id=raw,stage="Dynamic",oxygen={"n":"Normoxia","h":"Hypoxia"}[o.lower()],rpm=str(r),day=int(d),replicate=int(n))
def expression(root):
 c=pd.read_csv(root/"counts"/"filtered_counts.csv",index_col=0);c.index=c.index.astype(str);c.columns=c.columns.astype(str);m=pd.DataFrame([parse_sample(x) for x in c.columns]);x=np.log2(c.div(c.sum(axis=0),axis=1)*1e6+1);return x,m
def stars(q):
 if not np.isfinite(q):return ""
 if q<.001:return "***"
 if q<.01:return "**"
 if q<.05:return "*"
 return ""
def legend(out,name,handles,labels,size=(12,3),cols=2):
 fig,ax=plt.subplots(figsize=size);ax.axis("off");ax.legend(handles,labels,loc="center",frameon=False,ncol=cols,prop={"size":24,"weight":"bold"});save(fig,out/"legends"/name)

def two_group_stats(x,m,de,genes,group_col,left,right):
 gm=de.drop_duplicates("gene_id").set_index("gene_symbol").gene_id.astype(str).to_dict();q=de.set_index("gene_symbol");L=m.loc[m[group_col].astype(str).eq(str(left)),"sample_id"].tolist();R=m.loc[m[group_col].astype(str).eq(str(right)),"sample_id"].tolist();rows=[]
 for gene in genes:
  gid=gm.get(gene)
  if gid not in x.index or gene not in q.index:continue
  v=x.loc[gid];r=q.loc[gene];rows.append(dict(gene_symbol=gene,left_mean=v[L].mean(),left_sd=v[L].std(ddof=1),right_mean=v[R].mean(),right_sd=v[R].std(ddof=1),log2FC=r.log2FC,adjusted_p_value=r.adjusted_p_value,significant=bool(r.sig)))
 return pd.DataFrame(rows)
def module_figures(root,out,family,contrast,modules,group_col,left,right,left_label,right_label):
 de=load_de(root,contrast);x,m=expression(root);m=m[m.stage.eq("Dynamic")].copy()
 all_rows=[]
 for module,genes in modules.items():
  t=two_group_stats(x,m,de,genes,group_col,left,right);t["module"]=module;all_rows.append(t)
  if t.empty:continue
  t.to_csv(out/"source_data"/f"{family}_{safe(module)}_summary.csv",index=False)
  mat=t.set_index("gene_symbol")[["left_mean","right_mean"]].rename(columns={"left_mean":left_label,"right_mean":right_label});z=mat.sub(mat.mean(axis=1),axis=0).div(mat.std(axis=1).replace(0,np.nan),axis=0);z.to_csv(out/"source_data"/f"{family}_{safe(module)}_heatmap.csv")
  fig,ax=plt.subplots(figsize=(11,max(8,.78*len(z)+4)),layout="constrained");sns.heatmap(z,cmap="vlag",center=0,vmin=-1,vmax=1,cbar=False,linewidths=.75,linecolor="white",ax=ax);ax.set_title(module,pad=24);ax.set_xlabel("");ax.set_ylabel("");ax.tick_params(axis="x",rotation=0,labelsize=27);ax.tick_params(axis="y",rotation=0,labelsize=24);[w.set_fontweight("bold") for w in ax.get_xticklabels()+ax.get_yticklabels()];save(fig,out/"heatmaps"/family/safe(module))
  tt=t.iloc[::-1].reset_index(drop=True);y=np.arange(len(tt));h=.34;fig,ax=plt.subplots(figsize=(17,max(9,.72*len(tt)+5)),layout="constrained");ax.barh(y-h/2,tt.left_mean,height=h,xerr=tt.left_sd,color=LIGHT,edgecolor=LIGHT_EDGE,linewidth=1.2,error_kw=dict(ecolor="black",lw=1.8,capsize=4));ax.barh(y+h/2,tt.right_mean,height=h,xerr=tt.right_sd,color=CHARCOAL,edgecolor=DARK_EDGE,linewidth=1.2,error_kw=dict(ecolor="black",lw=1.8,capsize=4));ax.set_yticks(y);ax.set_yticklabels(tt.gene_symbol,fontsize=24,fontweight="bold");ax.set_xlabel("Mean log2 CPM +/- SD");ax.set_title(module,pad=24);mx=np.nanmax(np.r_[tt.left_mean+tt.left_sd.fillna(0),tt.right_mean+tt.right_sd.fillna(0)]);ax.set_xlim(0,mx*1.18)
  for i,r in tt.iterrows():
   s=stars(r.adjusted_p_value)
   if s:ax.text(max(r.left_mean+(r.left_sd if np.isfinite(r.left_sd) else 0),r.right_mean+(r.right_sd if np.isfinite(r.right_sd) else 0))+mx*.018,i,s,va="center",fontsize=24,fontweight="bold")
  sns.despine(ax=ax);save(fig,out/"barplots"/family/safe(module))
 pd.concat(all_rows,ignore_index=True).to_csv(out/"source_data"/f"{family}_all_modules.csv",index=False)
 legend(out,f"{family}_conditions",[Patch(facecolor=LIGHT,edgecolor=LIGHT_EDGE),Patch(facecolor=CHARCOAL,edgecolor=DARK_EDGE)],[left_label,right_label])

def focused_effects(root,out,names,title,file_name):
 rows=[]
 for name in names:
  d=load_de(root,name);z=d[d.sig].copy();z["contrast"]=name.replace("_pooled","").replace("_"," ");rows.append(z)
 t=pd.concat(rows,ignore_index=True);t.to_csv(out/"source_data"/f"{file_name}.csv",index=False)
 if t.empty:return
 # Show at most 20 strongest genes per contrast for readability.
 show=t.sort_values(["contrast","adjusted_p_value"]).groupby("contrast").head(20).copy();show["label"]=show.contrast+" | "+show.gene_symbol;show=show.sort_values(["contrast","log2FC"]);fig,ax=plt.subplots(figsize=(16,max(10,.46*len(show)+4)),layout="constrained");y=np.arange(len(show));ax.scatter(show.log2FC,y,s=np.where(show.large,150,95),c=np.where(show.log2FC>=0,UP,DOWN),alpha=.75,edgecolor="white");ax.axvline(0,c="black",lw=1.8);ax.set_yticks(y);ax.set_yticklabels(show.label,fontsize=20,fontweight="bold");ax.set_xlabel("Log2 fold change");ax.set_title(title,pad=24);sns.despine(ax=ax);save(fig,out/"effects"/file_name)
def deg_counts(root,out):
 specs={"Agitation 150 vs 100":{"Pooled":["150_vs_100_RPM_pooled"],"D2":["Normoxia_150_vs_100_RPM_D2","Hypoxia_150_vs_100_RPM_D2"],"D4":["Normoxia_150_vs_100_RPM_D4","Hypoxia_150_vs_100_RPM_D4"]},"Agitation 150 vs 120":{"Pooled":["150_vs_120_RPM_pooled"],"D2":["Normoxia_150_vs_120_RPM_D2","Hypoxia_150_vs_120_RPM_D2"],"D4":["Normoxia_150_vs_120_RPM_D4","Hypoxia_150_vs_120_RPM_D4"]},"Agitation 120 vs 100":{"Pooled":["120_vs_100_RPM_pooled"],"D2":["Normoxia_120_vs_100_RPM_D2","Hypoxia_120_vs_100_RPM_D2"],"D4":["Normoxia_120_vs_100_RPM_D4","Hypoxia_120_vs_100_RPM_D4"]},"Normoxia vs Hypoxia":{"Pooled":["Normoxia_vs_Hypoxia_pooled"],"D2":["Normoxia_vs_Hypoxia_D2"],"D4":["Normoxia_vs_Hypoxia_D4"]}}
 rows=[]
 for family,levels in specs.items():
  for time,names in levels.items():
   vals=[]
   for n in names:vals.append(load_de(root,n).query("sig")[["gene_symbol","direction"]])
   z=pd.concat(vals);dr=z.groupby("gene_symbol").direction.agg(lambda q:q.iloc[0] if q.nunique()==1 else "Discordant");dr=dr[dr!="Discordant"];rows.append(dict(family=family,time=time,Up=int((dr=="Up").sum()),Down=int((dr=="Down").sum())))
 t=pd.DataFrame(rows);t.to_csv(out/"source_data"/"DEG_count_summary.csv",index=False)
 for family,z in t.groupby("family",sort=False):
  z=z.set_index("time").reindex(["Pooled","D2","D4"]).reset_index();fig,ax=plt.subplots(figsize=(11,10),layout="constrained");x=np.arange(3);ax.bar(x,z.Down,color=DOWN,width=.62);ax.bar(x,z.Up,bottom=z.Down,color=UP,width=.62);ax.set_xticks(x);ax.set_xticklabels(z.time,fontsize=30,fontweight="bold");ax.set_ylabel("Number of moderate DEGs");ax.set_title(family,pad=24);sns.despine(ax=ax);save(fig,out/"counts"/safe(family))
 legend(out,"DEG_direction",[Patch(facecolor=DOWN),Patch(facecolor=UP)],["Downregulated","Upregulated"])
def oxygen_temporal(root,out):
 datasets={"Pooled":load_de(root,"Normoxia_vs_Hypoxia_pooled").set_index("gene_symbol"),"Day 2":load_de(root,"Normoxia_vs_Hypoxia_D2").set_index("gene_symbol"),"Day 4":load_de(root,"Normoxia_vs_Hypoxia_D4").set_index("gene_symbol")};rows=[]
 for gene in OXYGEN_TEMP:
  row={"gene_symbol":gene}
  present=False
  for lab,d in datasets.items():
   if gene in d.index:row[f"{lab}_log2FC"]=d.loc[gene,"log2FC"];row[f"{lab}_FDR"]=d.loc[gene,"adjusted_p_value"];present=True
   else:row[f"{lab}_log2FC"]=np.nan;row[f"{lab}_FDR"]=np.nan
  if present:rows.append(row)
 t=pd.DataFrame(rows);t.to_csv(out/"source_data"/"oxygen_pooled_D2_D4_effects.csv",index=False);mat=t.set_index("gene_symbol")[["Pooled_log2FC","Day 2_log2FC","Day 4_log2FC"]].rename(columns={"Pooled_log2FC":"Pooled","Day 2_log2FC":"Day 2","Day 4_log2FC":"Day 4"});fig,ax=plt.subplots(figsize=(11,max(10,.62*len(mat)+4)),layout="constrained");lim=max(1,float(np.nanmax(abs(mat.values))));sns.heatmap(mat,cmap="vlag",center=0,vmin=-lim,vmax=lim,cbar=False,linewidths=.7,linecolor="white",ax=ax);ax.set_title("Oxygen-response persistence and timing",pad=24);ax.set_xlabel("");ax.set_ylabel("");ax.tick_params(axis="x",rotation=0,labelsize=27);ax.tick_params(axis="y",rotation=0,labelsize=22);[w.set_fontweight("bold") for w in ax.get_xticklabels()+ax.get_yticklabels()];save(fig,out/"oxygen_temporal"/"pooled_D2_D4_heatmap")
def get_sets(out,library):
 cache=out/"ora"/f"{safe(library)}.gmt";cache.parent.mkdir(parents=True,exist_ok=True)
 if cache.exists():
  s={}
  for line in cache.read_text(encoding="utf-8").splitlines():q=line.split("\t");s[q[0]]=set(map(str.upper,q[2:]))
  return s
 import gseapy as gp
 s=gp.get_library(name=library,organism="Human")
 with cache.open("w",encoding="utf-8") as h:
  for k,v in s.items():h.write("\t".join([k,"na"]+list(v))+"\n")
 return {k:set(map(str.upper,v)) for k,v in s.items()}
def ora_table(genes,bg,sets):
 rows=[];M=len(bg);N=len(genes)
 if not genes:return pd.DataFrame()
 for term,g0 in sets.items():
  gs=g0&bg;n=len(gs);ov=genes&gs;k=len(ov)
  if k<2 or n<10 or n>500:continue
  rows.append(dict(term=term,p_value=hypergeom.sf(k-1,M,n,N),overlap_count=k,set_size=n,input_size=N,enrichment_ratio=(k/N)/(n/M),genes=";".join(sorted(ov))))
 z=pd.DataFrame(rows)
 if z.empty:return z
 z["adjusted_p_value"]=multipletests(z.p_value,method="fdr_bh")[1];return z.sort_values(["adjusted_p_value","enrichment_ratio"],ascending=[True,False])
def fdr_color(q):
 if q>.05:return "#BDBDBD"
 score=np.clip((-np.log10(max(q,1e-12))-(-np.log10(.05)))/(6-(-np.log10(.05))),0,1);return mpl.colormaps["RdPu"](.25+.7*score)
def ora(root,out,library,family,contrast):
 d=load_de(root,contrast);bg=set(d.gene_symbol);sets=get_sets(out,library);analyses={"coupled":set(d.loc[d.sig,"gene_symbol"]),"upregulated":set(d.loc[d.sig&d.log2FC.gt(0),"gene_symbol"]),"downregulated":set(d.loc[d.sig&d.log2FC.lt(0),"gene_symbol"])}
 for typ,genes in analyses.items():
  z=ora_table(genes,bg,sets);z.to_csv(out/"source_data"/f"ORA_{family}_{typ}_all.csv",index=False)
  if z.empty:continue
  show=pd.concat([z[z.adjusted_p_value<.05].head(12),z[z.adjusted_p_value>=.05].head(4)]).sort_values("enrichment_ratio");show.to_csv(out/"source_data"/f"ORA_{family}_{typ}_displayed.csv",index=False);fig,ax=plt.subplots(figsize=(18,max(9,.72*len(show)+5)),layout="constrained");y=np.arange(len(show));ax.barh(y,show.enrichment_ratio,color=[fdr_color(q) for q in show.adjusted_p_value],edgecolor="white");ax.set_yticks(y);ax.set_yticklabels(show.term.str.replace("_"," ").str.slice(0,72),fontsize=21,fontweight="bold");ax.set_xlabel("Over-representation enrichment ratio");ax.set_title(f"{family}: {typ} ORA",pad=24);ax.axvline(1,c=GREY,ls="--");sns.despine(ax=ax);save(fig,out/"ora"/family/f"ora_{typ}")
def main():
 a=args();out=a.output or a.input/"agitation_oxygen_1";out.mkdir(parents=True,exist_ok=True);(out/"source_data").mkdir(exist_ok=True);style();module_figures(a.input,out,"agitation_150_vs_100","150_vs_100_RPM_pooled",AGITATION_MODULES,"rpm","100","150","100 RPM","150 RPM");module_figures(a.input,out,"oxygen_normoxia_vs_hypoxia","Normoxia_vs_Hypoxia_pooled",OXYGEN_MODULES,"oxygen","Hypoxia","Normoxia","Hypoxia","Normoxia");focused_effects(a.input,out,["150_vs_120_RPM_pooled","120_vs_100_RPM_pooled"],"Focused higher-agitation comparisons","focused_agitation_comparisons");deg_counts(a.input,out);oxygen_temporal(a.input,out);ora(a.input,out,a.ora_library,"agitation","150_vs_100_RPM_pooled");ora(a.input,out,a.ora_library,"oxygen","Normoxia_vs_Hypoxia_pooled");legend(out,"ORA_FDR",[Patch(facecolor="#BDBDBD"),Patch(facecolor=mpl.colormaps["RdPu"](.35)),Patch(facecolor=mpl.colormaps["RdPu"](.65)),Patch(facecolor=mpl.colormaps["RdPu"](.95))],["FDR > 0.05","FDR < 0.05","FDR < 0.01","FDR < 0.001"],size=(14,3),cols=4);(out/"manifest.json").write_text(json.dumps({"workflow":"transcr_agitation_oxygen_1","primary_agitation":"150 vs 100 RPM pooled","oxygen":"normoxia vs hypoxia pooled plus D2/D4","ORA":["coupled","upregulated","downregulated"],"output":"300 DPI PNG only"},indent=2));print(f"Agitation and oxygen figures complete: {out}")
if __name__=="__main__":main()
