#!/usr/bin/env python3
"""Dynamic-versus-initial temporal regulatory-state workflow v3.3.

Standalone Python workflow using completed primary-collapsed DESeq2 outputs.
Generates 300 DPI PNG files only under dynamic_vs_initial_3_3/.

The temporal analysis is restricted to transcriptional, chromatin, cohesin,
and regulatory-RNA features relevant to pluripotency or future differentiation.
It creates:
1. A combined D2/D4 regulatory-state plot stratified as reinforced, maintained,
   attenuated, direction-changed, or D4-emergent.
2. Separate plots for pluripotency/competence, developmental transcription,
   chromatin/remodeling, and genome organization.
3. A D4-emergent effect plot.
4. Complete source tables and separate legend PNGs.

No differential expression statistics are recomputed.
"""
from __future__ import annotations
import argparse,json,warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.lines import Line2D
import seaborn as sns
warnings.filterwarnings("ignore",category=RuntimeWarning)

BASE=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
ROOT=BASE/"analysis"/"1_4_1"/"primary_collapsed"
DPI=300;FDR=.05;FC=.2
D2_COLOR="#4DAF4A";D4_COLOR="#984EA3";ZERO="#222222"
CLASS_COLORS={"Reinforced":"#7B3294","Maintained":"#4D4D4D","Attenuated":"#008837","Direction changed":"#D95F02","D4-emergent":"#C51B7D"}

CONTEXTS={
 "Pluripotency and competence":["ZNF263","FOXD3-AS1","SCIRT"],
 "Developmental transcription":["ZNF224","FOXL2","SOX12","DEAF1","ATF5","SOX21","RUNX1","ZIC2","ZIC3"],
 "Chromatin and methylation regulation":["SPIN1","SOX21-AS1","PAXIP1-AS2","LARRPM","CHD7","CHD6","PRMT5","BAZ1A"],
 "Genome organization":["CTCF","STAG1","STAG3"]
}
# Genes selected a priori from attached D2/D4 moderate-DEG review.
SELECTED=list(dict.fromkeys(g for genes in CONTEXTS.values() for g in genes))

def args():
 p=argparse.ArgumentParser();p.add_argument("--input",type=Path,default=ROOT);p.add_argument("--output",type=Path);p.add_argument("--reinforcement-delta",type=float,default=.15);return p.parse_args()
def style():
 mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":28,"axes.titlesize":38,"axes.titleweight":"bold","axes.labelsize":34,"axes.labelweight":"bold","xtick.labelsize":25,"ytick.labelsize":25,"legend.fontsize":24,"axes.linewidth":2.7,"xtick.major.width":2.7,"ytick.major.width":2.7,"savefig.dpi":DPI});sns.set_style("ticks")
def save(fig,p):p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.16);plt.close(fig)
def load(root,name):
 p=root/"differential_expression"/name/"all_tested_genes.csv"
 if not p.exists():raise FileNotFoundError(p)
 d=pd.read_csv(p,dtype={"gene_id":str});d["gene_symbol"]=d.gene_symbol.fillna(d.gene_id).astype(str).str.upper();d["moderate"]=d.adjusted_p_value.lt(FDR)&d.log2FC.abs().ge(FC);return d.sort_values("adjusted_p_value").drop_duplicates("gene_symbol").set_index("gene_symbol")
def star(q):
 if not np.isfinite(q):return ""
 if q<.001:return "***"
 if q<.01:return "**"
 if q<.05:return "*"
 return ""
def classify(d2,d4,delta):
 s2=bool(d2.moderate);s4=bool(d4.moderate)
 if s4 and not s2:return "D4-emergent"
 if not (s2 and s4):return "Not retained"
 if np.sign(d2.log2FC)!=np.sign(d4.log2FC):return "Direction changed"
 change=abs(d4.log2FC)-abs(d2.log2FC)
 if change>=delta:return "Reinforced"
 if change<=-delta:return "Attenuated"
 return "Maintained"
def build_table(root,delta):
 d2=load(root,"Normoxia_150RPM_D2_vs_Initial");d4=load(root,"Normoxia_150RPM_D4_vs_Initial");rows=[]
 for context,genes in CONTEXTS.items():
  for gene in genes:
   if gene not in d2.index or gene not in d4.index:continue
   a,b=d2.loc[gene],d4.loc[gene];cls=classify(a,b,delta)
   if cls=="Not retained":continue
   rows.append(dict(context=context,gene_symbol=gene,D2_log2FC=a.log2FC,D4_log2FC=b.log2FC,D2_adjusted_p=a.adjusted_p_value,D4_adjusted_p=b.adjusted_p_value,D2_moderate=bool(a.moderate),D4_moderate=bool(b.moderate),absolute_effect_change=abs(b.log2FC)-abs(a.log2FC),classification=cls,D2_symbol=star(a.adjusted_p_value),D4_symbol=star(b.adjusted_p_value)))
 return pd.DataFrame(rows)
def legend(out):
 fig,ax=plt.subplots(figsize=(9,2.5));ax.axis("off");ax.legend([Line2D([0],[0],marker="o",color="w",markerfacecolor=D2_COLOR,alpha=.58,markersize=16),Line2D([0],[0],marker="o",color="w",markerfacecolor=D4_COLOR,alpha=.58,markersize=18)],["Day 2","Day 4"],loc="center",ncol=2,frameon=False,prop={"size":24,"weight":"bold"});save(fig,out/"legends"/"timepoint_legend")
 fig,ax=plt.subplots(figsize=(15,3));ax.axis("off");handles=[Line2D([0],[0],color=CLASS_COLORS[k],lw=5,alpha=.65) for k in CLASS_COLORS];ax.legend(handles,list(CLASS_COLORS),loc="center",ncol=3,frameon=False,prop={"size":22,"weight":"bold"});save(fig,out/"legends"/"classification_legend")
def paired_plot(t,title,p):
 if t.empty:return
 order={"Reinforced":0,"Maintained":1,"Attenuated":2,"Direction changed":3,"D4-emergent":4}
 z=t.assign(_order=t.classification.map(order)).sort_values(["_order","D4_log2FC"]).reset_index(drop=True);fig,ax=plt.subplots(figsize=(17,max(9,.72*len(z)+5)),layout="constrained")
 for i,r in z.iterrows():
  c=CLASS_COLORS[r.classification]
  if r.classification=="D4-emergent":
   ax.scatter(r.D4_log2FC,i,s=250,c=D4_COLOR,alpha=.58,edgecolor="white",lw=1.2,zorder=3)
   ax.text(r.D4_log2FC,i+.20,r.D4_symbol,ha="center",va="bottom",fontsize=18,fontweight="bold")
  else:
   ax.plot([r.D2_log2FC,r.D4_log2FC],[i,i],c=c,lw=4,alpha=.22)
   ax.scatter(r.D2_log2FC,i,s=190,c=D2_COLOR,alpha=.58,edgecolor="white",lw=1.1,zorder=3)
   ax.scatter(r.D4_log2FC,i,s=250,c=D4_COLOR,alpha=.58,edgecolor="white",lw=1.1,zorder=3)
  ax.text(r.D2_log2FC,i-.18,r.D2_symbol,ha="center",va="top",fontsize=17,fontweight="bold")
  ax.text(r.D4_log2FC,i+.18,r.D4_symbol,ha="center",va="bottom",fontsize=17,fontweight="bold")
 ax.axvline(0,c=ZERO,lw=2);ax.set_yticks(range(len(z)));ax.set_yticklabels(z.gene_symbol,fontsize=26,fontweight="bold");ax.set_xlabel("Log2 fold change relative to initial state");ax.set_title(title,pad=26);sns.despine(ax=ax);save(fig,p)
def emergent_plot(t,out):
 z=t[t.classification.eq("D4-emergent")].sort_values("D4_log2FC").reset_index(drop=True)
 if z.empty:return
 fig,ax=plt.subplots(figsize=(14,max(8,.75*len(z)+4)),layout="constrained");y=np.arange(len(z));colors=np.where(z.D4_log2FC>=0,"#5E3C99","#B35806");ax.barh(y,z.D4_log2FC,color=colors,alpha=.82,edgecolor="white");ax.axvline(0,c=ZERO,lw=2);ax.set_yticks(y);ax.set_yticklabels(z.gene_symbol,fontsize=25,fontweight="bold");ax.set_xlabel("Day 4 log2 fold change relative to initial state");ax.set_title("D4-emergent regulatory remodeling",pad=24)
 for i,r in z.iterrows():ax.text(r.D4_log2FC+(0.05 if r.D4_log2FC>=0 else -0.05),i,r.D4_symbol,ha="left" if r.D4_log2FC>=0 else "right",va="center",fontsize=21,fontweight="bold")
 sns.despine(ax=ax);save(fig,out/"temporal"/"D4_emergent_regulators")
def summary_heatmap(t,out):
 if t.empty:return
 z=t.set_index("gene_symbol")[["D2_log2FC","D4_log2FC"]].rename(columns={"D2_log2FC":"Day 2","D4_log2FC":"Day 4"});z.to_csv(out/"source_data"/"regulatory_state_log2FC_matrix.csv");fig,ax=plt.subplots(figsize=(10,max(10,.62*len(z)+4)),layout="constrained");lim=max(1,float(np.nanmax(abs(z.values))));sns.heatmap(z,cmap="vlag",center=0,vmin=-lim,vmax=lim,linewidths=.7,linecolor="white",cbar=False,ax=ax);ax.set_title("Temporal regulatory-state remodeling",pad=24);ax.set_xlabel("");ax.set_ylabel("");ax.tick_params(axis="x",rotation=0,labelsize=27);ax.tick_params(axis="y",rotation=0,labelsize=23);[q.set_fontweight("bold") for q in ax.get_xticklabels()+ax.get_yticklabels()];save(fig,out/"temporal"/"combined_regulatory_heatmap")
def main():
 a=args();out=a.output or a.input/"dynamic_vs_initial_3_3";out.mkdir(parents=True,exist_ok=True);(out/"source_data").mkdir(exist_ok=True);style();t=build_table(a.input,a.reinforcement_delta);t.to_csv(out/"source_data"/"temporal_regulatory_classification.csv",index=False);paired_plot(t,"Temporal remodeling of transcriptional and chromatin-regulatory state",out/"temporal"/"combined_regulatory_state");summary_heatmap(t,out);emergent_plot(t,out)
 for context in CONTEXTS:paired_plot(t[t.context.eq(context)],context,out/"temporal"/"contexts"/context.replace(" ","_").replace("/","_"))
 legend(out);(out/"manifest.json").write_text(json.dumps({"workflow":"dynamic_vs_initial_3_3","selection":"a priori regulatory genes from attached D2/D4 moderate DEG review","reinforcement_delta":a.reinforcement_delta,"classifications":["Reinforced","Maintained","Attenuated","Direction changed","D4-emergent"],"contexts":list(CONTEXTS),"output":"300 DPI PNG only"},indent=2));print(f"Dynamic temporal regulatory workflow complete: {out}")
if __name__=="__main__":main()
