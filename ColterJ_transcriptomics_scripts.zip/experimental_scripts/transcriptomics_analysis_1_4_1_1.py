#!/usr/bin/env python3
"""Bulk RNA-seq analysis v1.4.1.1, Python only, standalone and resume-aware.

Primary analysis collapses lanes and technical libraries within biological samples.
Exploratory analysis treats lanes as pseudoreplicates and is sensitivity-only.
Completed branches are skipped when their completion manifest is present, or when
all expected terminal outputs from v1.4.1 are detected.
"""
from __future__ import annotations
import argparse,gzip,inspect,json,re,sys,urllib.request,warnings
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
warnings.filterwarnings("ignore",category=RuntimeWarning)
VERSION="1_4_1_1";FDR=.05;MOD_FC=.2;LARGE_FC=float(np.log2(1.5));DPI=300
BASE=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
GENE_INFO_URL="https://ftp.ncbi.nlm.nih.gov/gene/DATA/GENE_INFO/Mammalia/Homo_sapiens.gene_info.gz"

def args():
 p=argparse.ArgumentParser();p.add_argument("--base",type=Path,default=BASE);p.add_argument("--min-count",type=int,default=10);p.add_argument("--min-samples",type=int,default=3);p.add_argument("--fdr",type=float,default=FDR);p.add_argument("--log2fc",type=float,default=MOD_FC);p.add_argument("--top-labels",type=int,default=12);p.add_argument("--gsea-permutations",type=int,default=1000);p.add_argument("--no-gsea",action="store_true");p.add_argument("--force",action="store_true");p.add_argument("--force-primary",action="store_true");p.add_argument("--force-exploratory",action="store_true");return p.parse_args()
def style():
 mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":12,"axes.titlesize":15,"axes.titleweight":"bold","axes.labelsize":13,"axes.labelweight":"bold","xtick.labelsize":10,"ytick.labelsize":10,"legend.fontsize":10,"axes.linewidth":1.2,"savefig.dpi":DPI,"savefig.bbox":"tight"});sns.set_style("ticks")
def save(fig,p):p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.15);plt.close(fig)
def safe(x):return re.sub(r"[^A-Za-z0-9_]+","_",str(x)).strip("_")
def parse_file(p):
 s=p.stem;lm=re.search(r"_(L\d{3})_",s,re.I);lane=lm.group(1).upper() if lm else "unknown";lib=re.sub(r"_S\d+_L\d{3}_\d+$","",s,flags=re.I);dup=bool(re.search(r"_dup$",lib,re.I));bio=re.sub(r"_dup$","",lib,flags=re.I).lower();unit=f"{lib}_{lane}".lower()
 if re.fullmatch(r"c\d+",bio):return dict(file_name=p.name,unit_id=unit,library_id=lib.lower(),biological_id=bio,lane=lane,technical_duplicate=dup,stage="Initial",oxygen="Initial",rpm="Initial",day=0,replicate=int(re.search(r"\d+",bio).group()),subject=bio,condition="Initial")
 m=re.fullmatch(r"([hn])(100|120|150)d(2|4)s(\d+)",bio,re.I)
 if not m:raise ValueError(f"Unrecognized count filename: {p.name}")
 o,r,d,rep=m.groups();oxy={"h":"Hypoxia","n":"Normoxia"}[o.lower()];return dict(file_name=p.name,unit_id=unit,library_id=lib.lower(),biological_id=bio,lane=lane,technical_duplicate=dup,stage="Dynamic",oxygen=oxy,rpm=str(r),day=int(d),replicate=int(rep),subject=f"{o.lower()}{r}s{rep}",condition=f"{oxy}_{r}RPM_D{d}")
def read_count(p):
 d=pd.read_csv(p,sep="\t",comment="#",low_memory=False);d.columns=d.columns.astype(str).str.strip();gc=next((x for x in ["Geneid","gene_id","Gene ID","gene","Gene"] if x in d.columns),d.columns[0]);nums=[]
 for c in d.columns:
  if c!=gc:
   d[c]=pd.to_numeric(d[c],errors="coerce")
   if d[c].notna().any():nums.append(c)
 if not nums:raise ValueError(f"No numeric count column in {p.name}")
 x=d[[gc,nums[-1]]].copy();x.columns=["gene_id","count"];x.gene_id=x.gene_id.astype(str).str.replace(r"\.\d+$","",regex=True);x["count"]=x["count"].fillna(0);return x[~x.gene_id.str.startswith("__")].groupby("gene_id").sum().iloc[:,0]
def load_raw(folder):
 fs=sorted(folder.glob("*.tabular"));
 if not fs:raise FileNotFoundError(f"No .tabular files in {folder}")
 m=pd.DataFrame([parse_file(p) for p in fs]);r=pd.DataFrame({p.name:read_count(p) for p in fs}).fillna(0).round().astype(int);return r,m

def matrix(raw,meta,mode):
 if mode=="primary_collapsed":
  c=pd.DataFrame({b:raw[meta.loc[meta.biological_id.eq(b),"file_name"]].sum(axis=1) for b in meta.biological_id.drop_duplicates()});m=meta.sort_values(["biological_id","library_id","lane"]).drop_duplicates("biological_id").set_index("biological_id").reindex(c.columns).copy();m.index.name="sample_id";m=m.reset_index();m["biological_id"]=m.sample_id;m["analysis_unit"]="biological_sample"
 else:
  lookup=meta.set_index("file_name");c=raw.copy();c.columns=[lookup.loc[x,"unit_id"] for x in raw.columns];m=meta.copy();m["sample_id"]=m["unit_id"].astype(str);m=m.drop_duplicates("sample_id").set_index("sample_id",drop=True).reindex(c.columns);m.index.name="sample_id";m=m.reset_index();m["analysis_unit"]="sequencing_lane_pseudoreplicate"
 if "sample_id" not in m.columns: m=m.rename(columns={m.columns[0]:"sample_id"})
 m["sample_id"]=m.sample_id.astype(str)
 if m.sample_id.isna().any() or m.sample_id.duplicated().any():raise ValueError(f"Invalid sample_id metadata in {mode}")
 missing=sorted(set(c.columns)-set(m.sample_id));
 if missing:raise ValueError(f"Count columns missing metadata in {mode}: {missing}")
 return c.astype(int),m

def filter_counts(c,a):
 k=(c>=a.min_count).sum(axis=1)>=a.min_samples;return c.loc[k],pd.DataFrame({"gene_id":c.index,"retained":k,"n_samples_ge_threshold":(c>=a.min_count).sum(axis=1),"total_count":c.sum(axis=1)})
def annotation(base):
 p=base/"data"/"annotation"/"Homo_sapiens.gene_info.gz";p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists():urllib.request.urlretrieve(GENE_INFO_URL,p)
 with gzip.open(p,"rt",encoding="utf-8",errors="replace") as h:d=pd.read_csv(h,sep="\t",dtype=str)
 d.columns=[x.lstrip("#") for x in d.columns];d=d[d.tax_id.eq("9606")].copy();d["gene_id"]=d.GeneID.astype(str);d["gene_symbol"]=d.Symbol.replace("-",np.nan);d["gene_description"]=d.description.replace("-",np.nan);return d[["gene_id","gene_symbol","gene_description","Synonyms","type_of_gene"]].drop_duplicates("gene_id")
def annotate(d,a):
 z=d.merge(a,on="gene_id",how="left");z["gene_symbol"]=z.gene_symbol.fillna(z.gene_id);z["plot_label"]=z.gene_symbol;return z

def imports():
 from pydeseq2.dds import DeseqDataSet
 from pydeseq2.ds import DeseqStats
 return DeseqDataSet,DeseqStats
def supported(obj,kw):
 p=inspect.signature(obj).parameters;return {k:v for k,v in kw.items() if k in p}
def fit(c,m,factor,num,den):
 D,S=imports();params=inspect.signature(D).parameters;kw={"counts":c,"metadata":m,"refit_cooks":True,"n_cpus":4};kw["design"]="~ "+factor if "design" in params else factor
 if "design" not in params:kw={**{k:v for k,v in kw.items() if k!="design"},"design_factors":factor}
 d=D(**supported(D,kw));d.deseq2();st=S(**supported(S,{"dds":d,"contrast":[factor,str(num),str(den)],"alpha":FDR,"n_cpus":4}));st.summary();return st.results_df
def test(c,m,mask,factor,num,den,label,scope):
 x=m.loc[mask].copy();x[factor]=x[factor].astype(str);lev={str(num),str(den)};x=x[x[factor].isin(lev)].copy()
 if set(x[factor])!=lev:raise ValueError(f"{label}: expected {lev}, observed {set(x[factor])}")
 x=x.set_index("sample_id");cc=c[x.index].T;x=x.reindex(cc.index);x[factor]=pd.Categorical(x[factor],categories=[str(den),str(num)],ordered=True);r=fit(cc,x,factor,num,den).reset_index().rename(columns={"index":"gene_id","log2FoldChange":"log2FC","pvalue":"p_value","padj":"adjusted_p_value","stat":"wald_stat","lfcSE":"standard_error","baseMean":"base_mean"});r["contrast"]=label;r["numerator"]=str(num);r["denominator"]=str(den);r["analysis_scope"]=scope;return r
def pooled(c,m):
 d=m[m.stage.eq("Dynamic")].copy();out=pd.DataFrame({s:c[d.loc[d.subject.eq(s),"sample_id"]].sum(axis=1) for s in d.subject.unique()});mm=d.sort_values(["subject","day"]).drop_duplicates("subject").copy();mm["sample_id"]=mm.subject.astype(str);return out,mm

def contrasts(c,m):
 out=[];dyn=m.stage.eq("Dynamic");ac,am=pooled(c,m);allm=pd.Series(True,index=am.index)
 out.append(test(ac,am,allm,"oxygen","Normoxia","Hypoxia","Normoxia_vs_Hypoxia_pooled","pooled_subject"))
 for lo,hi in [(100,120),(120,150),(100,150)]:out.append(test(ac,am,allm,"rpm",hi,lo,f"{hi}_vs_{lo}_RPM_pooled","pooled_subject"))
 for day in [2,4]:out.append(test(c,m,dyn&m.day.eq(day),"oxygen","Normoxia","Hypoxia",f"Normoxia_vs_Hypoxia_D{day}","conditional"))
 for oxy in ["Hypoxia","Normoxia"]:
  for day in [2,4]:
   for lo,hi in [(100,120),(120,150),(100,150)]:out.append(test(c,m,dyn&m.oxygen.eq(oxy)&m.day.eq(day),"rpm",hi,lo,f"{oxy}_{hi}_vs_{lo}_RPM_D{day}","conditional"))
 z=m.copy();z["dynamic_initial"]=np.where(z.stage.eq("Initial"),"Initial","Dynamic");out.append(test(c,z,pd.Series(True,index=z.index),"dynamic_initial","Dynamic","Initial","Dynamic_pooled_vs_Initial","pooled_vs_initial"))
 for oxy in ["Normoxia","Hypoxia"]:
  z=m.copy();z["group"]=np.where(z.stage.eq("Initial"),"Initial",z.oxygen);out.append(test(c,z,z.stage.eq("Initial")|z.oxygen.eq(oxy),"group",oxy,"Initial",f"{oxy}_pooled_vs_Initial","pooled_vs_initial"))
 for rpm in [100,120,150]:
  z=m.copy();z["group"]=np.where(z.stage.eq("Initial"),"Initial",z.rpm);out.append(test(c,z,z.stage.eq("Initial")|z.rpm.eq(str(rpm)),"group",rpm,"Initial",f"{rpm}_RPM_pooled_vs_Initial","pooled_vs_initial"))
 for cond in m.loc[dyn,"condition"].drop_duplicates():
  z=m.copy();z["group"]=np.where(z.stage.eq("Initial"),"Initial",z.condition);out.append(test(c,z,z.stage.eq("Initial")|z.condition.eq(cond),"group",cond,"Initial",f"{cond}_vs_Initial","condition_vs_initial"))
 return pd.concat(out,ignore_index=True)
def tiers(d,a):
 z=d.copy();z["fdr_significant"]=z.adjusted_p_value.lt(a.fdr);z["moderate_deg"]=z.fdr_significant&z.log2FC.abs().ge(a.log2fc);z["large_deg"]=z.fdr_significant&z.log2FC.abs().ge(LARGE_FC);z["direction"]=np.where(z.log2FC>=0,"Up","Down");return z

def split_tables(de,out):
 for name,z in de.groupby("contrast"):
  p=out/safe(name);p.mkdir(parents=True,exist_ok=True);z.to_csv(p/"all_tested_genes.csv",index=False);z[z.fdr_significant].to_csv(p/"fdr_significant_genes.csv",index=False);z[z.moderate_deg].to_csv(p/"moderate_DEGs_FDR0.05_absLog2FC0.2.csv",index=False);z[z.large_deg].to_csv(p/"large_DEGs_FDR0.05_absLog2FC0.585.csv",index=False)
def count_data(de):
 rows=[]
 for (scope,name),z in de.groupby(["analysis_scope","contrast"]):
  for title,col in [("FDR only","fdr_significant"),("Moderate |log2FC| >= 0.2","moderate_deg"),("Large |log2FC| >= 0.585","large_deg")]:
   for dr in ["Up","Down"]:rows.append(dict(analysis_scope=scope,contrast=name,tier=title,direction=dr,n_genes=int((z[col]&z.direction.eq(dr)).sum())))
 return pd.DataFrame(rows)
def bars(tab,out):
 for tier,z in tab.groupby("tier"):
  p=z.pivot(index="contrast",columns="direction",values="n_genes").fillna(0);p=p.assign(total=p.sum(axis=1)).sort_values("total").drop(columns="total");fig=plt.figure(figsize=(10,max(5,.34*len(p)+2)),layout="constrained");gs=fig.add_gridspec(1,2,width_ratios=[1,.18]);ax=fig.add_subplot(gs[0]);la=fig.add_subplot(gs[1]);la.axis("off");y=np.arange(len(p));u=ax.barh(y,p.get("Up",0),color="#B2182B");d=ax.barh(y,-p.get("Down",0),color="#2166AC");ax.set_yticks(y);ax.set_yticklabels([x.replace("_"," ") for x in p.index],fontsize=8);ax.axvline(0,color="black",lw=.8);ax.set_xlabel("Number of genes");ax.set_title(tier);la.legend([u,d],["Up","Down"],frameon=False,loc="upper left");sns.despine(ax=ax);save(fig,out/safe(tier))
def volcano(z,p,a):
 q=z.copy();q["y"]=-np.log10(q.adjusted_p_value.clip(lower=1e-300));sig=q.moderate_deg;fig=plt.figure(figsize=(7.75,5.2),layout="constrained");gs=fig.add_gridspec(1,2,width_ratios=[1,.2]);ax=fig.add_subplot(gs[0]);la=fig.add_subplot(gs[1]);la.axis("off");ax.scatter(q.loc[~sig,"log2FC"],q.loc[~sig,"y"],s=12,c="#888",alpha=.2);u=ax.scatter(q.loc[sig&q.log2FC.gt(0),"log2FC"],q.loc[sig&q.log2FC.gt(0),"y"],s=24,c="#B2182B");d=ax.scatter(q.loc[sig&q.log2FC.lt(0),"log2FC"],q.loc[sig&q.log2FC.lt(0),"y"],s=24,c="#2166AC");ax.axhline(-np.log10(a.fdr),ls="--",c="black");ax.axvline(a.log2fc,ls="--",c="black");ax.axvline(-a.log2fc,ls="--",c="black");ax.set_title(z.contrast.iloc[0].replace("_"," "));ax.set_xlabel("Log2 fold change");ax.set_ylabel("-Log10 adjusted P");la.legend([u,d],["Higher","Lower"],frameon=False,loc="upper left");sns.despine(ax=ax);save(fig,p)
def gsea(de,out,nperm):
 import gseapy as gp;tabs=[]
 for name,z in de.groupby("contrast"):
  r=z[["gene_symbol","wald_stat"]].dropna().copy();r.gene_symbol=r.gene_symbol.astype(str).str.upper();r["abs_stat"]=r.wald_stat.abs();r=r.sort_values(["abs_stat","gene_symbol"],ascending=[False,True]).drop_duplicates("gene_symbol")[["gene_symbol","wald_stat"]].sort_values(["wald_stat","gene_symbol"],ascending=[False,True]).reset_index(drop=True)
  # Deterministic, negligible tie breaker prevents arbitrary prerank ordering.
  r["wald_stat"]=r.wald_stat.to_numpy()+np.linspace(1e-12,0,len(r),endpoint=False)
  for lib in ["MSigDB_Hallmark_2020","GO_Biological_Process_2023"]:
   try:q=gp.prerank(rnk=r,gene_sets=lib,organism="Human",min_size=10,max_size=500,permutation_num=nperm,seed=20260919,threads=4,outdir=None,verbose=False).res2d.reset_index();q["contrast"]=name;q["library"]=lib;tabs.append(q)
   except Exception as e:print(f"WARNING GSEA {name} {lib}: {e}",file=sys.stderr)
 (pd.concat(tabs,ignore_index=True) if tabs else pd.DataFrame()).to_csv(out,index=False)

def old_complete(base,mode,no_gsea):
 old=base/"analysis"/"1_4_1"/mode
 req=[old/"barplots"/"DEG_counts_by_contrast.csv",old/"differential_expression",old/"volcano"]
 if not no_gsea:req.append(old/"pathways"/"all_preranked_GSEA.csv")
 return old if all(x.exists() for x in req) else None
def run_mode(raw,meta,ann,mode,root,a):
 out=root/mode;done=out/"completion_manifest.json";force=a.force or (a.force_primary if mode=="primary_collapsed" else a.force_exploratory)
 if done.exists() and not force:return json.loads(done.read_text())
 prior=old_complete(a.base,mode,a.no_gsea)
 if prior and not force:
  result={"status":"skipped_completed_v1.4.1","existing_output":str(prior),"note":"Terminal outputs detected; no recomputation performed."};done.parent.mkdir(parents=True,exist_ok=True);done.write_text(json.dumps(result,indent=2));return result
 dirs={k:out/k for k in ["counts","qc","differential_expression","volcano","barplots","pathways"]};[p.mkdir(parents=True,exist_ok=True) for p in dirs.values()];c,m=matrix(raw,meta,mode);c.to_csv(dirs["counts"]/"raw_counts.csv");m.to_csv(dirs["qc"]/"sample_metadata.csv",index=False);f,audit=filter_counts(c,a);f.to_csv(dirs["counts"]/"filtered_counts.csv");audit.to_csv(dirs["qc"]/"gene_filter_audit.csv",index=False);de=tiers(annotate(contrasts(f,m),ann),a);split_tables(de,dirs["differential_expression"]);ct=count_data(de);ct.to_csv(dirs["barplots"]/"DEG_counts_by_contrast.csv",index=False);bars(ct,dirs["barplots"])
 for name,z in de.groupby("contrast"):volcano(z,dirs["volcano"]/safe(name),a)
 if not a.no_gsea:gsea(de,dirs["pathways"]/"all_preranked_GSEA.csv",a.gsea_permutations)
 result={"status":"complete","analysis_units":len(m),"genes_after_filtering":len(f),"contrasts":int(de.contrast.nunique()),"inferential_status":"primary" if mode=="primary_collapsed" else "exploratory pseudoreplication only"};done.write_text(json.dumps(result,indent=2));return result
def main():
 a=args();style();root=a.base/"analysis"/VERSION;root.mkdir(parents=True,exist_ok=True);raw,meta=load_raw(a.base/"data"/"counts");ann=annotation(a.base);ann.to_csv(root/"gene_annotation.csv",index=False);summary={"version":"1.4.1.1","resume_policy":"Skip completed v1.4.1 branches when terminal outputs are detected; completion manifests control subsequent reruns.","fixes":["preserve sample_id in exploratory metadata","deterministic GSEA tie breaking"],"analyses":{}}
 for mode in ["primary_collapsed","exploratory_lanes_separate"]:summary["analyses"][mode]=run_mode(raw,meta,ann,mode,root,a)
 (root/"run_summary.json").write_text(json.dumps(summary,indent=2));print(f"Transcriptomics v1.4.1.1 complete: {root}")
if __name__=="__main__":main()
