#!/usr/bin/env python3
"""Agitation and oxygen publication plotting workflow v1.1.

Standalone correction/extension using completed primary-collapsed DESeq2 outputs.
Generates 300 DPI PNG files only under agitation_oxygen_1_1/.

Changes from v1:
- Focused agitation effect plots are split by contrast so labels cannot be cut off.
- Adds agitation temporal analyses for 150 vs 100 and 120 vs 100 RPM across
  pooled, D2, and D4 comparisons.
- Retains oxygen pooled/D2/D4 temporal analysis.
- All legends are separate PNG files.
"""
from __future__ import annotations
import argparse,json,re,warnings
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
from matplotlib.lines import Line2D
warnings.filterwarnings("ignore",category=RuntimeWarning)
BASE=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
ROOT=BASE/"analysis"/"1_4_1"/"primary_collapsed"
DPI=300;FDR=.05;FC=.2;LARGE=float(np.log2(1.5));UP="#B2182B";DOWN="#2166AC";GREY="#8A8A8A";POOLED="#6A3D9A";D2="#4DAF4A";D4="#E6AB02"
AGITATION_GENES=["CDH2","PKP3","AJM1","LLGL1","TUBA1A","ACTN1","ZYX","ARHGEF19","ARHGAP39","GMIP","PLEKHG5","ERBB3","PDGFA","AXL","SRC","MAPK7","IRS2","BCL2L1","FOXO3","FAS","BBC3","TP53I3","GYS1","HMGCR","FDFT1","SIRT4","PANK1","PYCR1","NDUFAF3","EMX1","SOX12","KLF7","SNAI3","HMGA1","CUX1","NODAL","ALPP","ALPG","MRNIP","ALKBH2"]
OXYGEN_GENES=["PDK1","COX11","LPCAT3","SRR","FZD2","GRM5","PKDCC","KLF7","CLIC5","JAKMIP2","PXN","SLC4A5","EDIL3","CTSB","TCP1","PDCD4","HEXIM1","HEXIM2","PDE4C","HIF1A-AS2","NETO1-DT","AATBC"]
def args():
 p=argparse.ArgumentParser();p.add_argument("--input",type=Path,default=ROOT);p.add_argument("--output",type=Path);p.add_argument("--top-focused",type=int,default=20);return p.parse_args()
def style():
 mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":28,"axes.titlesize":38,"axes.titleweight":"bold","axes.labelsize":34,"axes.labelweight":"bold","xtick.labelsize":25,"ytick.labelsize":25,"axes.linewidth":2.8,"savefig.dpi":DPI});sns.set_style("ticks")
def save(fig,p):p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.35);plt.close(fig)
def load(root,name):
 p=root/"differential_expression"/name/"all_tested_genes.csv";d=pd.read_csv(p,dtype={"gene_id":str});d["gene_symbol"]=d.gene_symbol.fillna(d.gene_id).astype(str).str.upper();d["sig"]=d.adjusted_p_value.lt(FDR)&d.log2FC.abs().ge(FC);d["large"]=d.adjusted_p_value.lt(FDR)&d.log2FC.abs().ge(LARGE);return d.sort_values("adjusted_p_value").drop_duplicates("gene_symbol").set_index("gene_symbol")
def legend(out):
 fig,ax=plt.subplots(figsize=(12,2.8));ax.axis("off");ax.legend([Line2D([0],[0],marker="o",color="w",markerfacecolor=POOLED,markersize=16),Line2D([0],[0],marker="o",color="w",markerfacecolor=D2,markersize=16),Line2D([0],[0],marker="o",color="w",markerfacecolor=D4,markersize=16)],["Pooled","Day 2","Day 4"],loc="center",ncol=3,frameon=False,prop={"size":24,"weight":"bold"});save(fig,out/"legends"/"temporal")
 fig,ax=plt.subplots(figsize=(9,2.8));ax.axis("off");ax.legend([Line2D([0],[0],marker="o",color="w",markerfacecolor=UP,markersize=16),Line2D([0],[0],marker="o",color="w",markerfacecolor=DOWN,markersize=16)],["Higher in numerator","Lower in numerator"],loc="center",ncol=2,frameon=False,prop={"size":24,"weight":"bold"});save(fig,out/"legends"/"effect_direction")
def focused_one(root,out,contrast,title,n):
 d=load(root,contrast);z=d[d.sig].copy().sort_values("adjusted_p_value").head(n).sort_values("log2FC");z.reset_index().to_csv(out/"source_data"/f"{contrast}_focused.csv",index=False)
 if z.empty:return
 fig,ax=plt.subplots(figsize=(14,max(9,.72*len(z)+5)),layout="constrained");y=np.arange(len(z));ax.scatter(z.log2FC,y,s=np.where(z.large,165,105),c=np.where(z.log2FC>=0,UP,DOWN),alpha=.78,edgecolor="white",lw=1);ax.axvline(0,c="black",lw=2);ax.set_yticks(y);ax.set_yticklabels(z.index,fontsize=25,fontweight="bold");ax.set_xlabel("Log2 fold change",labelpad=22);ax.set_title(title,pad=28);ax.margins(x=.18);sns.despine(ax=ax);fig.subplots_adjust(left=.30,bottom=.22,right=.96,top=.88);save(fig,out/"focused_agitation"/contrast)
def merge_by_gene(root,names,genes):
 frames=[]
 for label,name in names:
  d=load(root,name);q=d.reindex(genes);frames.append(pd.DataFrame({"gene_symbol":genes,"time":label,"log2FC":q.log2FC.values,"adjusted_p_value":q.adjusted_p_value.values,"moderate":q.sig.fillna(False).values}))
 return pd.concat(frames,ignore_index=True)
def temporal_heatmap(root,out,prefix,names,genes,title):
 t=merge_by_gene(root,names,genes);t.to_csv(out/"source_data"/f"{prefix}_pooled_D2_D4.csv",index=False);mat=t.pivot(index="gene_symbol",columns="time",values="log2FC").reindex(index=genes,columns=[x[0] for x in names]);mat=mat.dropna(how="all")
 fig,ax=plt.subplots(figsize=(12,max(10,.62*len(mat)+5)),layout="constrained");lim=max(1,float(np.nanmax(abs(mat.values))));sns.heatmap(mat,cmap="vlag",center=0,vmin=-lim,vmax=lim,cbar=False,linewidths=.7,linecolor="white",ax=ax)
 sig=t.pivot(index="gene_symbol",columns="time",values="moderate").reindex(index=mat.index,columns=mat.columns).fillna(False)
 for i,g in enumerate(mat.index):
  for j,c in enumerate(mat.columns):
   if sig.loc[g,c]:ax.text(j+.5,i+.5,"*",ha="center",va="center",fontsize=18,fontweight="bold")
 ax.set_title(title,pad=28);ax.set_xlabel("");ax.set_ylabel("");ax.tick_params(axis="x",rotation=0,labelsize=27);ax.tick_params(axis="y",rotation=0,labelsize=22);[q.set_fontweight("bold") for q in ax.get_xticklabels()+ax.get_yticklabels()];fig.subplots_adjust(left=.28,bottom=.14,right=.96,top=.91);save(fig,out/"temporal"/f"{prefix}_heatmap")
def temporal_paired(root,out,prefix,names,genes,title):
 t=merge_by_gene(root,names,genes);p=t.pivot(index="gene_symbol",columns="time",values="log2FC").reindex(index=genes,columns=[x[0] for x in names]).dropna(how="all");p=p.loc[p.abs().max(axis=1).sort_values().index];fig,ax=plt.subplots(figsize=(16,max(10,.66*len(p)+5)),layout="constrained");y=np.arange(len(p));colors={"Pooled":POOLED,"Day 2":D2,"Day 4":D4}
 for i,(g,r) in enumerate(p.iterrows()):
  vals=r.dropna();ax.plot(vals.values,[i]*len(vals),c=GREY,lw=3,alpha=.16)
  for lab,val in vals.items():ax.scatter(val,i,s=180,c=colors[lab],alpha=.65,edgecolor="white",lw=1,zorder=3)
 ax.axvline(0,c="black",lw=2);ax.set_yticks(y);ax.set_yticklabels(p.index,fontsize=23,fontweight="bold");ax.set_xlabel("Log2 fold change",labelpad=20);ax.set_title(title,pad=28);ax.margins(x=.15);sns.despine(ax=ax);fig.subplots_adjust(left=.26,bottom=.16,right=.96,top=.90);save(fig,out/"temporal"/f"{prefix}_paired")
def main():
 a=args();out=a.output or a.input/"agitation_oxygen_1_1";out.mkdir(parents=True,exist_ok=True);(out/"source_data").mkdir(exist_ok=True);style();focused_one(a.input,out,"150_vs_120_RPM_pooled","150 versus 120 RPM",a.top_focused);focused_one(a.input,out,"120_vs_100_RPM_pooled","120 versus 100 RPM",a.top_focused)
 names1510=[("Pooled","150_vs_100_RPM_pooled"),("Day 2","Normoxia_150_vs_100_RPM_D2"),("Day 4","Normoxia_150_vs_100_RPM_D4")];names1210=[("Pooled","120_vs_100_RPM_pooled"),("Day 2","Normoxia_120_vs_100_RPM_D2"),("Day 4","Normoxia_120_vs_100_RPM_D4")];namesoxy=[("Pooled","Normoxia_vs_Hypoxia_pooled"),("Day 2","Normoxia_vs_Hypoxia_D2"),("Day 4","Normoxia_vs_Hypoxia_D4")]
 temporal_heatmap(a.input,out,"agitation_150_vs_100",names1510,AGITATION_GENES,"150 versus 100 RPM: pooled and temporal effects");temporal_paired(a.input,out,"agitation_150_vs_100",names1510,AGITATION_GENES,"150 versus 100 RPM across pooled, D2, and D4 comparisons");temporal_heatmap(a.input,out,"agitation_120_vs_100",names1210,AGITATION_GENES,"120 versus 100 RPM: pooled and temporal effects");temporal_paired(a.input,out,"agitation_120_vs_100",names1210,AGITATION_GENES,"120 versus 100 RPM across pooled, D2, and D4 comparisons");temporal_heatmap(a.input,out,"oxygen",namesoxy,OXYGEN_GENES,"Oxygen-response persistence and timing");legend(out);(out/"manifest.json").write_text(json.dumps({"version":"1.1","focused_agitation":"split into independent figures with expanded margins","temporal_agitation":["150 vs 100 RPM","120 vs 100 RPM"],"temporal_scope":"D2 and D4 use normoxia-stratified contrasts to match the representative agitation framework","output":"300 DPI PNG only"},indent=2));print(f"Agitation/oxygen v1.1 correction complete: {out}")
if __name__=="__main__":main()
