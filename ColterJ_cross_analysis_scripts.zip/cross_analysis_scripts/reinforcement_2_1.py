#!/usr/bin/env python3
"""Experimental-developmental reinforcement analysis v2.1.

Matches experimental gene_symbol to Tyser reference gene_id and analyzes only:
1. Dynamic_pooled_vs_Initial
2. 150_vs_100_RPM_pooled
3. 120_vs_100_RPM_pooled
4. Normoxia_vs_Hypoxia_pooled

V2.1 removes the in-panel positive-y/negative-y explanatory text. A separate
legend PNG is retained. Outputs are written to cross_analysis/reinforcement/2_1/.
"""
from __future__ import annotations
import argparse,json,re,warnings
from datetime import datetime,timezone
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.lines import Line2D
warnings.filterwarnings("ignore",category=RuntimeWarning)
PROJECT=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
EXP_ROOT=PROJECT/"analysis"/"1_4_1"/"primary_collapsed"/"differential_expression"
REF_ROOT=PROJECT/"cross_analysis"/"dge"/"all_tested"
OUT=PROJECT/"cross_analysis"/"reinforcement"/"2_1"
VERSION="2_1";PADJ=.05;FC=.2;DPI=300
EXPERIMENTAL=["Dynamic_pooled_vs_Initial","150_vs_100_RPM_pooled","120_vs_100_RPM_pooled","Normoxia_vs_Hypoxia_pooled"]
CONVERGENT="#7B3294";DIVERGENT="#D95F02"
def args():
 p=argparse.ArgumentParser();p.add_argument("--experimental-root",type=Path,default=EXP_ROOT);p.add_argument("--reference-root",type=Path,default=REF_ROOT);p.add_argument("--output",type=Path,default=OUT);p.add_argument("--top-labels",type=int,default=30);p.add_argument("--padj",type=float,default=PADJ);p.add_argument("--abs-log2fc",type=float,default=FC);p.add_argument("--overwrite",action="store_true");return p.parse_args()
def safe(x):return re.sub(r"[^A-Za-z0-9_]+","_",str(x)).strip("_")
def style():mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":24,"axes.titlesize":32,"axes.titleweight":"bold","axes.labelsize":28,"axes.labelweight":"bold","xtick.labelsize":22,"ytick.labelsize":22,"axes.linewidth":2.5,"xtick.major.width":2.5,"ytick.major.width":2.5,"savefig.dpi":DPI})
def save(fig,p):p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.30);plt.close(fig)
def clean_symbol(s):return s.astype(str).str.strip().str.upper().str.replace(r"\.\d+$","",regex=True)
def read_exp(path):
 d=pd.read_csv(path,dtype={"gene_id":str});req={"gene_symbol","log2FC","adjusted_p_value"};miss=req-set(d.columns)
 if miss:raise ValueError(f"{path} missing {sorted(miss)}")
 d=d.copy();d["gene_key"]=clean_symbol(d.gene_symbol);d["exp_gene_id"]=d.gene_id.astype(str);d["exp_gene_symbol"]=d.gene_symbol.astype(str);d["exp_log2FC"]=pd.to_numeric(d.log2FC,errors="coerce");d["exp_adjusted_p_value"]=pd.to_numeric(d.adjusted_p_value,errors="coerce");d=d[d.gene_key.ne("")&d.gene_key.ne("NAN")].sort_values("exp_adjusted_p_value").drop_duplicates("gene_key");return d[["gene_key","exp_gene_id","exp_gene_symbol","exp_log2FC","exp_adjusted_p_value"]]
def read_ref(path):
 d=pd.read_csv(path,dtype={"gene_id":str});req={"gene_id","log2FC","adjusted_p_value"};miss=req-set(d.columns)
 if miss:raise ValueError(f"{path} missing {sorted(miss)}")
 d=d.copy();d["gene_key"]=clean_symbol(d.gene_id);d["ref_gene_symbol"]=d.gene_id.astype(str);d["ref_log2FC"]=pd.to_numeric(d.log2FC,errors="coerce");d["ref_adjusted_p_value"]=pd.to_numeric(d.adjusted_p_value,errors="coerce");d=d[d.gene_key.ne("")&d.gene_key.ne("NAN")].sort_values("ref_adjusted_p_value").drop_duplicates("gene_key");return d[["gene_key","ref_gene_symbol","ref_log2FC","ref_adjusted_p_value"]]
def references(root):return dict(sorted((p.name.replace("_all_tested_genes.csv",""),p) for p in root.glob("*_all_tested_genes.csv") if p.name.startswith(("Epiblast_vs_","PriS_vs_"))))
def compare(ep,rp,padj,fc):
 d=read_exp(ep).merge(read_ref(rp),on="gene_key",how="inner",validate="one_to_one")
 if len(d)<100:raise ValueError(f"Implausibly low shared-gene count ({len(d)}): {ep} vs {rp}")
 d=d.dropna(subset=["exp_log2FC","ref_log2FC","exp_adjusted_p_value","ref_adjusted_p_value"]).copy();d["exp_moderate"]=(d.exp_adjusted_p_value<padj)&(d.exp_log2FC.abs()>fc);d["ref_moderate"]=(d.ref_adjusted_p_value<padj)&(d.ref_log2FC.abs()>fc);d["joint_moderate"]=d.exp_moderate&d.ref_moderate;d["reinforcement_ratio"]=d.exp_log2FC/d.ref_log2FC;d["delta_log2FC"]=d.exp_log2FC-d.ref_log2FC;d["relationship"]=np.where(d.reinforcement_ratio>0,"Convergent / reinforced","Divergent");d["display_label"]=d.exp_gene_symbol.fillna(d.ref_gene_symbol);return d
def boxed(ax,d,n):
 if d.empty or n<=0:return
 q=d.copy();q["score"]=np.sqrt(q.exp_log2FC.abs()*q.ref_log2FC.abs())*(-np.log10(np.maximum(q.exp_adjusted_p_value*q.ref_adjusted_p_value,1e-300)));pick=pd.concat([q[q.reinforcement_ratio>0].nlargest(max(1,n//2),"score"),q[q.reinforcement_ratio<0].nlargest(max(1,n-n//2),"score")]).drop_duplicates("gene_key").nlargest(n,"score")
 try:
  from adjustText import adjust_text
  texts=[ax.text(r.plot_x,r.plot_y,r.display_label,fontsize=14,fontweight="bold",ha="center",va="center",bbox=dict(boxstyle="round,pad=.24",fc="white",ec="#333",lw=1,alpha=.96),clip_on=True,zorder=5) for _,r in pick.iterrows()];adjust_text(texts,ax=ax,expand=(1.3,1.5),force_text=(.9,1.1),force_points=(.5,.8),ensure_inside_axes=True,arrowprops=dict(arrowstyle="-",color="#555",lw=.9,alpha=.7))
 except ImportError:
  for i,(_,r) in enumerate(pick.iterrows()):
   side=1 if i%2==0 else -1;ax.annotate(r.display_label,(r.plot_x,r.plot_y),xytext=(side*(22+7*(i//2)),14+11*(i//2)),textcoords="offset points",fontsize=13,fontweight="bold",ha="left" if side>0 else "right",bbox=dict(boxstyle="round,pad=.24",fc="white",ec="#333",lw=1),arrowprops=dict(arrowstyle="-",color="#555",lw=.9),annotation_clip=True)
def plot(d,en,rn,p,n):
 z=d[d.joint_moderate&np.isfinite(d.reinforcement_ratio)].copy()
 if z.empty:return False
 xlim=max(1,float(np.nanpercentile(np.abs(z.delta_log2FC),99))*1.15);ylim=max(1,float(np.nanpercentile(np.abs(z.reinforcement_ratio),99))*1.15);z["plot_x"]=z.delta_log2FC.clip(-xlim,xlim);z["plot_y"]=z.reinforcement_ratio.clip(-ylim,ylim)
 fig,ax=plt.subplots(figsize=(15,12),layout="constrained");ax.scatter(z.plot_x,z.plot_y,s=np.clip(np.sqrt(z.exp_log2FC.abs()*z.ref_log2FC.abs())*85,35,230),c=np.where(z.reinforcement_ratio>0,CONVERGENT,DIVERGENT),alpha=.58,edgecolors="white",lw=.45);ax.axhline(0,c="black",lw=1.8);ax.axvline(0,c="black",lw=1.2,ls="--");ax.set_xlim(-xlim,xlim);ax.set_ylim(-ylim,ylim);ax.set_xlabel("Delta log2FC: experimental - reference");ax.set_ylabel("Signed reinforcement ratio: experimental / reference");ax.set_title(f"{en.replace('_',' ')}\nversus {rn.replace('_',' ')}",pad=24);boxed(ax,z,n);ax.grid(alpha=.12);ax.spines[["top","right"]].set_visible(False);save(fig,p);return True
def main():
 a=args();style();a.output.mkdir(parents=True,exist_ok=True);refs=references(a.reference_root)
 if not refs:raise FileNotFoundError(f"No reference tables under {a.reference_root}")
 rows=[]
 for order,en in enumerate(EXPERIMENTAL,1):
  ep=a.experimental_root/en/"all_tested_genes.csv"
  if not ep.exists():raise FileNotFoundError(ep)
  for rn,rp in refs.items():
   stem=f"{safe(en)}__{safe(rn)}";png=a.output/"plots"/f"{order}_{safe(en)}"/stem;src=a.output/"source_data"/f"{order}_{safe(en)}";src.mkdir(parents=True,exist_ok=True)
   if png.with_suffix(".png").exists() and not a.overwrite:raise FileExistsError(f"Use --overwrite: {png.with_suffix('.png')}")
   print(f"[COMPARE] {en} vs {rn}");d=compare(ep,rp,a.padj,a.abs_log2fc);d.to_csv(src/f"{stem}_shared_genes.csv.gz",index=False,compression="gzip");joint=d[d.joint_moderate].copy();joint.to_csv(src/f"{stem}_joint_moderate.csv",index=False);made=plot(d,en,rn,png,a.top_labels);conv=joint.reinforcement_ratio.gt(0);div=joint.reinforcement_ratio.lt(0)
   rows.append({"experimental_order":order,"experimental_contrast":en,"reference_contrast":rn,"n_shared_tested_genes":len(d),"n_experimental_moderate":int(d.exp_moderate.sum()),"n_reference_moderate":int(d.ref_moderate.sum()),"n_joint_moderate":len(joint),"n_convergent":int(conv.sum()),"n_divergent":int(div.sum()),"convergent_fraction":float(conv.mean()) if len(joint) else np.nan,"divergent_fraction":float(div.mean()) if len(joint) else np.nan,"plot_generated":made,"plot_file":str(png.with_suffix('.png'))})
 summary=pd.DataFrame(rows);(a.output/"summaries").mkdir(exist_ok=True);summary.to_csv(a.output/"summaries"/"reinforcement_summary_2_1.csv",index=False)
 fig,ax=plt.subplots(figsize=(11,2.6));ax.axis("off");ax.legend([Line2D([0],[0],marker="o",color="w",markerfacecolor=CONVERGENT,markersize=15),Line2D([0],[0],marker="o",color="w",markerfacecolor=DIVERGENT,markersize=15)],["Directional convergence / reinforcement","Directional divergence"],loc="center",ncol=2,frameon=False,prop={"size":20,"weight":"bold"});save(fig,a.output/"legends"/"reinforcement_legend")
 manifest={"workflow":"reinforcement_2_1","timestamp_utc":datetime.now(timezone.utc).isoformat(),"experimental_contrasts":EXPERIMENTAL,"reference_contrasts":list(refs),"gene_match":"experimental gene_symbol uppercase joined to reference gene_id uppercase","joint_moderate":f"padj < {a.padj} and abs(log2FC) > {a.abs_log2fc} in both datasets","plot_change":"Removed in-panel positive-y/negative-y explanatory text","output":"300 DPI PNG only"};(a.output/"reinforcement_manifest_2_1.json").write_text(json.dumps(manifest,indent=2));print(f"[COMPLETE] {len(summary)} analyses written to {a.output}")
if __name__=="__main__":main()
