#!/usr/bin/env python3
"""Focused developmental reinforcement barplots v2.1.3.

Reads reinforcement V2.1 source tables and creates one diverging-count barplot
per pooled experimental contrast. Primary panels are restricted to:

- Epiblast vs PriS            (gastrulation entry)
- Epiblast vs Mesoderm       (broad mesoderm specification)
- Epiblast vs DE             (definitive endoderm specification)

Axial mesoderm is excluded because it is a specialized downstream mesodermal
subtype and is redundant with the intended high-level lineage framing.

Positive bars: jointly moderate genes with reinforcement_ratio > 0.
Negative bars: negative count of jointly moderate genes with ratio < 0.

Outputs:
  cross_analysis/reinforcement/2_1/barplots/2_1_3/
"""
from __future__ import annotations
import argparse,json,re,warnings
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.patches import Patch
warnings.filterwarnings("ignore",category=RuntimeWarning)

PROJECT=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
ROOT=PROJECT/"cross_analysis"/"reinforcement"/"2_1"
SOURCE=ROOT/"source_data"
OUT=ROOT/"barplots"/"2_1_3"
DPI=300;VERSION="2_1_3";BAR_ALPHA=.72
CONVERGENT="#7B3294";DIVERGENT="#D95F02"
EXPERIMENTAL_ORDER=[
 (1,"Dynamic_pooled_vs_Initial"),
 (2,"150_vs_100_RPM_pooled"),
 (3,"120_vs_100_RPM_pooled"),
 (4,"Normoxia_vs_Hypoxia_pooled"),
]
FOCUSED_REFERENCES=["Epiblast_vs_PriS","Epiblast_vs_Mesoderm","Epiblast_vs_DE"]
DISPLAY={
 "Epiblast_vs_PriS":"Primitive streak",
 "Epiblast_vs_Mesoderm":"Mesoderm",
 "Epiblast_vs_DE":"Definitive endoderm",
}

def args():
 p=argparse.ArgumentParser();p.add_argument("--source-root",type=Path,default=SOURCE);p.add_argument("--output-dir",type=Path,default=OUT);p.add_argument("--bar-alpha",type=float,default=BAR_ALPHA);p.add_argument("--overwrite",action="store_true");return p.parse_args()
def safe(x):return re.sub(r"[^A-Za-z0-9_]+","_",str(x)).strip("_")
def style():
 mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":28,"axes.titlesize":38,"axes.titleweight":"bold","axes.labelsize":34,"axes.labelweight":"bold","xtick.labelsize":27,"ytick.labelsize":27,"axes.linewidth":2.8,"xtick.major.width":2.8,"ytick.major.width":2.8,"savefig.dpi":DPI})
def save(fig,p):
 p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.35);plt.close(fig)
def as_bool(s):
 if pd.api.types.is_bool_dtype(s):return s.fillna(False)
 return s.astype(str).str.lower().isin(["true","1","yes"])
def parse_ref(filename,exp):
 stem=filename.replace("_joint_moderate.csv","").replace("_shared_genes.csv.gz","");prefix=f"{safe(exp)}__"
 return stem[len(prefix):] if stem.startswith(prefix) else stem.split("__",1)[-1]
def load_counts(folder,exp):
 files=sorted(folder.glob("*_joint_moderate.csv")) or sorted(folder.glob("*_shared_genes.csv.gz"));rows=[]
 for p in files:
  ref=parse_ref(p.name,exp)
  if ref not in FOCUSED_REFERENCES:continue
  d=pd.read_csv(p)
  if "reinforcement_ratio" not in d.columns:raise ValueError(f"Missing reinforcement_ratio: {p}")
  d["reinforcement_ratio"]=pd.to_numeric(d.reinforcement_ratio,errors="coerce")
  if "joint_moderate" in d.columns:d=d[as_bool(d.joint_moderate)]
  d=d[np.isfinite(d.reinforcement_ratio)].copy();conv=int((d.reinforcement_ratio>0).sum());div=int((d.reinforcement_ratio<0).sum())
  rows.append({"experimental_contrast":exp,"reference_contrast":ref,"developmental_state":DISPLAY[ref],"n_joint_moderate":len(d),"n_convergent":conv,"n_divergent":div,"convergent_fraction":conv/len(d) if len(d) else np.nan,"divergent_fraction":div/len(d) if len(d) else np.nan,"net_convergence":conv-div,"source_file":str(p)})
 t=pd.DataFrame(rows);missing=[r for r in FOCUSED_REFERENCES if r not in set(t.reference_contrast if not t.empty else [])]
 if missing:raise FileNotFoundError(f"Focused source tables missing for {exp}: {missing}")
 t["reference_order"]=t.reference_contrast.map({r:i for i,r in enumerate(FOCUSED_REFERENCES)})
 return t.sort_values("reference_order").reset_index(drop=True)
def draw(t,title,path,alpha):
 x=np.arange(len(t));mx=max(1,int(max(t.n_convergent.max(),t.n_divergent.max())));fig,ax=plt.subplots(figsize=(12,11),layout="constrained")
 up=ax.bar(x,t.n_convergent,color=CONVERGENT,alpha=alpha,width=.64,edgecolor="#4A1F66",linewidth=1.2)
 down=ax.bar(x,-t.n_divergent,color=DIVERGENT,alpha=alpha,width=.64,edgecolor="#8F3000",linewidth=1.2)
 ax.axhline(0,color="black",lw=2.2);ax.set_xticks(x);ax.set_xticklabels(t.developmental_state,rotation=25,ha="right",fontsize=27,fontweight="bold");ax.set_ylabel("Gene count\nEpiblast-aligned (+) / tissue-aligned (-)");ax.set_title(title,pad=28);ax.set_ylim(-mx*1.30,mx*1.30);ax.grid(axis="y",alpha=.13,lw=.8);ax.spines[["top","right"]].set_visible(False)
 for b,n in zip(up,t.n_convergent):ax.text(b.get_x()+b.get_width()/2,b.get_height()+mx*.035,str(int(n)),ha="center",va="bottom",fontsize=20,fontweight="bold")
 for b,n in zip(down,t.n_divergent):ax.text(b.get_x()+b.get_width()/2,b.get_height()-mx*.035,str(int(n)),ha="center",va="top",fontsize=20,fontweight="bold")
 save(fig,path)
def main():
 a=args();style()
 if not 0<a.bar_alpha<=1:raise ValueError("--bar-alpha must be > 0 and <= 1")
 if not a.source_root.exists():raise FileNotFoundError(a.source_root)
 a.output_dir.mkdir(parents=True,exist_ok=True);src=a.output_dir/"source_data";src.mkdir(exist_ok=True);all_rows=[];outputs=[]
 for order,exp in EXPERIMENTAL_ORDER:
  folder=a.source_root/f"{order}_{safe(exp)}"
  if not folder.exists():raise FileNotFoundError(folder)
  t=load_counts(folder,exp);all_rows.append(t);t.to_csv(src/f"{order}_{safe(exp)}_focused_counts.csv",index=False)
  out=a.output_dir/f"{order}_{safe(exp)}_gastrulation_lineage_programs"
  if out.with_suffix(".png").exists() and not a.overwrite:raise FileExistsError(f"Use --overwrite: {out.with_suffix('.png')}")
  draw(t,exp.replace("_"," ")+" against early developmental programs",out,a.bar_alpha);outputs.append({"experimental_order":order,"experimental_contrast":exp,"plot_file":str(out.with_suffix('.png'))})
 pd.concat(all_rows,ignore_index=True).to_csv(src/"focused_reinforcement_counts_all_conditions_2_1_3.csv",index=False);pd.DataFrame(outputs).to_csv(src/"reinforcement_barplot_outputs_2_1_3.csv",index=False)
 fig,ax=plt.subplots(figsize=(12,2.8));ax.axis("off");ax.legend([Patch(facecolor=CONVERGENT,alpha=a.bar_alpha,edgecolor="#4A1F66"),Patch(facecolor=DIVERGENT,alpha=a.bar_alpha,edgecolor="#8F3000")],["Epiblast-aligned genes","Tissue-aligned genes"],loc="center",ncol=2,frameon=False,prop={"size":24,"weight":"bold"});save(fig,a.output_dir/"reinforcement_bar_legend")
 manifest={"workflow":"reinforcement_bar_2_1_3","timestamp_utc":datetime.now(timezone.utc).isoformat(),"source_root":str(a.source_root),"output_dir":str(a.output_dir),"bar_alpha":a.bar_alpha,"focused_references":FOCUSED_REFERENCES,"excluded_from_v2_1_2":"Epiblast_vs_Axial_Mes","rationale":"Axial mesoderm is a specialized mesodermal subtype; primary panels retain gastrulation entry, broad mesoderm, and definitive endoderm.","positive_bar":"Epiblast-aligned jointly moderate genes","negative_bar":"negative count of tissue-aligned jointly moderate genes","output":"300 DPI PNG only"};(a.output_dir/"reinforcement_bar_manifest_2_1_3.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8");print(f"[COMPLETE] V2.1.3 barplots written to {a.output_dir}")
if __name__=="__main__":main()
