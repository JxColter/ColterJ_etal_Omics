#!/usr/bin/env python3
"""Dynamic-versus-initial developmental cross-analysis v2.4.1.

Standalone publication workflow retaining lineage-specific and pooled volcanoes,
effect heatmaps, developmental-alignment module barplots, alignment-count bars,
and alignment-specific ORA. Divergent volcanoes are mirrored downward.

V2.4.1 volcano formatting:
- convergent y limits: 0 to +40
- divergent y limits: -40 to 0
- plot values beyond +/-40 are clipped for display only
- titles have explicit whitespace above the axes and below the canvas edge

Outputs: cross_analysis/dynamic_initial/2_4_1/ (300 DPI PNG only).
"""
from __future__ import annotations
import argparse,json,re,warnings
from pathlib import Path
from datetime import datetime,timezone
import numpy as np,pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
from matplotlib.patches import Patch
from scipy.stats import hypergeom
from statsmodels.stats.multitest import multipletests
warnings.filterwarnings("ignore",category=RuntimeWarning)
P=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
SRC=P/"cross_analysis"/"reinforcement"/"2_1"/"source_data"/"1_Dynamic_pooled_vs_Initial"
BASE=P/"analysis"/"1_4_1"/"primary_collapsed";OUT=P/"cross_analysis"/"dynamic_initial"/"2_4_1"
ALL=BASE/"differential_expression"/"Dynamic_pooled_vs_Initial"/"all_tested_genes.csv";COUNTS=BASE/"counts"/"filtered_counts.csv"
DPI=300;FDR=.05;FC=.2;YLIM=40;EPI="#7B3294";LIN="#D95F02";MIX="#7A7A7A";GRAY="#BDBDBD";INIT="#E6E6E6"
LINEAGES={"Primitive streak":"Dynamic_pooled_vs_Initial__Epiblast_vs_PriS_joint_moderate.csv","Mesoderm":"Dynamic_pooled_vs_Initial__Epiblast_vs_Mesoderm_joint_moderate.csv","Definitive endoderm":"Dynamic_pooled_vs_Initial__Epiblast_vs_DE_joint_moderate.csv"}
MODULES={"Developmental and regulatory":["L1TD1","HMGA1","DNMT1","JARID2","SMARCA4","RUNX1","EMX1","SOX11","SOX12","SOX13","SALL2","CHD7","SOX15","SOX21","FEZF1","SKOR2","SNAI3","KMO","ZNF263","DEAF1","ZNF224","FOXL2"],"Chromatin and methylation":["CHD6","CHD7","PRMT5","SPIN1","BAZ1A","PAXIP1-AS2","LARRPM","SOX21-AS1","DNMT1","JARID2","SMARCA4","PRMT6","BRD4"],"Genome organization":["CTCF","STAG1","STAG3","NCAPH2","CENPN","CENPO"],"Mechanotransduction and architecture":["YAP1","TEAD1","PTK2","ZYX","CRB2","AJM1","PLEKHA7","KRT8","CXADR","LOXL1","LOXL3","PXN","LIMK2","RHOC"],"Cell cycle and genome maintenance":["CCND1","CCND2","CCNE2","SPDYA","CENPN","CENPO","ERCC1","MSH2","RAD54L","TP53BP1","RAD9A","FEN1","DDB2","MUTYH","CDC34"]}
def args():
 p=argparse.ArgumentParser();p.add_argument("--source-dir",type=Path,default=SRC);p.add_argument("--output-dir",type=Path,default=OUT);p.add_argument("--all-tested",type=Path,default=ALL);p.add_argument("--counts",type=Path,default=COUNTS);p.add_argument("--ora-library",default="GO_Biological_Process_2023");p.add_argument("--top-labels",type=int,default=30);p.add_argument("--top-heatmap",type=int,default=40);p.add_argument("--overwrite",action="store_true");return p.parse_args()
def safe(x):return re.sub(r"[^A-Za-z0-9_]+","_",str(x)).strip("_")
def style():mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":25,"axes.titlesize":36,"axes.titleweight":"bold","axes.labelsize":31,"axes.labelweight":"bold","xtick.labelsize":23,"ytick.labelsize":23,"axes.linewidth":2.7,"savefig.dpi":DPI});sns.set_style("ticks")
def save(f,p):p.parent.mkdir(parents=True,exist_ok=True);f.savefig(p.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.55);plt.close(f)
def bools(s):return s.fillna(False) if pd.api.types.is_bool_dtype(s) else s.astype(str).str.lower().isin(["true","1","yes"])
def load_cross(src):
 out=[]
 for lin,file in LINEAGES.items():
  d=pd.read_csv(src/file,dtype={"gene_key":str,"exp_gene_id":str})
  for c in ["exp_log2FC","ref_log2FC","delta_log2FC","reinforcement_ratio","exp_adjusted_p_value","ref_adjusted_p_value"]:d[c]=pd.to_numeric(d[c],errors="coerce")
  if "joint_moderate" in d:d=d[bools(d.joint_moderate)]
  d=d.dropna(subset=["exp_log2FC","ref_log2FC","reinforcement_ratio"]);d["lineage"]=lin;d["alignment"]=np.where(d.reinforcement_ratio>0,"Epiblast-aligned","Lineage-aligned");d["gene_symbol"]=d.display_label.fillna(d.gene_key).astype(str).str.upper();out.append(d)
 return pd.concat(out,ignore_index=True)
def pooled(c):
 rows=[]
 for gene,d in c.groupby("gene_symbol"):
  s=set(d.alignment);cl="Epiblast-aligned" if s=={"Epiblast-aligned"} else "Lineage-aligned" if s=={"Lineage-aligned"} else "Mixed";r=d.sort_values("exp_adjusted_p_value").iloc[0].copy();r["alignment"]=cl;r["lineage"]="Pooled developmental programs";r["reference_lineages"]=";".join(sorted(d.lineage.unique()));rows.append(r)
 return pd.DataFrame(rows).reset_index(drop=True)
def expdata(p):
 d=pd.read_csv(p,dtype={"gene_id":str});d["gene_symbol"]=d.gene_symbol.fillna(d.gene_id).astype(str).str.upper();d["log2FC"]=pd.to_numeric(d.log2FC,errors="coerce");d["adjusted_p_value"]=pd.to_numeric(d.adjusted_p_value,errors="coerce");return d.sort_values("adjusted_p_value").drop_duplicates("gene_symbol")
def labels(ax,d,n):
 q=d.copy();q["score"]=q.log2FC.abs()*np.abs(q.plot_y);pick=pd.concat([q[q.log2FC>0].nlargest(n//2,"score"),q[q.log2FC<0].nlargest(n-n//2,"score")]).drop_duplicates("gene_symbol")
 try:
  from adjustText import adjust_text
  t=[ax.text(r.log2FC,r.plot_y,r.gene_symbol,fontsize=14,fontweight="bold",bbox=dict(boxstyle="round,pad=.22",fc="white",ec="#333",alpha=.96)) for _,r in pick.iterrows()];adjust_text(t,ax=ax,ensure_inside_axes=True,arrowprops=dict(arrowstyle="-",color="#555",lw=.8))
 except ImportError:pass
def volcano(dataset,e,o,n,scope):
 for al,col,slug in [("Epiblast-aligned",EPI,"convergent"),("Lineage-aligned",LIN,"divergent")]:
  genes=set(dataset.loc[dataset.alignment.eq(al),"gene_symbol"]);q=e.copy();sel=q.gene_symbol.isin(genes);raw=(-np.log10(q.adjusted_p_value.clip(lower=1e-300)) if al=="Epiblast-aligned" else np.log10(q.adjusted_p_value.clip(lower=1e-300)));q["raw_plot_y"]=raw;q["plot_y"]=raw.clip(0,YLIM) if al=="Epiblast-aligned" else raw.clip(-YLIM,0);selected=q[sel].copy();selected.to_csv(o/"source_data"/f"volcano_{safe(scope)}_{slug}.csv",index=False)
  f,a=plt.subplots(figsize=(15,12));f.subplots_adjust(left=.12,right=.97,bottom=.12,top=.82);a.scatter(q.loc[~sel,"log2FC"],q.loc[~sel,"plot_y"],s=24,c=GRAY,alpha=.12);a.scatter(selected.log2FC,selected.plot_y,s=80,c=col,alpha=.62,edgecolor="white");a.axhline(-np.log10(FDR) if al=="Epiblast-aligned" else np.log10(FDR),c="black",ls="--");a.axvline(FC,c="black",ls="--");a.axvline(-FC,c="black",ls="--");a.set_xlabel("Experimental log2 fold change");a.set_ylabel("-Log10 adjusted P" if al=="Epiblast-aligned" else "Log10 adjusted P");a.set_ylim((0,YLIM) if al=="Epiblast-aligned" else (-YLIM,0));a.set_title(f"Dynamic vs initial: {al}\n{scope}",pad=34);labels(a,selected,n);a.spines[["top","right"]].set_visible(False);save(f,o/"volcanoes"/safe(scope)/slug)
def heatmap(dataset,o,n,scope):
 q=dataset[dataset.alignment.ne("Mixed")].copy();q["s"]=np.sqrt(q.exp_log2FC.abs()*q.ref_log2FC.abs())*(-np.log10(np.maximum(q.exp_adjusted_p_value*q.ref_adjusted_p_value,1e-300)));q=pd.concat([q[q.alignment.eq("Epiblast-aligned")].nlargest(n//2,"s"),q[q.alignment.eq("Lineage-aligned")].nlargest(n-n//2,"s")]).drop_duplicates("gene_symbol");m=q.set_index("gene_symbol")[["exp_log2FC","ref_log2FC","delta_log2FC"]];m.columns=["Dynamic vs initial","Epiblast vs reference","Delta"];m.to_csv(o/"source_data"/f"heatmap_{safe(scope)}.csv");f,a=plt.subplots(figsize=(13,max(10,.62*len(m)+5)),layout="constrained");v=max(1,np.nanmax(abs(m.values)));sns.heatmap(m,cmap="vlag",center=0,vmin=-v,vmax=v,cbar=False,linewidths=.6,linecolor="white",ax=a);a.set_title(scope,pad=30);a.tick_params(axis="x",rotation=30);a.tick_params(axis="y",rotation=0,labelsize=20);save(f,o/"heatmaps"/safe(scope))
def sample_group(x):return "Initial" if re.fullmatch(r"c\d+",re.sub(r"_S\d+_L\d{3}_\d+(?:\.tabular)?$","",str(x),flags=re.I).lower()) else "Dynamic"
def stars(q):return "***" if q<.001 else "**" if q<.01 else "*" if q<.05 else ""
def module_bars(p,e,countp,o):
 ct=pd.read_csv(countp,index_col=0);ct.index=ct.index.astype(str);ct.columns=ct.columns.astype(str);g=pd.Series([sample_group(x) for x in ct.columns],index=ct.columns);x=np.log2(ct.div(ct.sum(0),axis=1)*1e6+1);em=e.set_index("gene_symbol");ids=e.drop_duplicates("gene_symbol").set_index("gene_symbol").gene_id.astype(str).to_dict();am=p.set_index("gene_symbol").alignment.to_dict();cols={"Epiblast-aligned":EPI,"Lineage-aligned":LIN,"Mixed":MIX}
 for mod,genes in MODULES.items():
  rows=[]
  for gene in genes:
   if gene not in am or gene not in ids or ids[gene] not in x.index or gene not in em.index:continue
   v=x.loc[ids[gene]];de=em.loc[gene];rows.append({"gene_symbol":gene,"initial_mean":v[g.eq("Initial")].mean(),"initial_sd":v[g.eq("Initial")].std(),"dynamic_mean":v[g.eq("Dynamic")].mean(),"dynamic_sd":v[g.eq("Dynamic")].std(),"adjusted_p_value":de.adjusted_p_value,"pooled_alignment":am[gene]})
  t=pd.DataFrame(rows)
  if t.empty:continue
  t.to_csv(o/"source_data"/f"module_{safe(mod)}.csv",index=False);z=t.iloc[::-1];y=np.arange(len(z));f,a=plt.subplots(figsize=(18,max(9,.78*len(z)+5)),layout="constrained");a.barh(y-.17,z.initial_mean,.34,xerr=z.initial_sd,color=INIT,edgecolor="#AAA");a.barh(y+.17,z.dynamic_mean,.34,xerr=z.dynamic_sd,color=[cols[v] for v in z.pooled_alignment],alpha=.76);a.set_yticks(y);a.set_yticklabels(z.gene_symbol,fontweight="bold");a.set_xlabel("Mean log2 CPM +/- SD");a.set_title(mod+"\nDynamic bars colored by pooled developmental alignment",pad=30);mx=np.nanmax(np.r_[z.initial_mean+z.initial_sd.fillna(0),z.dynamic_mean+z.dynamic_sd.fillna(0)]);a.set_xlim(0,mx*1.2)
  for i,(_,r) in enumerate(z.iterrows()):
   if stars(r.adjusted_p_value):a.text(max(r.initial_mean+(r.initial_sd if np.isfinite(r.initial_sd) else 0),r.dynamic_mean+(r.dynamic_sd if np.isfinite(r.dynamic_sd) else 0))+mx*.02,i,stars(r.adjusted_p_value),fontweight="bold")
  a.spines[["top","right"]].set_visible(False);save(f,o/"module_barplots"/safe(mod))
def countbar(p,o):
 z=p[p.alignment.ne("Mixed")].groupby("alignment").size();c=int(z.get("Epiblast-aligned",0));d=int(z.get("Lineage-aligned",0));pd.DataFrame({"alignment":["Epiblast-aligned","Lineage-aligned"],"n_genes":[c,d]}).to_csv(o/"source_data"/"pooled_alignment_gene_counts.csv",index=False);f,a=plt.subplots(figsize=(8,9),layout="constrained");a.bar([0,1],[c,-d],color=[EPI,LIN],alpha=.76);a.axhline(0,c="black");a.set_xticks([0,1]);a.set_xticklabels(["Epiblast-aligned","Lineage-aligned"],rotation=25,ha="right");a.set_ylabel("Gene count");a.set_title("Pooled developmental alignment",pad=30);save(f,o/"pooled"/"pooled_alignment_counts")
def getsets(o,lib):
 p=o/"ora"/f"{safe(lib)}.gmt";p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():return {q[0]:set(map(str.upper,q[2:])) for q in (x.split("\t") for x in p.read_text().splitlines())}
 import gseapy as gp
 s=gp.get_library(name=lib,organism="Human");p.write_text("\n".join("\t".join([k,"na"]+list(v)) for k,v in s.items()));return {k:set(map(str.upper,v)) for k,v in s.items()}
def oratab(genes,bg,ss):
 R=[];M=len(bg);N=len(genes)
 for term,s in ss.items():
  s=s&bg;k=len(genes&s);nn=len(s)
  if k>=2 and 10<=nn<=500:R.append([term,hypergeom.sf(k-1,M,nn,N),k,(k/N)/(nn/M),";".join(sorted(genes&s))])
 z=pd.DataFrame(R,columns=["term","p_value","overlap_count","enrichment_ratio","genes"])
 if not z.empty:z["adjusted_p_value"]=multipletests(z.p_value,method="fdr_bh")[1];z=z.sort_values(["adjusted_p_value","enrichment_ratio"],ascending=[True,False])
 return z
def ocolor(q,al):
 if q>=.05:return GRAY
 t=np.clip((-np.log10(max(q,1e-12))-1.301)/4.699,0,1);return mpl.colormaps["Purples" if al=="Epiblast-aligned" else "Oranges"](.35+.6*t)
def oraplots(dataset,e,o,lib,scope):
 bg=set(e.gene_symbol);ss=getsets(o,lib)
 for al,slug in [("Epiblast-aligned","convergent"),("Lineage-aligned","divergent")]:
  z=oratab(set(dataset.loc[dataset.alignment.eq(al),"gene_symbol"]),bg,ss);z["alignment"]=al;z.to_csv(o/"source_data"/f"ORA_{safe(scope)}_{slug}_all.csv",index=False)
  if z.empty:continue
  q=pd.concat([z[z.adjusted_p_value<.05].head(12),z[z.adjusted_p_value>=.05].head(4)]).sort_values("enrichment_ratio");q.to_csv(o/"source_data"/f"ORA_{safe(scope)}_{slug}_displayed.csv",index=False);f,a=plt.subplots(figsize=(18,max(9,.7*len(q)+5)),layout="constrained");y=np.arange(len(q));a.barh(y,q.enrichment_ratio,color=[ocolor(v,al) for v in q.adjusted_p_value],edgecolor="white",alpha=.86);a.set_yticks(y);a.set_yticklabels(q.term.str.replace("_"," ").str.slice(0,72),fontsize=20,fontweight="bold");a.set_xlabel("Over-representation enrichment ratio");a.set_title(f"{scope}: {al} genes",pad=30);a.axvline(1,c=GRAY,ls="--");a.spines[["top","right"]].set_visible(False);save(f,o/"ora"/safe(scope)/slug)
def main():
 a=args();style();a.output_dir.mkdir(parents=True,exist_ok=True);(a.output_dir/"source_data").mkdir(exist_ok=True)
 if any(a.output_dir.rglob("*.png")) and not a.overwrite:raise FileExistsError(f"Outputs exist under {a.output_dir}; use --overwrite")
 c=load_cross(a.source_dir);p=pooled(c);e=expdata(a.all_tested);c.to_csv(a.output_dir/"source_data"/"lineage_specific_joint_moderate.csv.gz",index=False,compression="gzip");p.to_csv(a.output_dir/"source_data"/"pooled_developmental_alignment.csv",index=False)
 for lin,d in c.groupby("lineage",sort=False):volcano(d,e,a.output_dir,a.top_labels,lin);heatmap(d,a.output_dir,a.top_heatmap,lin);oraplots(d,e,a.output_dir,a.ora_library,lin)
 volcano(p,e,a.output_dir,a.top_labels,"Pooled developmental programs");heatmap(p,a.output_dir,a.top_heatmap,"Pooled developmental programs");oraplots(p,e,a.output_dir,a.ora_library,"Pooled developmental programs");module_bars(p,e,a.counts,a.output_dir);countbar(p,a.output_dir)
 f,x=plt.subplots(figsize=(16,3.2));x.axis("off");x.legend([Patch(facecolor=INIT,edgecolor="#AAA"),Patch(facecolor=EPI,alpha=.76),Patch(facecolor=LIN,alpha=.76),Patch(facecolor=MIX,alpha=.76),Patch(facecolor=GRAY)],["Initial","Epiblast-aligned / convergent","Lineage-aligned / divergent","Mixed across lineages","ORA FDR >= 0.05"],loc="center",ncol=3,frameon=False,prop={"size":20,"weight":"bold"});save(f,a.output_dir/"legends"/"cross_analysis_legend")
 m={"workflow":"cross_analysis_dynamic_initial_2_4_1","timestamp_utc":datetime.now(timezone.utc).isoformat(),"volcano_y_limits":{"convergent":[0,40],"divergent":[-40,0]},"volcano_clipping":"Values beyond limits clipped for display only; raw values retained in source CSVs.","title_spacing":"Volcano axes top=0.82, title pad=34, save padding=0.55 inches; other titles pad=30.","output":"300 DPI PNG only"};(a.output_dir/"cross_analysis_dynamic_initial_manifest_2_4_1.json").write_text(json.dumps(m,indent=2));print(f"[COMPLETE] robust V2.4.1 written to {a.output_dir}")
if __name__=="__main__":main()
