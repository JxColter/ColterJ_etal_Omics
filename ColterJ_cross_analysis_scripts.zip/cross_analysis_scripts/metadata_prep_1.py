#!/usr/bin/env python3
"""Prepare Tyser E-MTAB-9388 developmental annotations for downstream analysis.

Executive annotation choice
---------------------------
Primary labels use pred_annotation, not raw_annotation or sub_pred_annotation.
- raw_annotation is retained as the original/manual label for provenance.
- pred_annotation is used as the stable analysis-level cell-state label because
  it resolves several ambiguous raw assignments while retaining biologically
  useful gastrulation classes.
- sub_pred_annotation is retained as a secondary fine label, but it is not the
  primary grouping variable because it only adds detail for selected states
  (for example Late_EPI and Late_Hypoblast) and otherwise largely duplicates
  pred_annotation.

The script does not silently coerce low-confidence predictions into a lineage.
Predicted labels equal to 'Ambiguous' or below the requested confidence cutoff
are marked analysis_eligible=False. Original labels remain available.

Inputs under reference_data/
----------------------------
Tyser_2021_PMID_34789876_audit_1_metadata_snapshot.csv
Tyser_2021_PMID_34789876_log1p_cpm_1.h5ad

Outputs under reference_data/
-----------------------------
Tyser_2021_PMID_34789876_annotation_map_1.csv.gz
Tyser_2021_PMID_34789876_annotation_summary_1.csv
Tyser_2021_PMID_34789876_annotation_discordance_1.csv.gz
Tyser_2021_PMID_34789876_log1p_cpm_annotated_1.h5ad
Tyser_2021_PMID_34789876_metadata_prep_1_report.json
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
import anndata as ad
import numpy as np
import pandas as pd

PROJECT=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
REF=PROJECT/"reference_data"
BASE="Tyser_2021_PMID_34789876"
VERSION="1"

# Descriptive names preserve the source label while improving figure readability.
DISPLAY={
 "Epiblast":"Epiblast",
 "PriS":"Primitive streak",
 "Mesoderm":"Mesoderm",
 "AdvMes":"Advanced mesoderm",
 "Axial Mes":"Axial mesoderm",
 "DE":"Definitive endoderm",
 "HEP":"Hemato-endothelial progenitor",
 "Erythroblasts":"Erythroblasts",
 "Amnion":"Amnion",
 "ExE_Mes":"Extraembryonic mesoderm",
 "YSE":"Yolk sac endoderm",
 "Hypoblast":"Hypoblast",
 "Ambiguous":"Ambiguous",
}
# Analysis contexts, not claims of exact developmental equivalence.
CONTEXT={
 "Epiblast":"pluripotent_anchor",
 "PriS":"lineage_transition",
 "Mesoderm":"embryonic_mesoderm",
 "AdvMes":"embryonic_mesoderm",
 "Axial Mes":"embryonic_mesoderm",
 "DE":"embryonic_endoderm",
 "HEP":"downstream_mesoderm",
 "Erythroblasts":"downstream_mesoderm",
 "Amnion":"extraembryonic_or_amnion",
 "ExE_Mes":"extraembryonic_or_amnion",
 "YSE":"extraembryonic_endoderm",
 "Hypoblast":"extraembryonic_endoderm",
 "Ambiguous":"ambiguous",
}

def args():
 p=argparse.ArgumentParser();p.add_argument("--reference-dir",type=Path,default=REF);p.add_argument("--confidence",type=float,default=.50);p.add_argument("--overwrite",action="store_true");return p.parse_args()
def clean(s):return s.astype(str).str.strip().replace({"":"NA","nan":"NA","None":"NA"})
def main():
 a=args();r=a.reference_dir;meta_path=r/f"{BASE}_audit_1_metadata_snapshot.csv";h5_path=r/f"{BASE}_log1p_cpm_1.h5ad";out_map=r/f"{BASE}_annotation_map_{VERSION}.csv.gz";out_h5=r/f"{BASE}_log1p_cpm_annotated_{VERSION}.h5ad"
 if not meta_path.exists():raise FileNotFoundError(meta_path)
 if not h5_path.exists():raise FileNotFoundError(h5_path)
 meta=pd.read_csv(meta_path,dtype=str)
 req=["cell","devTime","raw_annotation","pred_annotation","sub_pred_annotation","prediction_score_max"]
 miss=[x for x in req if x not in meta.columns]
 if miss:raise ValueError(f"Missing required metadata columns: {miss}")
 for c in ["cell","devTime","raw_annotation","pred_annotation","sub_pred_annotation"]:meta[c]=clean(meta[c])
 meta["prediction_score_max"]=pd.to_numeric(meta["prediction_score_max"],errors="coerce")
 if meta.cell.eq("NA").any() or meta.cell.duplicated().any():raise ValueError("Cell identifiers are empty or duplicated")
 # Primary decision: pred_annotation. Fine label remains secondary only.
 meta["annotation_primary_source"]="pred_annotation"
 meta["annotation_primary"]=meta.pred_annotation
 meta["annotation_fine"]=meta.sub_pred_annotation
 meta["annotation_original"]=meta.raw_annotation
 meta["annotation_display"]=meta.annotation_primary.map(DISPLAY).fillna(meta.annotation_primary.str.replace("_"," ",regex=False))
 meta["developmental_context"]=meta.annotation_primary.map(CONTEXT).fillna("other")
 meta["raw_pred_agreement"]=meta.raw_annotation.eq(meta.pred_annotation)
 meta["pred_subpred_agreement"]=meta.pred_annotation.eq(meta.sub_pred_annotation)
 meta["is_ambiguous_prediction"]=meta.pred_annotation.eq("Ambiguous")
 meta["passes_prediction_confidence"]=meta.prediction_score_max.ge(a.confidence)
 meta["analysis_eligible"]=(~meta.is_ambiguous_prediction)&meta.passes_prediction_confidence
 meta["exclusion_reason"]=np.select([meta.is_ambiguous_prediction,~meta.passes_prediction_confidence],["ambiguous_prediction",f"prediction_score_below_{a.confidence:g}"],default="included")
 cols=["cell","devTime","annotation_primary","annotation_display","annotation_fine","annotation_original","prediction_score_max","developmental_context","analysis_eligible","exclusion_reason","raw_pred_agreement","pred_subpred_agreement"]
 amap=meta[cols].copy();amap.to_csv(out_map,index=False,compression="gzip")
 summary=(amap.groupby(["annotation_primary","annotation_display","developmental_context","analysis_eligible"],dropna=False).size().rename("n_cells").reset_index().sort_values(["analysis_eligible","n_cells"],ascending=[False,False]));summary.to_csv(r/f"{BASE}_annotation_summary_{VERSION}.csv",index=False)
 amap.loc[(~amap.raw_pred_agreement)|(~amap.pred_subpred_agreement)].to_csv(r/f"{BASE}_annotation_discordance_{VERSION}.csv.gz",index=False,compression="gzip")
 adata=ad.read_h5ad(h5_path)
 missing=sorted(set(adata.obs_names)-set(amap.cell));extra=sorted(set(amap.cell)-set(adata.obs_names))
 if missing or extra:raise ValueError(f"H5AD/annotation mismatch: missing annotations={len(missing)}, extra annotations={len(extra)}")
 add=amap.set_index("cell").loc[adata.obs_names]
 for c in add.columns:adata.obs[c]=add[c].values
 adata.uns["annotation_primary_source"]="pred_annotation"
 adata.uns["annotation_fine_source"]="sub_pred_annotation"
 adata.uns["annotation_original_source"]="raw_annotation"
 adata.uns["annotation_confidence_cutoff"]=float(a.confidence)
 adata.uns["annotation_policy"]="Predicted labels are primary; ambiguous or low-confidence predictions are excluded from developmental contrasts but preserved in the object."
 if out_h5.exists() and not a.overwrite:raise FileExistsError(f"Output exists; use --overwrite: {out_h5}")
 adata.write_h5ad(out_h5,compression="gzip")
 report={"input_metadata":str(meta_path),"input_h5ad":str(h5_path),"primary_choice":"pred_annotation","rationale":"Stable analysis-level prediction with confidence score and explicit ambiguous class; raw retained for provenance; sub_pred retained as selective fine annotation.","confidence_cutoff":a.confidence,"n_cells":int(len(amap)),"n_analysis_eligible":int(amap.analysis_eligible.sum()),"n_excluded":int((~amap.analysis_eligible).sum()),"n_raw_pred_discordant":int((~amap.raw_pred_agreement).sum()),"n_pred_subpred_discordant":int((~amap.pred_subpred_agreement).sum()),"annotation_map":str(out_map),"annotated_h5ad":str(out_h5)}
 (r/f"{BASE}_metadata_prep_{VERSION}_report.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
 print(json.dumps(report,indent=2))
if __name__=="__main__":main()
