#!/usr/bin/env python3
"""Audit curated embryo reference datasets and create log1p-CPM H5AD files.

Expected project layout
-----------------------
<PROJECT>/
  scripts/reference_data_audit_1.py
  reference_data/
    Petropoulos_2016_PMID_27062923.counts.gz
    Petropoulos_2016_PMID_27062923.meta.tsv
    Tyser_2021_PMID_34789876.counts.gz
    Tyser_2021_PMID_34789876.meta.tsv

For each dataset this script:
1. Audits count and metadata structure without changing the input files.
2. Determines count-matrix orientation by matching metadata sample identifiers.
3. Rejects duplicate sample IDs, unmatched samples, invalid counts, negative values,
   non-integer counts, zero-library cells, duplicate genes, and empty matrices.
4. Saves dataset-specific audit tables and a text report under reference_data/.
5. Creates a cells x genes AnnData object only when all critical checks pass.
6. Stores raw integer counts in adata.layers['counts'].
7. Stores log1p(CPM) values in adata.X and writes a versioned .h5ad file.

No filtering, clustering, annotation changes, integration, or downsampling are
performed. The original metadata columns are retained in adata.obs.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse

PROJECT = Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
REFERENCE_DIR = PROJECT / "reference_data"
TARGET_SUM = 1_000_000.0
VERSION = "1"

DATASETS = [
    {
        "name": "Petropoulos_2016_PMID_27062923",
        "accession": "E-MTAB-3929",
        "counts": "Petropoulos_2016_PMID_27062923.counts.gz",
        "metadata": "Petropoulos_2016_PMID_27062923.meta.tsv",
    },
    {
        "name": "Tyser_2021_PMID_34789876",
        "accession": "E-MTAB-9388",
        "counts": "Tyser_2021_PMID_34789876.counts.gz",
        "metadata": "Tyser_2021_PMID_34789876.meta.tsv",
    },
]

SAMPLE_ID_CANDIDATES = [
    "sample_id", "sample", "cell_id", "cell", "barcode", "well", "name",
    "library_id", "run", "run_id", "accession", "id",
]
GENE_ID_CANDIDATES = [
    "gene_id", "ensembl_gene_id", "gene", "gene_symbol", "symbol", "feature",
]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--reference-dir", type=Path, default=REFERENCE_DIR)
    p.add_argument("--target-sum", type=float, default=TARGET_SUM)
    p.add_argument("--overwrite", action="store_true")
    return p.parse_args()


def clean_label(x: object) -> str:
    return str(x).strip().replace("\ufeff", "")


def make_unique(values: list[str]) -> list[str]:
    seen: dict[str, int] = {}
    out: list[str] = []
    for value in values:
        if value not in seen:
            seen[value] = 0
            out.append(value)
        else:
            seen[value] += 1
            out.append(f"{value}__duplicate_{seen[value]}")
    return out


def read_metadata(path: Path) -> pd.DataFrame:
    meta = pd.read_csv(path, sep="\t", dtype=str, keep_default_na=False)
    meta.columns = [clean_label(c) for c in meta.columns]
    return meta


def read_counts(path: Path) -> pd.DataFrame:
    # sep=None enables delimiter inference for a .gz file that may be TSV or CSV.
    counts = pd.read_csv(path, sep=None, engine="python", compression="infer", dtype=str)
    counts.columns = [clean_label(c) for c in counts.columns]
    if counts.empty:
        raise ValueError("Count matrix is empty")
    return counts


def choose_metadata_id(meta: pd.DataFrame, count_row_ids: set[str], count_col_ids: set[str]) -> tuple[str, dict]:
    candidates = []
    for col in meta.columns:
        vals = meta[col].map(clean_label)
        nonempty = set(vals[vals.ne("")])
        row_overlap = len(nonempty & count_row_ids)
        col_overlap = len(nonempty & count_col_ids)
        candidates.append({
            "column": col,
            "n_unique_nonempty": int(vals[vals.ne("")].nunique()),
            "n_duplicate_nonempty": int(vals[vals.ne("")].duplicated().sum()),
            "row_overlap": row_overlap,
            "column_overlap": col_overlap,
            "best_overlap": max(row_overlap, col_overlap),
        })
    table = pd.DataFrame(candidates).sort_values(
        ["best_overlap", "n_unique_nonempty"], ascending=[False, False]
    )
    if table.empty or int(table.iloc[0]["best_overlap"]) == 0:
        lowered = {c.lower(): c for c in meta.columns}
        for key in SAMPLE_ID_CANDIDATES:
            if key in lowered:
                return lowered[key], {"candidate_table": table, "selection_reason": "name_fallback"}
        raise ValueError("No metadata column could be matched to count-matrix sample labels")
    return str(table.iloc[0]["column"]), {"candidate_table": table, "selection_reason": "maximum_overlap"}


def find_gene_column(counts: pd.DataFrame) -> str:
    lowered = {c.lower(): c for c in counts.columns}
    for key in GENE_ID_CANDIDATES:
        if key in lowered:
            return lowered[key]
    return counts.columns[0]


def numeric_fraction(series: pd.Series) -> float:
    if len(series) == 0:
        return 0.0
    return float(pd.to_numeric(series, errors="coerce").notna().mean())


def audit_dataset(spec: dict, reference_dir: Path, target_sum: float, overwrite: bool) -> dict:
    name = spec["name"]
    counts_path = reference_dir / spec["counts"]
    meta_path = reference_dir / spec["metadata"]
    prefix = reference_dir / f"{name}_audit_{VERSION}"
    h5ad_path = reference_dir / f"{name}_log1p_cpm_{VERSION}.h5ad"

    report: dict = {
        "dataset": name,
        "accession": spec["accession"],
        "counts_file": str(counts_path),
        "metadata_file": str(meta_path),
        "target_sum": target_sum,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "critical_failures": [],
        "warnings": [],
    }

    if not counts_path.exists():
        report["critical_failures"].append(f"Missing counts file: {counts_path}")
    if not meta_path.exists():
        report["critical_failures"].append(f"Missing metadata file: {meta_path}")
    if report["critical_failures"]:
        return report

    meta = read_metadata(meta_path)
    counts_raw = read_counts(counts_path)
    report["metadata_rows"] = int(meta.shape[0])
    report["metadata_columns"] = int(meta.shape[1])
    report["count_table_rows_raw"] = int(counts_raw.shape[0])
    report["count_table_columns_raw"] = int(counts_raw.shape[1])

    gene_col = find_gene_column(counts_raw)
    first_col = counts_raw.columns[0]
    candidate_gene_ids = set(counts_raw[gene_col].map(clean_label))
    count_column_ids = set(map(clean_label, counts_raw.columns)) - {gene_col}

    # Also consider the first column as row IDs. This supports gene x cell files.
    row_ids = set(counts_raw[first_col].map(clean_label))
    sample_col, selection = choose_metadata_id(meta, row_ids, count_column_ids)
    selection["candidate_table"].to_csv(f"{prefix}_metadata_id_candidates.csv", index=False)
    report["metadata_sample_id_column"] = sample_col
    report["metadata_id_selection_reason"] = selection["selection_reason"]

    meta[sample_col] = meta[sample_col].map(clean_label)
    empty_meta_ids = int(meta[sample_col].eq("").sum())
    duplicate_meta_ids = int(meta.loc[meta[sample_col].ne(""), sample_col].duplicated().sum())
    report["empty_metadata_sample_ids"] = empty_meta_ids
    report["duplicate_metadata_sample_ids"] = duplicate_meta_ids
    if empty_meta_ids:
        report["critical_failures"].append(f"Metadata contains {empty_meta_ids} empty sample IDs")
    if duplicate_meta_ids:
        report["critical_failures"].append(f"Metadata contains {duplicate_meta_ids} duplicate sample IDs")

    meta_ids = set(meta[sample_col])
    column_overlap = len(meta_ids & count_column_ids)
    row_overlap = len(meta_ids & row_ids)
    report["metadata_to_count_column_overlap"] = int(column_overlap)
    report["metadata_to_count_row_overlap"] = int(row_overlap)

    if column_overlap >= row_overlap and column_overlap > 0:
        orientation = "genes_by_cells"
        genes = counts_raw[gene_col].map(clean_label).tolist()
        value_df = counts_raw.drop(columns=[gene_col]).copy()
        value_df.columns = [clean_label(c) for c in value_df.columns]
        value_df.index = genes
        counts_genes_cells = value_df
    elif row_overlap > 0:
        orientation = "cells_by_genes"
        sample_index_col = first_col
        samples = counts_raw[sample_index_col].map(clean_label).tolist()
        value_df = counts_raw.drop(columns=[sample_index_col]).copy()
        value_df.index = samples
        value_df.columns = [clean_label(c) for c in value_df.columns]
        counts_genes_cells = value_df.T
    else:
        orientation = "unresolved"
        counts_genes_cells = pd.DataFrame()
        report["critical_failures"].append("Could not resolve count-matrix orientation from metadata IDs")
    report["count_matrix_orientation"] = orientation

    if not counts_genes_cells.empty:
        counts_genes_cells.index = [clean_label(x) for x in counts_genes_cells.index]
        counts_genes_cells.columns = [clean_label(x) for x in counts_genes_cells.columns]
        duplicate_count_samples = int(pd.Index(counts_genes_cells.columns).duplicated().sum())
        duplicate_genes = int(pd.Index(counts_genes_cells.index).duplicated().sum())
        report["duplicate_count_sample_ids"] = duplicate_count_samples
        report["duplicate_gene_ids"] = duplicate_genes
        if duplicate_count_samples:
            report["critical_failures"].append(f"Count matrix contains {duplicate_count_samples} duplicate sample IDs")
        if duplicate_genes:
            report["critical_failures"].append(f"Count matrix contains {duplicate_genes} duplicate gene IDs")

        count_samples = set(counts_genes_cells.columns)
        missing_in_counts = sorted(meta_ids - count_samples)
        missing_in_metadata = sorted(count_samples - meta_ids)
        pd.DataFrame({"sample_id": missing_in_counts}).to_csv(f"{prefix}_metadata_samples_missing_from_counts.csv", index=False)
        pd.DataFrame({"sample_id": missing_in_metadata}).to_csv(f"{prefix}_count_samples_missing_from_metadata.csv", index=False)
        report["metadata_samples_missing_from_counts"] = len(missing_in_counts)
        report["count_samples_missing_from_metadata"] = len(missing_in_metadata)
        if missing_in_counts:
            report["critical_failures"].append(f"{len(missing_in_counts)} metadata samples are absent from counts")
        if missing_in_metadata:
            report["critical_failures"].append(f"{len(missing_in_metadata)} count samples are absent from metadata")

        numeric = counts_genes_cells.apply(pd.to_numeric, errors="coerce")
        nonnumeric_cells = int(numeric.isna().sum().sum())
        report["nonnumeric_count_values"] = nonnumeric_cells
        if nonnumeric_cells:
            report["critical_failures"].append(f"Count matrix contains {nonnumeric_cells} nonnumeric or missing values")
        if not nonnumeric_cells:
            array = numeric.to_numpy(dtype=np.float64)
            negative = int((array < 0).sum())
            noninteger = int((np.abs(array - np.rint(array)) > 1e-8).sum())
            report["negative_count_values"] = negative
            report["noninteger_count_values"] = noninteger
            if negative:
                report["critical_failures"].append(f"Count matrix contains {negative} negative values")
            if noninteger:
                report["critical_failures"].append(f"Count matrix contains {noninteger} noninteger values; file may not contain raw counts")

            library_sizes = numeric.sum(axis=0)
            detected_genes = numeric.gt(0).sum(axis=0)
            qc = pd.DataFrame({
                "sample_id": numeric.columns,
                "library_size": library_sizes.values,
                "detected_genes": detected_genes.values,
            })
            qc.to_csv(f"{prefix}_sample_qc.csv", index=False)
            zero_libraries = int(library_sizes.eq(0).sum())
            report["zero_library_samples"] = zero_libraries
            report["n_genes"] = int(numeric.shape[0])
            report["n_samples"] = int(numeric.shape[1])
            report["library_size_min"] = float(library_sizes.min())
            report["library_size_median"] = float(library_sizes.median())
            report["library_size_max"] = float(library_sizes.max())
            report["detected_genes_min"] = int(detected_genes.min())
            report["detected_genes_median"] = float(detected_genes.median())
            report["detected_genes_max"] = int(detected_genes.max())
            if zero_libraries:
                report["critical_failures"].append(f"Count matrix contains {zero_libraries} zero-library samples")

            # Metadata audit: unique values and missingness for every field.
            audit_rows = []
            for col in meta.columns:
                values = meta[col].astype(str)
                missing = values.eq("").sum()
                examples = " | ".join(values[values.ne("")].drop_duplicates().head(10).tolist())
                audit_rows.append({
                    "column": col,
                    "dtype_read": str(meta[col].dtype),
                    "n_missing_or_empty": int(missing),
                    "fraction_missing_or_empty": float(missing / max(len(meta), 1)),
                    "n_unique_nonempty": int(values[values.ne("")].nunique()),
                    "example_values": examples,
                })
            pd.DataFrame(audit_rows).to_csv(f"{prefix}_metadata_columns.csv", index=False)
            meta.to_csv(f"{prefix}_metadata_snapshot.csv", index=False)

            if not report["critical_failures"]:
                if h5ad_path.exists() and not overwrite:
                    report["warnings"].append(f"H5AD already exists and was not overwritten: {h5ad_path}")
                else:
                    ordered_meta = meta.set_index(sample_col).loc[numeric.columns].copy()
                    ordered_meta.index = ordered_meta.index.astype(str)
                    ordered_meta.index.name = "sample_id"
                    ordered_meta.columns = make_unique([clean_label(c) for c in ordered_meta.columns])
                    counts_cells_genes = numeric.T.to_numpy(dtype=np.float32)
                    cpm = counts_cells_genes / counts_cells_genes.sum(axis=1, keepdims=True) * target_sum
                    log1p_cpm = np.log1p(cpm).astype(np.float32)
                    var = pd.DataFrame(index=pd.Index(numeric.index.astype(str), name="gene_id"))
                    adata = ad.AnnData(
                        X=sparse.csr_matrix(log1p_cpm),
                        obs=ordered_meta,
                        var=var,
                    )
                    adata.layers["counts"] = sparse.csr_matrix(np.rint(counts_cells_genes).astype(np.int64))
                    adata.obs["library_size_raw"] = library_sizes.loc[adata.obs_names].astype(float).values
                    adata.obs["detected_genes_raw"] = detected_genes.loc[adata.obs_names].astype(int).values
                    adata.uns["dataset_name"] = name
                    adata.uns["accession"] = spec["accession"]
                    adata.uns["normalization"] = "log1p(CPM)"
                    adata.uns["normalization_target_sum"] = float(target_sum)
                    adata.uns["counts_layer"] = "raw integer counts"
                    adata.uns["audit_version"] = VERSION
                    adata.write_h5ad(h5ad_path, compression="gzip")
                    report["h5ad_written"] = str(h5ad_path)
                    report["h5ad_shape_cells_by_genes"] = [int(adata.n_obs), int(adata.n_vars)]

    report["audit_passed"] = len(report["critical_failures"]) == 0
    with open(f"{prefix}_report.json", "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    with open(f"{prefix}_report.txt", "w", encoding="utf-8") as fh:
        fh.write(f"Dataset: {name}\n")
        fh.write(f"Accession: {spec['accession']}\n")
        fh.write(f"Audit passed: {report['audit_passed']}\n")
        fh.write(f"Orientation: {report.get('count_matrix_orientation', 'not assessed')}\n")
        fh.write(f"Metadata sample ID column: {report.get('metadata_sample_id_column', 'not assessed')}\n")
        fh.write(f"Samples: {report.get('n_samples', 'not assessed')}\n")
        fh.write(f"Genes: {report.get('n_genes', 'not assessed')}\n")
        fh.write("Critical failures:\n")
        for item in report["critical_failures"]:
            fh.write(f"  - {item}\n")
        fh.write("Warnings:\n")
        for item in report["warnings"]:
            fh.write(f"  - {item}\n")
    return report


def main() -> int:
    a = parse_args()
    a.reference_dir.mkdir(parents=True, exist_ok=True)
    all_reports = []
    for spec in DATASETS:
        print(f"[AUDIT] {spec['name']}")
        try:
            report = audit_dataset(spec, a.reference_dir, a.target_sum, a.overwrite)
        except Exception as exc:
            report = {
                "dataset": spec["name"],
                "accession": spec["accession"],
                "audit_passed": False,
                "critical_failures": [f"Unhandled error: {type(exc).__name__}: {exc}"],
                "warnings": [],
            }
        all_reports.append(report)
        print(f"  passed={report.get('audit_passed', False)}")
        for failure in report.get("critical_failures", []):
            print(f"  ERROR: {failure}")
    summary = pd.DataFrame([{
        "dataset": r.get("dataset"),
        "accession": r.get("accession"),
        "audit_passed": r.get("audit_passed", False),
        "n_samples": r.get("n_samples"),
        "n_genes": r.get("n_genes"),
        "orientation": r.get("count_matrix_orientation"),
        "metadata_sample_id_column": r.get("metadata_sample_id_column"),
        "n_critical_failures": len(r.get("critical_failures", [])),
        "h5ad_written": r.get("h5ad_written", ""),
    } for r in all_reports])
    summary.to_csv(a.reference_dir / f"reference_data_audit_summary_{VERSION}.csv", index=False)
    passed = bool(summary.audit_passed.all()) if not summary.empty else False
    print(f"[COMPLETE] all_datasets_passed={passed}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
