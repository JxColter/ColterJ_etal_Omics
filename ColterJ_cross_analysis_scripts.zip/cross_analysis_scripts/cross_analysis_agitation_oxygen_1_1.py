#!/usr/bin/env python3
"""Oxygen module-barplot supplement for cross-analysis v1.1.

This focused revision reads the completed V1 oxygen cross-analysis outputs and
adds Hypoxia-versus-Normoxia module barplots without rerunning volcano, heatmap,
reinforcement, or ORA analyses.

Input:
  cross_analysis/agitation_oxygen/1/Normoxia_vs_Hypoxia_pooled/source_data/
    pooled_developmental_alignment.csv
  analysis/1_4_1/primary_collapsed/
    differential_expression/Normoxia_vs_Hypoxia_pooled/all_tested_genes.csv
    counts/filtered_counts.csv

Output:
  cross_analysis/agitation_oxygen/1_1/Normoxia_vs_Hypoxia_pooled/
    module_barplots/*.png
    source_data/*.csv
    legends/oxygen_module_bar_legend.png

Hypoxia is the light-gray reference bar. Normoxia bars are colored by pooled
alignment: purple for Epiblast-aligned, orange for lineage-aligned, and gray for
mixed alignment across primitive-streak, mesoderm, and definitive-endoderm
references. All figures are 300 DPI PNG only.
"""
from __future__ import annotations
import argparse,json,re,warnings
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.patches import Patch
warnings.filterwarnings("ignore",category=RuntimeWarning)

PROJECT=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
V1=PROJECT/"cross_analysis"/"agitation_oxygen"/"1"/"Normoxia_vs_Hypoxia_pooled"
OUT=PROJECT/"cross_analysis"/"agitation_oxygen"/"1_1"/"Normoxia_vs_Hypoxia_pooled"
BASE=PROJECT/"analysis"/"1_4_1"/"primary_collapsed"
ALIGNMENT=V1/"source_data"/"pooled_developmental_alignment.csv"
DEG=BASE/"differential_expression"/"Normoxia_vs_Hypoxia_pooled"/"all_tested_genes.csv"
COUNTS=BASE/"counts"/"filtered_counts.csv"
DPI=300
HYPOXIA="#E6E6E6";EPI="#7B3294";LINEAGE="#D95F02";MIXED="#7A7A7A"
MODULES={
 "Metabolic adaptation":["PDK1","COX11","LPCAT3","SRR","SIRT4","PANK1","PYCR1","NDUFAF3","GYS1","HMGCR"],
 "Developmental signaling":["FZD2","GRM5","PKDCC","KLF7","NODAL","SOX12","EMX1","HMGA1","CUX1"],
 "Membrane, adhesion and organization":["CLIC5","JAKMIP2","PXN","SLC4A5","EDIL3","ZYX","PTK2","AJM1","CRB2"],
 "Protein turnover and stress response":["CTSB","TCP1","PDCD4","HSPA5","HSPD1","SQSTM1","ATG7"],
 "Transcriptional and regulatory control":["HEXIM1","HEXIM2","PDE4C","HIF1A-AS2","NETO1-DT","AATBC","DNMT1","JARID2","SMARCA4","CHD7"]
}

def args():
 p=argparse.ArgumentParser();p.add_argument("--alignment",type=Path,default=ALIGNMENT);p.add_argument("--all-tested",type=Path,default=DEG);p.add_argument("--counts",type=Path,default=COUNTS);p.add_argument("--output-dir",type=Path,default=OUT);p.add_argument("--overwrite",action="store_true");return p.parse_args()
def safe(x):return re.sub(r"[^A-Za-z0-9_]+","_",str(x)).strip("_")
def style():
 mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":26,"axes.titlesize":36,"axes.titleweight":"bold","axes.labelsize":31,"axes.labelweight":"bold","xtick.labelsize":23,"ytick.labelsize":23,"axes.linewidth":2.7,"savefig.dpi":DPI})
def save(fig,path):
 path.parent.mkdir(parents=True,exist_ok=True);fig.savefig(path.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.45);plt.close(fig)
def parse_sample(x):
 raw=str(x);core=re.sub(r"_S\d+_L\d{3}_\d+(?:\.tabular)?$","",raw,flags=re.I);core=re.sub(r"_dup$","",core,flags=re.I).lower();m=re.fullmatch(r"([hn])(100|120|150)d(2|4)s\d+",core)
 if not m:return None
 return "Normoxia" if m.group(1)=="n" else "Hypoxia"
def stars(q):return "***" if q<.001 else "**" if q<.01 else "*" if q<.05 else ""
def main():
 a=args();style()
 for p in [a.alignment,a.all_tested,a.counts]:
  if not p.exists():raise FileNotFoundError(p)
 a.output_dir.mkdir(parents=True,exist_ok=True);src=a.output_dir/"source_data";src.mkdir(exist_ok=True)
 if any(a.output_dir.rglob("*.png")) and not a.overwrite:raise FileExistsError(f"Outputs exist under {a.output_dir}; use --overwrite")
 align=pd.read_csv(a.alignment);align["gene_symbol"]=align.gene_symbol.astype(str).str.upper()
 if "alignment" not in align.columns:raise ValueError(f"Missing alignment column: {a.alignment}")
 amap=align.sort_values("exp_adjusted_p_value").drop_duplicates("gene_symbol").set_index("gene_symbol").alignment.to_dict()
 de=pd.read_csv(a.all_tested,dtype={"gene_id":str});de["gene_symbol"]=de.gene_symbol.fillna(de.gene_id).astype(str).str.upper();de["adjusted_p_value"]=pd.to_numeric(de.adjusted_p_value,errors="coerce");de["log2FC"]=pd.to_numeric(de.log2FC,errors="coerce");de=de.sort_values("adjusted_p_value").drop_duplicates("gene_symbol");emap=de.set_index("gene_symbol");ids=de.set_index("gene_symbol").gene_id.astype(str).to_dict()
 counts=pd.read_csv(a.counts,index_col=0);counts.index=counts.index.astype(str);counts.columns=counts.columns.astype(str);groups=pd.Series([parse_sample(x) for x in counts.columns],index=counts.columns);groups=groups[groups.notna()];x=np.log2(counts[groups.index].div(counts[groups.index].sum(axis=0),axis=1)*1e6+1)
 colors={"Epiblast-aligned":EPI,"Lineage-aligned":LINEAGE,"Mixed":MIXED};all_rows=[]
 for module,genes in MODULES.items():
  rows=[]
  for gene in genes:
   if gene not in amap or gene not in ids or ids[gene] not in x.index or gene not in emap.index:continue
   v=x.loc[ids[gene]];r=emap.loc[gene];rows.append({"module":module,"gene_symbol":gene,"hypoxia_mean":v[groups.eq("Hypoxia")].mean(),"hypoxia_sd":v[groups.eq("Hypoxia")].std(ddof=1),"normoxia_mean":v[groups.eq("Normoxia")].mean(),"normoxia_sd":v[groups.eq("Normoxia")].std(ddof=1),"log2FC_normoxia_vs_hypoxia":r.log2FC,"adjusted_p_value":r.adjusted_p_value,"pooled_alignment":amap[gene]})
  t=pd.DataFrame(rows)
  if t.empty:continue
  all_rows.append(t);t.to_csv(src/f"oxygen_module_{safe(module)}.csv",index=False);z=t.iloc[::-1].reset_index(drop=True);y=np.arange(len(z));mx=np.nanmax(np.r_[z.hypoxia_mean+z.hypoxia_sd.fillna(0),z.normoxia_mean+z.normoxia_sd.fillna(0)])
  fig,ax=plt.subplots(figsize=(18,max(8,.85*len(z)+5)),layout="constrained");ax.barh(y-.17,z.hypoxia_mean,.34,xerr=z.hypoxia_sd,color=HYPOXIA,edgecolor="#A6A6A6",linewidth=1.2,error_kw=dict(ecolor="black",capsize=4));ax.barh(y+.17,z.normoxia_mean,.34,xerr=z.normoxia_sd,color=[colors.get(v,MIXED) for v in z.pooled_alignment],alpha=.76,edgecolor="#444444",linewidth=1.0,error_kw=dict(ecolor="black",capsize=4));ax.set_yticks(y);ax.set_yticklabels(z.gene_symbol,fontweight="bold");ax.set_xlabel("Mean log2 CPM +/- SD");ax.set_title(module+"\nNormoxia bars colored by pooled developmental alignment",pad=30);ax.set_xlim(0,mx*1.22)
  for i,r in z.iterrows():
   s=stars(r.adjusted_p_value)
   if s:ax.text(max(r.hypoxia_mean+(r.hypoxia_sd if np.isfinite(r.hypoxia_sd) else 0),r.normoxia_mean+(r.normoxia_sd if np.isfinite(r.normoxia_sd) else 0))+mx*.025,i,s,va="center",fontsize=22,fontweight="bold")
  ax.spines[["top","right"]].set_visible(False);save(fig,a.output_dir/"module_barplots"/safe(module))
 if all_rows:pd.concat(all_rows,ignore_index=True).to_csv(src/"oxygen_module_barplots_all_genes.csv",index=False)
 fig,ax=plt.subplots(figsize=(14,3.2));ax.axis("off");ax.legend([Patch(facecolor=HYPOXIA,edgecolor="#A6A6A6"),Patch(facecolor=EPI,alpha=.76),Patch(facecolor=LINEAGE,alpha=.76),Patch(facecolor=MIXED,alpha=.76)],["Hypoxia","Normoxia: Epiblast-aligned","Normoxia: lineage-aligned","Normoxia: mixed across lineages"],loc="center",ncol=2,frameon=False,prop={"size":21,"weight":"bold"});save(fig,a.output_dir/"legends"/"oxygen_module_bar_legend")
 manifest={"workflow":"cross_analysis_agitation_oxygen_1_1","timestamp_utc":datetime.now(timezone.utc).isoformat(),"scope":"Normoxia_vs_Hypoxia_pooled module barplots only","input_alignment":str(a.alignment),"control":"Hypoxia","experimental":"Normoxia","module_gene_policy":"Predefined oxygen-response modules restricted to genes present in pooled developmental-alignment results","output":"300 DPI PNG only"};(a.output_dir/"cross_analysis_agitation_oxygen_manifest_1_1.json").write_text(json.dumps(manifest,indent=2));print(f"[COMPLETE] oxygen module barplots written to {a.output_dir}")
if __name__=="__main__":main()
