#!/usr/bin/env python3
"""Publication-ready UMAPs for annotated Tyser E-MTAB-9388 cells.

Input:
  reference_data/Tyser_2021_PMID_34789876_log1p_cpm_annotated_1.h5ad

Output:
  cross_analysis/umap/*.png
  cross_analysis/umap/source_data/*.csv

The workflow recalculates latent space from log1p-CPM expression using:
- eligible, non-ambiguous cells only by default
- genes detected in at least 1% of retained cells
- top variable genes by variance
- gene-wise scaling
- PCA
- UMAP

No expression values or annotations in the input H5AD are modified.
"""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
import anndata as ad
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.lines import Line2D
from scipy import sparse
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import umap

PROJECT=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
INPUT=PROJECT/"reference_data"/"Tyser_2021_PMID_34789876_log1p_cpm_annotated_1.h5ad"
OUT=PROJECT/"cross_analysis"/"umap"
DPI=300;VERSION="1"
PALETTE={
 "Epiblast":"#1B9E77","PriS":"#D95F02","Mesoderm":"#7570B3",
 "AdvMes":"#E7298A","Axial Mes":"#66A61E","DE":"#E6AB02",
 "HEP":"#A6761D","Erythroblasts":"#E41A1C","Amnion":"#1F78B4",
 "ExE_Mes":"#6A3D9A","YSE":"#8C510A","Hypoblast":"#01665E",
 "Ambiguous":"#BDBDBD"
}
def args():
 p=argparse.ArgumentParser();p.add_argument("--input",type=Path,default=INPUT);p.add_argument("--output",type=Path,default=OUT);p.add_argument("--include-ineligible",action="store_true");p.add_argument("--min-detection-fraction",type=float,default=.01);p.add_argument("--n-variable-genes",type=int,default=3000);p.add_argument("--n-pcs",type=int,default=30);p.add_argument("--n-neighbors",type=int,default=20);p.add_argument("--min-dist",type=float,default=.35);p.add_argument("--seed",type=int,default=42);return p.parse_args()
def style():
 mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":26,"axes.titlesize":38,"axes.titleweight":"bold","axes.labelsize":30,"axes.labelweight":"bold","xtick.labelsize":22,"ytick.labelsize":22,"axes.linewidth":2.6,"savefig.dpi":DPI})
def save(fig,p):p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.2);plt.close(fig)
def as_bool(x):
 if pd.api.types.is_bool_dtype(x):return x.fillna(False).to_numpy(bool)
 return x.astype(str).str.lower().isin(["true","1","yes"]).to_numpy()
def scatter(emb,labels,title,path,palette,legend_name,out):
 fig,ax=plt.subplots(figsize=(15,12),layout="constrained")
 for label in sorted(pd.unique(labels)):
  m=np.asarray(labels==label);ax.scatter(emb[m,0],emb[m,1],s=30,c=palette.get(label,"#777777"),alpha=.72,edgecolors="none",rasterized=True)
 ax.set_title(title,pad=24);ax.set_xlabel("UMAP 1");ax.set_ylabel("UMAP 2");ax.set_xticks([]);ax.set_yticks([]);ax.spines[["top","right","bottom","left"]].set_visible(False);save(fig,path)
 handles=[Line2D([0],[0],marker="o",color="w",markerfacecolor=palette.get(x,"#777777"),markersize=13) for x in sorted(pd.unique(labels))]
 fig,ax=plt.subplots(figsize=(14,max(3,.55*len(handles))));ax.axis("off");ax.legend(handles,sorted(pd.unique(labels)),loc="center",frameon=False,ncol=3,prop={"size":22,"weight":"bold"});save(fig,out/"legends"/legend_name)
def main():
 a=args();style();a.output.mkdir(parents=True,exist_ok=True);(a.output/"source_data").mkdir(exist_ok=True)
 adata=ad.read_h5ad(a.input)
 req=["annotation_primary","annotation_display","developmental_context","analysis_eligible"]
 miss=[x for x in req if x not in adata.obs]
 if miss:raise ValueError(f"Missing obs columns: {miss}")
 keep=np.ones(adata.n_obs,dtype=bool) if a.include_ineligible else as_bool(adata.obs.analysis_eligible)
 x=adata.X[keep]
 obs=adata.obs.iloc[np.flatnonzero(keep)].copy()
 if sparse.issparse(x):detect=np.asarray((x>0).mean(axis=0)).ravel();var=np.asarray(x.power(2).mean(axis=0)).ravel()-np.asarray(x.mean(axis=0)).ravel()**2
 else:detect=(x>0).mean(0);var=np.var(x,axis=0)
 gene_keep=detect>=a.min_detection_fraction
 idx=np.flatnonzero(gene_keep);idx=idx[np.argsort(var[idx])[::-1][:min(a.n_variable_genes,len(idx))]]
 z=x[:,idx].toarray() if sparse.issparse(x) else np.asarray(x[:,idx]);z=StandardScaler().fit_transform(z)
 npcs=min(a.n_pcs,z.shape[0]-1,z.shape[1]);pcs=PCA(n_components=npcs,random_state=a.seed).fit_transform(z)
 emb=umap.UMAP(n_neighbors=min(a.n_neighbors,len(obs)-1),min_dist=a.min_dist,n_components=2,metric="cosine",random_state=a.seed).fit_transform(pcs)
 coords=obs[["annotation_primary","annotation_display","developmental_context","analysis_eligible"]].copy();coords.insert(0,"cell",obs.index.astype(str));coords["UMAP_1"]=emb[:,0];coords["UMAP_2"]=emb[:,1];coords.to_csv(a.output/"source_data"/f"Tyser_UMAP_coordinates_{VERSION}.csv",index=False)
 scatter(emb,obs.annotation_primary.astype(str).to_numpy(),"Human gastrulation reference by developmental annotation",a.output/"Tyser_annotation_primary",PALETTE,"annotation_primary",a.output)
 contexts=obs.developmental_context.astype(str).to_numpy();ctx_palette={x:mpl.colormaps["tab10"](i%10) for i,x in enumerate(sorted(pd.unique(contexts)))}
 scatter(emb,contexts,"Human gastrulation reference by developmental context",a.output/"Tyser_developmental_context",ctx_palette,"developmental_context",a.output)
 # Highlight Epiblast and Primitive streak against all other eligible states.
 hi=np.where(obs.annotation_primary.astype(str).eq("Epiblast"),"Epiblast",np.where(obs.annotation_primary.astype(str).eq("PriS"),"Primitive streak","Other eligible states"));hi_palette={"Epiblast":PALETTE["Epiblast"],"Primitive streak":PALETTE["PriS"],"Other eligible states":"#D9D9D9"}
 scatter(emb,hi,"Epiblast and primitive streak within the gastrulation reference",a.output/"Tyser_Epiblast_PriS_highlight",hi_palette,"Epiblast_PriS",a.output)
 pd.DataFrame({"gene_id":adata.var_names[idx].astype(str),"detection_fraction":detect[idx],"variance_log1p_cpm":var[idx]}).to_csv(a.output/"source_data"/f"Tyser_UMAP_variable_genes_{VERSION}.csv",index=False)
 manifest={"workflow":"cross_analysis_umap_1","input":str(a.input),"n_cells":int(len(obs)),"n_genes_used":int(len(idx)),"n_pcs":int(npcs),"n_neighbors":int(min(a.n_neighbors,len(obs)-1)),"min_dist":a.min_dist,"metric":"cosine","random_seed":a.seed,"eligible_cells_only":not a.include_ineligible,"output":"300 DPI PNG only"};(a.output/f"cross_analysis_umap_manifest_{VERSION}.json").write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
if __name__=="__main__":main()
