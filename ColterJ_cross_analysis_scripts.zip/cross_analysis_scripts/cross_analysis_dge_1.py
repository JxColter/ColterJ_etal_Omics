#!/usr/bin/env python3
"""Pairwise developmental-state differential expression for Tyser E-MTAB-9388.

Primary comparisons
-------------------
- Epiblast versus every other eligible pred_annotation state.
- PriS versus every other eligible pred_annotation state.

Input
-----
reference_data/Tyser_2021_PMID_34789876_log1p_cpm_annotated_1.h5ad

Output
------
cross_analysis/dge/<target>_vs_<reference>_moderate_DEGs.csv
cross_analysis/dge/all_tested/<target>_vs_<reference>_all_tested_genes.csv
cross_analysis/dge/cross_analysis_dge_summary_1.csv
cross_analysis/dge/cross_analysis_dge_manifest_1.json

Statistical scope
-----------------
The Tyser reference consists of cells from one embryo. Therefore these are
cell-level, reference-signature comparisons, not replicate-level population
inference. The script uses Wilcoxon rank-sum tests on log1p-CPM expression and
Benjamini-Hochberg adjusted P values. It does not treat cells as independent
embryo replicates or report these results as embryo-level differential
expression.

Moderate DEG definition
-----------------------
adjusted P < 0.05 and absolute log2 fold change > 0.2.
Positive log2FC means higher expression in the target state.
"""
from __future__ import annotations

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse, stats
from statsmodels.stats.multitest import multipletests

PROJECT = Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Transcriptomics")
INPUT_H5AD = PROJECT / "reference_data" / "Tyser_2021_PMID_34789876_log1p_cpm_annotated_1.h5ad"
OUTPUT_DIR = PROJECT / "cross_analysis" / "dge"
VERSION = "1"
TARGETS = ("Epiblast", "PriS")
PADJ_CUTOFF = 0.05
ABS_LOG2FC_CUTOFF = 0.2
MIN_CELLS = 3


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--input", type=Path, default=INPUT_H5AD)
    p.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    p.add_argument("--annotation-column", default="annotation_primary")
    p.add_argument("--eligibility-column", default="analysis_eligible")
    p.add_argument("--targets", nargs="+", default=list(TARGETS))
    p.add_argument("--min-cells", type=int, default=MIN_CELLS)
    p.add_argument("--padj", type=float, default=PADJ_CUTOFF)
    p.add_argument("--abs-log2fc", type=float, default=ABS_LOG2FC_CUTOFF)
    p.add_argument("--overwrite", action="store_true")
    return p.parse_args()


def safe(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", str(text)).strip("_")


def dense_rows(X, mask: np.ndarray) -> np.ndarray:
    part = X[mask]
    if sparse.issparse(part):
        part = part.toarray()
    return np.asarray(part, dtype=np.float64)


def bh_adjust(pvalues: np.ndarray) -> np.ndarray:
    out = np.full(len(pvalues), np.nan, dtype=float)
    finite = np.isfinite(pvalues)
    if finite.any():
        out[finite] = multipletests(pvalues[finite], method="fdr_bh")[1]
    return out


def compare(
    adata: ad.AnnData,
    annotation_column: str,
    target: str,
    reference: str,
    padj_cutoff: float,
    abs_log2fc_cutoff: float,
) -> pd.DataFrame:
    labels = adata.obs[annotation_column].astype(str).to_numpy()
    target_mask = labels == target
    reference_mask = labels == reference

    target_x = dense_rows(adata.X, target_mask)
    reference_x = dense_rows(adata.X, reference_mask)

    # adata.X is natural-log log1p(CPM). Convert group means back to CPM before
    # calculating an interpretable log2 fold change with a small CPM pseudocount.
    target_cpm_mean = np.expm1(target_x).mean(axis=0)
    reference_cpm_mean = np.expm1(reference_x).mean(axis=0)
    pseudocount = 1.0
    log2fc = np.log2((target_cpm_mean + pseudocount) / (reference_cpm_mean + pseudocount))

    mean_target_log1pcpm = target_x.mean(axis=0)
    mean_reference_log1pcpm = reference_x.mean(axis=0)
    fraction_target = (target_x > 0).mean(axis=0)
    fraction_reference = (reference_x > 0).mean(axis=0)

    pvalues = np.full(adata.n_vars, np.nan, dtype=float)
    statistics = np.full(adata.n_vars, np.nan, dtype=float)
    for idx in range(adata.n_vars):
        a = target_x[:, idx]
        b = reference_x[:, idx]
        if np.all(a == a[0]) and np.all(b == b[0]) and a[0] == b[0]:
            statistics[idx] = 0.0
            pvalues[idx] = 1.0
        else:
            result = stats.mannwhitneyu(a, b, alternative="two-sided", method="asymptotic")
            statistics[idx] = float(result.statistic)
            pvalues[idx] = float(result.pvalue)

    adjusted = bh_adjust(pvalues)
    result = pd.DataFrame({
        "gene_id": adata.var_names.astype(str),
        "target": target,
        "reference": reference,
        "n_target_cells": int(target_mask.sum()),
        "n_reference_cells": int(reference_mask.sum()),
        "mean_target_log1p_cpm": mean_target_log1pcpm,
        "mean_reference_log1p_cpm": mean_reference_log1pcpm,
        "mean_target_cpm": target_cpm_mean,
        "mean_reference_cpm": reference_cpm_mean,
        "fraction_target_detected": fraction_target,
        "fraction_reference_detected": fraction_reference,
        "log2FC": log2fc,
        "mann_whitney_u": statistics,
        "p_value": pvalues,
        "adjusted_p_value": adjusted,
    })
    result["direction"] = np.where(result.log2FC > 0, "Up", np.where(result.log2FC < 0, "Down", "No change"))
    result["moderate_deg"] = (
        result.adjusted_p_value.lt(padj_cutoff)
        & result.log2FC.abs().gt(abs_log2fc_cutoff)
    )
    result["plot_label"] = result.gene_id
    return result.sort_values(
        ["adjusted_p_value", "log2FC"], ascending=[True, False], na_position="last"
    ).reset_index(drop=True)


def main() -> int:
    a = parse_args()
    if not a.input.exists():
        raise FileNotFoundError(a.input)

    a.output_dir.mkdir(parents=True, exist_ok=True)
    all_tested_dir = a.output_dir / "all_tested"
    all_tested_dir.mkdir(parents=True, exist_ok=True)

    adata = ad.read_h5ad(a.input)
    for column in (a.annotation_column, a.eligibility_column):
        if column not in adata.obs.columns:
            raise ValueError(f"Missing required adata.obs column: {column}")

    eligible_raw = adata.obs[a.eligibility_column]
    if pd.api.types.is_bool_dtype(eligible_raw):
        eligible = eligible_raw.fillna(False).to_numpy(dtype=bool)
    else:
        eligible = eligible_raw.astype(str).str.lower().isin(["true", "1", "yes"]).to_numpy()
    work = adata[eligible].copy()
    work.obs[a.annotation_column] = work.obs[a.annotation_column].astype(str)

    counts = work.obs[a.annotation_column].value_counts().sort_index()
    counts.rename_axis("annotation_primary").rename("n_cells").reset_index().to_csv(
        a.output_dir / f"annotation_cell_counts_{VERSION}.csv", index=False
    )

    valid_states = sorted(counts[counts >= a.min_cells].index.tolist())
    targets = [target for target in a.targets if target in valid_states]
    missing_targets = sorted(set(a.targets) - set(targets))
    if missing_targets:
        raise ValueError(f"Requested targets absent or below min-cells threshold: {missing_targets}")

    existing_outputs = []
    for target in targets:
        for reference in valid_states:
            if reference == target:
                continue
            stem = f"{safe(target)}_vs_{safe(reference)}"
            for path in (
                a.output_dir / f"{stem}_moderate_DEGs.csv",
                all_tested_dir / f"{stem}_all_tested_genes.csv",
            ):
                if path.exists():
                    existing_outputs.append(path)
    if existing_outputs and not a.overwrite:
        preview = "\n".join(str(p) for p in existing_outputs[:10])
        raise FileExistsError(f"Outputs already exist. Use --overwrite.\n{preview}")

    summary_rows = []
    for target in targets:
        for reference in valid_states:
            if reference == target:
                continue
            stem = f"{safe(target)}_vs_{safe(reference)}"
            print(f"[DGE] {target} vs {reference}")
            result = compare(
                work,
                a.annotation_column,
                target,
                reference,
                a.padj,
                a.abs_log2fc,
            )
            moderate = result[result.moderate_deg].copy()
            result.to_csv(all_tested_dir / f"{stem}_all_tested_genes.csv", index=False)
            moderate.to_csv(a.output_dir / f"{stem}_moderate_DEGs.csv", index=False)
            summary_rows.append({
                "target": target,
                "reference": reference,
                "n_target_cells": int((work.obs[a.annotation_column] == target).sum()),
                "n_reference_cells": int((work.obs[a.annotation_column] == reference).sum()),
                "n_tested_genes": int(len(result)),
                "n_moderate_degs": int(len(moderate)),
                "n_up_in_target": int((moderate.log2FC > 0).sum()),
                "n_down_in_target": int((moderate.log2FC < 0).sum()),
                "moderate_deg_file": str(a.output_dir / f"{stem}_moderate_DEGs.csv"),
            })

    summary = pd.DataFrame(summary_rows)
    summary.to_csv(a.output_dir / f"cross_analysis_dge_summary_{VERSION}.csv", index=False)
    manifest = {
        "workflow": "cross_analysis_dge_1",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "input_h5ad": str(a.input),
        "output_dir": str(a.output_dir),
        "annotation_column": a.annotation_column,
        "eligibility_column": a.eligibility_column,
        "targets": targets,
        "reference_states": valid_states,
        "minimum_cells_per_state": a.min_cells,
        "test": "two-sided Mann-Whitney U on log1p-CPM values",
        "multiple_testing": "Benjamini-Hochberg within each pairwise contrast",
        "moderate_deg_definition": f"adjusted_p_value < {a.padj} and abs(log2FC) > {a.abs_log2fc}",
        "log2fc_definition": "log2((mean CPM target + 1)/(mean CPM reference + 1))",
        "interpretation_limit": "Single-embryo cell-level reference-signature comparison; not embryo-level replicated inference.",
        "n_comparisons": int(len(summary)),
    }
    (a.output_dir / f"cross_analysis_dge_manifest_{VERSION}.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    print(f"[COMPLETE] {len(summary)} comparisons written to {a.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
