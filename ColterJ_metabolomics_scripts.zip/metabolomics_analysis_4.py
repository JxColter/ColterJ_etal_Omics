#!/usr/bin/env python3
"""Exploratory metabolomics workflow v4.

Reclassifies n150m3d2 and n150m3d4 from nominal Normoxia to analysis Hypoxia,
while retaining the original label and an explicit audit flag. This is an
exploratory sensitivity analysis only. Outputs are written to analysis/4/.
"""
from __future__ import annotations
import argparse,json,math,re,warnings
from pathlib import Path
import numpy as np,pandas as pd
from scipy import stats,optimize,special
from scipy.cluster.hierarchy import linkage,leaves_list
from scipy.spatial.distance import pdist
from statsmodels.stats.multitest import multipletests
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
warnings.filterwarnings("ignore",category=RuntimeWarning)

VERSION="4"; DPI=300; FDR=.05; FC=float(np.log2(1.5))
BASE=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Metabolomics")
INPUT="CMRF_M20240112MKJC_Uca_JamesColter_BMA-RPIP-Semi_2024-01-18.csv"
RECLASSIFIED_SUBJECT="n150m3"
ANN={"label","metaGroupId","groupId","goodPeakCount","medMz","medRt","maxQuality","note","adductName","isotopeLabel","compound","compoundId","formula","expectedRtDiff","ppmDiff","parent"}
ALIASES={"L-ALANINE":"ALANINE","L-SERINE":"SERINE","L-PROLINE":"PROLINE","L-VALINE":"VALINE","L-LEUCINE":"LEUCINE","L-GLUTAMINE":"GLUTAMINE","L-GLUTAMATE":"GLUTAMATE","[R]-MALATE":"MALATE","PYROGLUTAMIC ACID":"5-OXO-PROLINE"}

def cli():
 p=argparse.ArgumentParser();p.add_argument("--base",type=Path,default=BASE);p.add_argument("--blank-fold",type=float,default=3);p.add_argument("--min-detection",type=float,default=.70);p.add_argument("--fdr",type=float,default=FDR);p.add_argument("--log2fc",type=float,default=FC);p.add_argument("--top-labels",type=int,default=10);p.add_argument("--top-heatmap",type=int,default=30);return p.parse_args()
def style():
 mpl.rcParams.update({"font.family":"Arial","font.weight":"bold","font.size":14,"axes.titlesize":18,"axes.titleweight":"bold","axes.titlepad":24,"axes.labelsize":16,"axes.labelweight":"bold","xtick.labelsize":12,"ytick.labelsize":12,"legend.fontsize":11,"axes.linewidth":1.4,"savefig.dpi":DPI,"savefig.bbox":"tight"});sns.set_style("ticks")
def save(fig,p):p.parent.mkdir(parents=True,exist_ok=True);fig.savefig(p.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.18);plt.close(fig)
def bh(x):
 x=np.asarray(x,float);o=np.full(x.shape,np.nan);k=np.isfinite(x)
 if k.any():o[k]=multipletests(x[k],method="fdr_bh")[1]
 return o
def canon(x):
 s=re.sub(r"\s+"," ",str(x).strip().upper().replace("_"," "));s=re.sub(r"-->.*$","",s).strip();return ALIASES.get(s,s)
def parse_sample(n):
 if n.lower().startswith("blank"):return dict(sample_id=n,sample_type="blank",include=False)
 if n.lower().startswith("stdr"):return dict(sample_id=n,sample_type="standard",include=False)
 if n.lower()=="c1":return dict(sample_id=n,sample_type="control",include=False)
 m=re.fullmatch(r"([hn])(100|120|150)m(\d+)d(2|4)",n,re.I)
 if not m:return dict(sample_id=n,sample_type="unmapped",include=False)
 o,r,rep,day=m.groups();subject=f"{o.lower()}{r}m{rep}";nominal={"h":"Hypoxia","n":"Normoxia"}[o.lower()];analysis="Hypoxia" if subject==RECLASSIFIED_SUBJECT else nominal
 return dict(sample_id=n,sample_type="biological",include=True,nominal_oxygen=nominal,oxygen=analysis,oxygen_reclassified=subject==RECLASSIFIED_SUBJECT,reclassification_reason="Exploratory oxygen-chamber sensitivity analysis" if subject==RECLASSIFIED_SUBJECT else "",rpm=int(r),replicate=int(rep),day=int(day),subject=subject,group=f"{analysis}_{r}RPM_D{day}")
def load(path):
 d=pd.read_csv(path,low_memory=False);d.columns=d.columns.astype(str).str.replace(r"\\_","_",regex=True).str.strip();d=d[d.compound.notna()].copy();d["metabolite"]=d.compound.map(canon);cols=[c for c in d.columns if c not in ANN and c!="metabolite"];return d,pd.DataFrame([parse_sample(c) for c in cols])
def preprocess(d,m,a):
 cols=m.sample_id.tolist();raw=d.set_index("metabolite")[cols].apply(pd.to_numeric,errors="coerce").groupby(level=0).median();blank=m.loc[m.sample_type.eq("blank"),"sample_id"].tolist();bio=m.loc[m.include.eq(True),"sample_id"].tolist();bmed=raw[blank].median(axis=1);corrected=raw.sub(bmed,axis=0).clip(lower=0);smed=raw[bio].median(axis=1);det=(corrected[bio]>0).mean(axis=1);keep=det.ge(a.min_detection)&(smed.ge(a.blank_fold*bmed)|bmed.le(0));x=corrected.loc[keep,bio];ref=x.replace(0,np.nan).median(axis=1);factor=x.div(ref,axis=0).median(axis=0).replace(0,np.nan);pqn=x.div(factor,axis=1);log2=np.log2(pqn.replace(0,np.nan));qc=pd.DataFrame({"metabolite":raw.index,"blank_median":bmed,"sample_median":smed,"detection_fraction":det,"retained":keep});return pqn,log2,qc
def subject_matrix(log2,m):
 b=m[m.include.eq(True)].copy();x=pd.DataFrame({s:log2[b.loc[b.subject.eq(s),"sample_id"]].mean(axis=1) for s in b.subject.unique()});mm=b.sort_values(["subject","day"]).drop_duplicates("subject").set_index("subject").reindex(x.columns).rename_axis("subject").reset_index();mm["sample_id"]=mm.subject;return x,mm
def squeeze(s2,df):
 s2=np.asarray(s2,float);df=np.asarray(df,float);k=np.isfinite(s2)&(s2>0)&np.isfinite(df)&(df>0)
 if k.sum()<10:return float(np.nanmedian(s2[k])),10.
 lv=np.log(s2[k]);lo,hi=np.quantile(lv,[.05,.95]);lv=np.clip(lv,lo,hi);z=lv-special.digamma(df[k]/2)+np.log(df[k]/2);target=max(float(np.var(z,ddof=1)-np.mean(special.polygamma(1,df[k]/2))),1e-8)
 try:d0=float(optimize.brentq(lambda d:special.polygamma(1,d/2)-target,1e-3,1e6))
 except ValueError:d0=1e6
 return float(np.exp(np.mean(z)+special.digamma(d0/2)-np.log(d0/2))),d0
def fit(matrix,meta,name,denmask,nummask,den,num,unit):
 aid=meta.loc[denmask,"sample_id"].tolist();bid=meta.loc[nummask,"sample_id"].tolist();rows=[]
 for met,r in matrix.iterrows():
  a=r.reindex(aid).dropna().to_numpy(float);b=r.reindex(bid).dropna().to_numpy(float)
  if len(a)<2 or len(b)<2:continue
  y=np.r_[a,b];X=np.column_stack([np.r_[np.ones(len(a)),np.zeros(len(b))],np.r_[np.zeros(len(a)),np.ones(len(b))]]);inv=np.linalg.pinv(X.T@X);beta=np.linalg.lstsq(X,y,rcond=None)[0];res=y-X@beta;df=len(y)-2
  if df>0:rows.append(dict(metabolite=met,contrast=name,denominator=den,numerator=num,log2FC=float(beta[1]-beta[0]),unscaled_se=float(np.sqrt(np.array([-1.,1.])@inv@np.array([-1.,1.]))),s2=float(res@res/df),df=df,denominator_n=len(a),numerator_n=len(b),unit=unit))
 return pd.DataFrame(rows)
def contrasts(log2,m):
 raw=m[m.include.eq(True)].copy();sx,sm=subject_matrix(log2,raw);tests=[fit(sx,sm,"Normoxia_vs_Hypoxia_pooled",sm.oxygen.eq("Hypoxia"),sm.oxygen.eq("Normoxia"),"Hypoxia","Normoxia","subject mean")]
 for lo,hi in [(100,120),(120,150),(100,150)]:tests.append(fit(sx,sm,f"{hi}_vs_{lo}_RPM_pooled",sm.rpm.eq(lo),sm.rpm.eq(hi),f"{lo} RPM",f"{hi} RPM","subject mean"))
 for day in [2,4]:tests.append(fit(log2,raw,f"Normoxia_vs_Hypoxia_D{day}",raw.oxygen.eq("Hypoxia")&raw.day.eq(day),raw.oxygen.eq("Normoxia")&raw.day.eq(day),"Hypoxia","Normoxia","sample"))
 for oxy in ["Hypoxia","Normoxia"]:
  for lo,hi in [(100,120),(120,150),(100,150)]:tests.append(fit(sx,sm,f"{oxy}_{hi}_vs_{lo}_RPM",sm.oxygen.eq(oxy)&sm.rpm.eq(lo),sm.oxygen.eq(oxy)&sm.rpm.eq(hi),f"{lo} RPM",f"{hi} RPM","subject mean"))
 z=pd.concat([q for q in tests if not q.empty],ignore_index=True);u=z.drop_duplicates(["contrast","metabolite"]);s0,d0=squeeze(u.s2,u.df);z["prior_variance"]=s0;z["prior_df"]=d0;z["moderated_variance"]=(d0*s0+z.df*z.s2)/(d0+z.df);z["moderated_df"]=d0+z.df;z["moderated_se"]=z.unscaled_se*np.sqrt(z.moderated_variance);z["moderated_t"]=z.log2FC/z.moderated_se;z["p_value"]=2*stats.t.sf(abs(z.moderated_t),z.moderated_df);z["adjusted_p_value"]=z.groupby("contrast").p_value.transform(bh);return z
def label_points(ax,z,n):
 chosen=pd.concat([z[z.log2FC.gt(0)].nsmallest(max(1,n//2),"adjusted_p_value"),z[z.log2FC.lt(0)].nsmallest(max(1,n//2),"adjusted_p_value")]).drop_duplicates("metabolite").head(n)
 try:
  from adjustText import adjust_text
  texts=[ax.text(r.log2FC,r.y,r.metabolite,fontsize=8,fontweight="bold",ha="center",va="center",bbox=dict(boxstyle="round,pad=.2",fc="white",ec="#444",lw=.7),clip_on=True) for _,r in chosen.iterrows()];adjust_text(texts,ax=ax,expand=(1.25,1.4),force_text=(.7,.9),force_points=(.4,.6),ensure_inside_axes=True)
 except ImportError:pass
def volcano(z,path,title,a):
 q=z.copy();q["y"]=-np.log10(q.adjusted_p_value.clip(lower=1e-300));q["sig"]=q.adjusted_p_value.lt(a.fdr)&q.log2FC.abs().ge(a.log2fc);fig=plt.figure(figsize=(7.75,5.2),layout="constrained");gs=fig.add_gridspec(1,2,width_ratios=[1,.22],wspace=.04);ax=fig.add_subplot(gs[0,0]);lax=fig.add_subplot(gs[0,1]);lax.axis("off");ax.scatter(q.loc[~q.sig,"log2FC"],q.loc[~q.sig,"y"],s=24,c="#888",alpha=.2,lw=0);up=ax.scatter(q.loc[q.sig&q.log2FC.gt(0),"log2FC"],q.loc[q.sig&q.log2FC.gt(0),"y"],s=40,c="#B2182B",alpha=.55,lw=0);down=ax.scatter(q.loc[q.sig&q.log2FC.lt(0),"log2FC"],q.loc[q.sig&q.log2FC.lt(0),"y"],s=40,c="#2166AC",alpha=.55,lw=0);ax.axhline(-np.log10(a.fdr),c="#222",ls="--",lw=1.4);ax.axvline(a.log2fc,c="#222",ls="--",lw=1.4);ax.axvline(-a.log2fc,c="#222",ls="--",lw=1.4);ax.margins(x=.12,y=.18);label_points(ax,q[q.sig].sort_values("adjusted_p_value"),a.top_labels) if q.sig.any() else None;ax.set_title(title);ax.set_xlabel("Log2FC");ax.set_ylabel("-Log10 adjusted P");sns.despine(ax=ax)
 if q.sig.any():lax.legend([up,down],["Higher","Lower"],loc="upper left",frameon=False)
 save(fig,path)
def row_z(x):return x.sub(x.mean(axis=1),axis=0).div(x.std(axis=1).replace(0,np.nan),axis=0)
def cluster(x):
 if len(x)<3:return x
 return x.iloc[leaves_list(linkage(pdist(x.fillna(0).values),method="average"))]
def heatmaps(log2,m,z,root,a):
 raw=m[m.include.eq(True)].copy();sx,sm=subject_matrix(log2,raw)
 for name,st in z.groupby("contrast"):
  r=st.iloc[0];matrix=sx if r.unit=="subject mean" else log2;meta=sm if r.unit=="subject mean" else raw;den=meta.loc[(meta.oxygen.eq(r.denominator))|(meta.rpm.astype(str).add(" RPM").eq(r.denominator)),"sample_id"].tolist();num=meta.loc[(meta.oxygen.eq(r.numerator))|(meta.rpm.astype(str).add(" RPM").eq(r.numerator)),"sample_id"].tolist()
  if "_D" in name and r.unit=="sample":day=int(re.search(r"_D(\d+)",name).group(1));idx=meta.set_index("sample_id");den=[x for x in den if int(idx.loc[x,"day"])==day];num=[x for x in num if int(idx.loc[x,"day"])==day]
  if not den or not num:continue
  mets=list(dict.fromkeys(st[st.adjusted_p_value.lt(a.fdr)].sort_values("adjusted_p_value").metabolite.tolist()+st.assign(t=st.moderated_t.abs()).sort_values("t",ascending=False).metabolite.tolist()))[:a.top_heatmap];means=cluster(row_z(pd.DataFrame({r.denominator:matrix.loc[mets,den].mean(axis=1),r.numerator:matrix.loc[mets,num].mean(axis=1)})));safe=re.sub(r"[^A-Za-z0-9_]+","_",name);out=root/safe;out.mkdir(parents=True,exist_ok=True);means.to_csv(out/"condition_mean_heatmap_matrix.csv");fig,ax=plt.subplots(figsize=(7.75,max(4,min(9,1.6+.23*len(means)))),layout="constrained");sns.heatmap(means,cmap="vlag",center=0,vmin=-1.5,vmax=1.5,annot=False,linewidths=.5,linecolor="white",cbar_kws={"label":"Row Z score","shrink":.72},ax=ax);ax.set_title(name.replace("_"," "));ax.set_xlabel("");ax.set_ylabel("");save(fig,out/"condition_mean_heatmap")
def main():
 a=cli();style();path=a.base/"data"/INPUT
 if not path.exists():raise FileNotFoundError(path)
 root=a.base/"analysis"/VERSION;tab=root/"tables";fig=root/"figures";tab.mkdir(parents=True,exist_ok=True);fig.mkdir(parents=True,exist_ok=True);d,m=load(path);m.to_csv(tab/"sample_metadata_with_exploratory_reclassification.csv",index=False);m[m.oxygen_reclassified.fillna(False)].to_csv(tab/"reclassified_samples.csv",index=False);pqn,log2,qc=preprocess(d,m,a);pqn.to_csv(tab/"pqn_normalized_abundance.csv");log2.to_csv(tab/"log2_pqn_abundance.csv");qc.to_csv(tab/"metabolite_qc.csv",index=False);z=contrasts(log2,m);z.to_csv(tab/"pooled_moderated_statistics.csv",index=False)
 for name,q in z.groupby("contrast"):volcano(q,fig/"pooled_volcano"/re.sub(r"[^A-Za-z0-9_]+","_",name),name.replace("_"," "),a)
 heatmaps(log2,m,z,fig/"pooled_heatmaps",a);(root/"run_summary.json").write_text(json.dumps({"version":"4","exploratory":True,"reclassified_subject":RECLASSIFIED_SUBJECT,"reclassified_samples":["n150m3d2","n150m3d4"],"nominal_condition":"Normoxia","analysis_condition":"Hypoxia","reason":"User-specified sensitivity analysis for possible oxygen-chamber issue"},indent=2));print(f"Exploratory metabolomics v4 complete: {root}")
if __name__=="__main__":main()
