#!/usr/bin/env python3
"""Colter et al. proteomics pathway and pluripotency workflow v2.9.5.

Standalone revision of v2.9.4.

Changes from v2.9.4
-------------------
- Pluripotency barplots retain a 7.75-inch width but increase from 2.65 to
  5.30 inches in height, doubling the height-to-width ratio.
- Full pluripotency panels remain present even when proteins are not identified.
- Missing proteins remain represented as zero differential abundance with
  hatched bars and identified_in_proteome=False in exported tables.
- Compact pathway heatmaps are retained unchanged.
"""
from __future__ import annotations
import argparse, json, re, warnings
from pathlib import Path
from typing import Iterable, Optional, Sequence
import numpy as np
import pandas as pd
from scipy import stats, optimize, special
from scipy.cluster.hierarchy import linkage, leaves_list
from scipy.spatial.distance import pdist
from statsmodels.stats.multitest import multipletests
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
warnings.filterwarnings("ignore", category=RuntimeWarning)

VERSION="2_9_5"
BASE=Path(r"C:\Users\jxcol\Documents\Professional\Projects\Colter et al Omics\Experimental\Proteomics")
DPI=300; SEED=20260918
RPM=[20,60,100]; PLATFORMS=["Well","Flask","Bioreactor"]
DESIGNS={"well_bioreactor":{"filename":"well_bioreactor_homosapien_proteinGroups.txt","heavy":"Bioreactor","light":"Well"},"well_flask":{"filename":"well_flask_homosapien_proteinGroups.txt","heavy":"Flask","light":"Well"},"bioreactor_flask":{"filename":"bioreactor_flask_homosapien_proteinGroups.txt","heavy":"Flask","light":"Bioreactor"}}
LIBS=["MSigDB_Hallmark_2020","Reactome_2022","GO_Biological_Process_2023"]
PC={"Well":np.array([1.,0.]),"Flask":np.array([0.,1.]),"Bioreactor":np.array([-1.,-1.])}
PLATFORM={"Well unique":1.5*PC["Well"],"Flask unique":1.5*PC["Flask"],"Bioreactor unique":1.5*PC["Bioreactor"],"Flask vs Well":PC["Flask"]-PC["Well"],"Bioreactor vs Well":PC["Bioreactor"]-PC["Well"],"Bioreactor vs Flask":PC["Bioreactor"]-PC["Flask"]}
DYNAMIC={"60 vs 20 RPM":np.array([-1.,1.,0.]),"100 vs 60 RPM":np.array([0.,-1.,1.]),"100 vs 20 RPM":np.array([-1.,0.,1.]),"20 RPM unique":np.array([1.,-.5,-.5]),"60 RPM unique":np.array([-.5,1.,-.5]),"100 RPM unique":np.array([-.5,-.5,1.])}
PLURIPOTENCY_PANEL=[("POU5F1","OCT4"),("SOX2","SOX2"),("NANOG","NANOG"),("LIN28A","LIN28A"),("LIN28B","LIN28B"),("SALL4","SALL4"),("UTF1","UTF1"),("DPPA4","DPPA4"),("OTX2","OTX2"),("ZIC2","ZIC2"),("DNMT3B","DNMT3B"),("FGF2","FGF2"),("FGFR1","FGFR1")]
PLATFORM_COLORS={"Well":"#6656A5","Flask":"#EC2B78","Bioreactor":"#00A6A6"};RPM_COLORS={20:"#ED1C24",60:"#70BF44",100:"#F7941D"}

def cli():
 p=argparse.ArgumentParser();p.add_argument("--base",type=Path,default=BASE);p.add_argument("--top-pathways",type=int,default=10);p.add_argument("--no-download",action="store_true");p.add_argument("--pathway-width",type=float,default=5.85);p.add_argument("--pathway-height",type=float,default=2.35);p.add_argument("--pluripotency-width",type=float,default=8.75);p.add_argument("--pluripotency-height",type=float,default=5.30);return p.parse_args()
def set_style():
 mpl.rcParams.update({
  "font.family":"Arial",
  "font.weight":"bold",
  "font.size":18,
  "axes.titlesize":24,
  "axes.titleweight":"bold",
  "axes.labelsize":20,
  "axes.labelweight":"bold",
  "xtick.labelsize":18,
  "ytick.labelsize":16,
  "legend.fontsize":16,
  "legend.title_fontsize":16,
  "axes.linewidth":2.0,
  "xtick.major.width":2.0,
  "ytick.major.width":2.0,
  "savefig.dpi":DPI,
  "savefig.bbox":"tight"
 })
 sns.set_style("ticks")

def bold(ax):
 for label in ax.get_xticklabels()+ax.get_yticklabels():label.set_fontweight("bold")
def save(fig,path):path.parent.mkdir(parents=True,exist_ok=True);fig.savefig(path.with_suffix(".png"),dpi=DPI,bbox_inches="tight",facecolor="white",pad_inches=.08);plt.close(fig)
def bh(x:Iterable[float]):
 a=np.asarray(list(x),float);o=np.full(a.shape,np.nan);k=np.isfinite(a)
 if k.any():o[k]=multipletests(a[k],method="fdr_bh")[1]
 return o
def gene(x)->Optional[str]:
 if pd.isna(x):return None
 s=str(x).strip();m=re.search(r"(?:^|\s)GN=([A-Za-z0-9_.-]+)",s);return m.group(1) if m else (re.split(r"[;,\s]+",s)[0] if s else None)
def gene_series(df):
 df.columns=df.columns.astype(str).str.strip()
 for c in ["Gene names","Gene Names","Gene names (primary)","Genes","Gene Symbol","Fasta headers","Protein names","Description"]:
  if c in df:
   g=df[c].apply(gene)
   if g.notna().any():return g
 raise ValueError("No gene annotation source")
def filter_mq(df):
 z=df.copy();z.columns=z.columns.astype(str).str.strip()
 for c in ["Reverse","Potential contaminant","Only identified by site"]:
  if c in z:z=z.loc[~z[c].astype(str).eq("+")].copy()
 return z
def numbered(cols:Sequence[str],patterns:Sequence[str]):
 d={}
 for c in cols:
  for p in patterns:
   m=re.match(p,str(c).strip(),re.I)
   if m:d[int(m.group(1))]=c;break
 return d
def ratio_matrix(df):
 r=numbered(df.columns,[r"^Ratio H/L normalized\s+(\d+)$",r"^Ratio H/L\s+(\d+)$"])
 if len(r)>=2:
  k=sorted(r);x=df[[r[i] for i in k]].apply(pd.to_numeric,errors="coerce").replace(0,np.nan);x.columns=[f"R{i}" for i in k];return np.log2(x)
 raise ValueError("Replicate normalized H/L ratios are required")
def squeeze(s2,df):
 s2=np.asarray(s2,float);df=np.asarray(df,float);ok=np.isfinite(s2)&(s2>0)&np.isfinite(df)&(df>0)
 if ok.sum()<20:return float(np.nanmedian(s2[ok])),10.
 lv=np.log(s2[ok]);lo,hi=np.quantile(lv,[.05,.95]);lv=np.clip(lv,lo,hi);z=lv-special.digamma(df[ok]/2)+np.log(df[ok]/2);target=max(float(np.var(z,ddof=1)-np.mean(special.polygamma(1,df[ok]/2))),1e-8)
 try:d0=float(optimize.brentq(lambda d:special.polygamma(1,d/2)-target,1e-3,1e6))
 except ValueError:d0=1e6
 return float(np.exp(np.mean(z)+special.digamma(d0/2)-np.log(d0/2))),d0
def moderate(base):
 src=base.drop_duplicates("gene_symbol");s0,d0=squeeze(src.s2,src.df);z=base.copy();z["s2_post"]=(d0*s0+z.df*z.s2)/(d0+z.df);z["df_post"]=d0+z.df;z["moderated_se"]=z.unscaled_se*np.sqrt(z.s2_post);z["t"]=z.log2FC/z.moderated_se;z["p_value"]=2*stats.t.sf(np.abs(z.t),z.df_post);z["adjusted_p_value"]=z.groupby("contrast").p_value.transform(bh);z["rank_score"]=z.t;return z

def platform_stats(data):
 frames=[]
 for _,d in DESIGNS.items():
  raw=filter_mq(pd.read_csv(data/d["filename"],sep="\t",low_memory=False));raw["gene_symbol"]=gene_series(raw);raw=raw[raw.gene_symbol.notna()].copy();x=ratio_matrix(raw);x["gene_symbol"]=raw.gene_symbol.values;x=x.groupby("gene_symbol").median(numeric_only=True).reset_index().melt(id_vars="gene_symbol",var_name="replicate",value_name="y").dropna();x["heavy"]=d["heavy"];x["light"]=d["light"];frames.append(x)
 long=pd.concat(frames,ignore_index=True);rows=[]
 for gn,q in long.groupby("gene_symbol"):
  y=q.y.to_numpy(float);X=np.vstack([PC[h]-PC[l] for h,l in zip(q.heavy,q.light)])
  if len(y)<4 or np.linalg.matrix_rank(X)<2:continue
  inv=np.linalg.pinv(X.T@X);b=np.linalg.lstsq(X,y,rcond=None)[0];res=y-X@b;df=len(y)-2
  if df<=0:continue
  s2=float(res@res/df)
  for name,c in PLATFORM.items():rows.append((gn,name,float(c@b),float(np.sqrt(max(c@inv@c,0))),s2,df))
 return moderate(pd.DataFrame(rows,columns=["gene_symbol","contrast","log2FC","unscaled_se","s2","df"]))
def dynamic_data(data):
 meta=pd.read_csv(data/"dynamic_summary.txt",sep="\t",dtype=str,keep_default_na=False);meta=meta[meta["Raw file"].str.startswith("S")].copy();meta["experiment"]=pd.to_numeric(meta.Experiment,errors="coerce");meta=meta[meta.experiment.notna()].copy();meta.experiment=meta.experiment.astype(int);vals=[]
 for n in meta["Raw file"]:
  m=re.search(r"_(Above|Within|Below)_(\d+)_",n,re.I);vals.append({"Below":20,"Within":60,"Above":100}[m.group(1).capitalize()])
 meta["rpm"]=vals;meta["sample_id"]=meta["Raw file"].str.replace(r"\\_","_",regex=True);meta=meta.sort_values("experiment");raw=filter_mq(pd.read_csv(data/"dynamic_culture_proteinGroups.txt",sep="\t",low_memory=False));raw["gene_symbol"]=gene_series(raw)
 for prefix in ["LFQ intensity","Intensity"]:
  mp={int(m.group(1)):c for c in raw.columns if (m:=re.match(rf"^{re.escape(prefix)}\s+(\d+)$",str(c),re.I))}
  if all(i in mp for i in meta.experiment):cols=[mp[i] for i in meta.experiment];break
 else:raise ValueError("Dynamic sample intensity columns were not found")
 x=np.log2(raw[cols].apply(pd.to_numeric,errors="coerce").replace(0,np.nan));x.columns=meta.sample_id.tolist();x["gene_symbol"]=raw.gene_symbol.values;x=x[x.gene_symbol.notna()].groupby("gene_symbol").median(numeric_only=True);return x,meta
def dynamic_stats(x,meta):
 rows=[]
 for gn,r in x.iterrows():
  y=r.to_numpy(float);ok=np.isfinite(y);rpm=meta.rpm.to_numpy()[ok];yy=y[ok]
  if len(yy)<6 or len(np.unique(rpm))<3:continue
  X=np.column_stack([(rpm==v).astype(float) for v in RPM]);inv=np.linalg.pinv(X.T@X);b=np.linalg.lstsq(X,yy,rcond=None)[0];res=yy-X@b;df=len(yy)-3
  if df<=0:continue
  s2=float(res@res/df)
  for name,c in DYNAMIC.items():rows.append((gn,name,float(c@b),float(np.sqrt(max(c@inv@c,0))),s2,df))
 return moderate(pd.DataFrame(rows,columns=["gene_symbol","contrast","log2FC","unscaled_se","s2","df"]))
def full_panel_table(stats_table,condition_map):
 rows=[]
 for symbol,display in PLURIPOTENCY_PANEL:
  for condition,contrast in condition_map.items():
   q=stats_table[(stats_table.gene_symbol.eq(symbol))&(stats_table.contrast.eq(contrast))];found=not q.empty;rows.append(dict(gene_symbol=symbol,display_name=display,condition=condition,relative_log2_abundance=float(q.log2FC.iloc[0]/1.5) if found else 0.,moderated_se=float(q.moderated_se.iloc[0]/1.5) if found else 0.,identified_in_proteome=found,p_value=float(q.p_value.iloc[0]) if found else np.nan,adjusted_p_value=float(q.adjusted_p_value.iloc[0]) if found else np.nan,source_contrast=contrast if found else "not identified; set to zero"))
 return pd.DataFrame(rows)
def pluripotency_barplot(table,condition_order,colors,title,ylabel,out,width,height):
 markers=[d for _,d in PLURIPOTENCY_PANEL];ncond=len(condition_order);gap=.70;bar_width=.22;centers=np.arange(len(markers))*(ncond*bar_width+gap);fig,ax=plt.subplots(figsize=(width,height),layout="constrained")
 for j,condition in enumerate(condition_order):
  q=table[table.condition.eq(condition)].set_index("display_name").reindex(markers);x=centers+(j-(ncond-1)/2)*bar_width;bars=ax.bar(x,q.relative_log2_abundance,width=bar_width*.92,color=colors[condition],label=str(condition),edgecolor="none",zorder=2);identified=q.identified_in_proteome.fillna(False).to_numpy(bool)
  for bar,found in zip(bars,identified):
   if not found:bar.set_facecolor("white");bar.set_edgecolor(colors[condition]);bar.set_linewidth(.8);bar.set_hatch("//")
  valid=identified & np.isfinite(q.moderated_se.to_numpy(float));ax.errorbar(x[valid],q.relative_log2_abundance.to_numpy(float)[valid],yerr=q.moderated_se.to_numpy(float)[valid],fmt="none",ecolor="black",elinewidth=1.8,capsize=4.8,capthick=1.8,zorder=3)
 ax.axhline(0,color="#333",lw=1.8);ax.set_xticks(centers);ax.set_xticklabels(markers,rotation=45,ha="right",fontsize=16,fontweight="bold");ax.set_title(title,pad=20,fontsize=22,fontweight="bold");ax.set_ylabel(ylabel,fontsize=20,fontweight="bold");ax.set_xlabel("");ax.tick_params(axis="y",labelsize=18,width=2.0);ax.legend(frameon=False,ncol=len(condition_order),loc="upper center",bbox_to_anchor=(.5,-.20),fontsize=16);sns.despine(ax=ax);save(fig,out)

def write_gmt(d,p):
 with p.open("w",encoding="utf-8") as h:
  for k,v in d.items():h.write("\t".join([k,"na"]+list(map(str,v)))+"\n")
def load_sets(ana,no_download):
 folder=ana/"gmt";folder.mkdir(parents=True,exist_ok=True);files=list(folder.glob("*.gmt"))
 if not files and not no_download:
  import gseapy as gp
  for lib in LIBS:p=folder/f"{lib}.gmt";write_gmt(gp.get_library(name=lib,organism="Human"),p);files.append(p)
 out={}
 for p in files:
  for line in p.read_text(encoding="utf-8").splitlines():q=line.split("\t");out[f"{p.stem}::{q[0]}"]=q[2:] if len(q)>=3 else []
 return out
def run_gsea(stats_table,names,sets):
 import gseapy as gp;tabs=[]
 for name in names:
  z=stats_table[stats_table.contrast.eq(name)][["gene_symbol","rank_score"]].dropna().drop_duplicates("gene_symbol").sort_values("rank_score",ascending=False)
  if len(z)<100:continue
  r=gp.prerank(rnk=z,gene_sets=sets,min_size=10,max_size=500,permutation_num=1000,seed=SEED,threads=4,outdir=None,verbose=False).res2d.reset_index(drop=True);r["contrast"]=name;tabs.append(r)
 out=pd.concat(tabs,ignore_index=True) if tabs else pd.DataFrame()
 if not out.empty:out["NES"]=pd.to_numeric(out["NES"],errors="coerce");out["FDR q-val"]=pd.to_numeric(out["FDR q-val"],errors="coerce")
 return out
def clean(x):return re.sub(r"\s+R-HSA-\d+$","",re.sub(r"\s*\(GO:\d+\)$","",re.sub(r"^[^:]+::","",str(x))))
def select_clustered(tab,contrasts,n):
 piv=tab.pivot_table(index="Term",columns="contrast",values="NES",aggfunc="first").reindex(columns=contrasts).fillna(0);fdr=tab.pivot_table(index="Term",columns="contrast",values="FDR q-val",aggfunc="first").reindex(columns=contrasts).fillna(1);eligible=fdr.min(axis=1)<.25;cand=piv.loc[eligible] if eligible.sum()>=n else piv;score=(cand.abs().max(axis=1)*(1+(-np.log10(fdr.loc[cand.index].min(axis=1).clip(lower=1e-6))))).sort_values(ascending=False);mat=piv.loc[score.head(n).index]
 if len(mat)>2:mat=mat.iloc[leaves_list(linkage(pdist(mat.values),method="average"))]
 return mat,fdr.loc[mat.index]
def fdr_symbol(v):return "***" if v<.001 else "**" if v<.01 else "*" if v<.05 else "." if v<.10 else ""
def pathway_heatmap(tab,contrasts,title,out,n,width,height):
 if tab.empty:return
 mat,fdr=select_clustered(tab,contrasts,n);mat=mat.reindex(columns=contrasts);fdr=fdr.reindex(index=mat.index,columns=contrasts);vmax=max(2.,float(np.nanmax(np.abs(mat.values))));fig,ax=plt.subplots(figsize=(width,height),layout="constrained");sns.heatmap(mat,cmap="vlag",center=0,vmin=-vmax,vmax=vmax,linewidths=.55,linecolor="white",cbar_kws={"label":"NES","shrink":.72,"pad":.015,"aspect":12},xticklabels=[c.replace(" unique","") for c in contrasts],yticklabels=[clean(x) for x in mat.index],ax=ax)
 for i,term in enumerate(mat.index):
  for j,c in enumerate(contrasts):
   q=float(fdr.loc[term,c]);sym=fdr_symbol(q);value=float(mat.loc[term,c])
   if sym:ax.text(j+.5,i+.5,sym,ha="center",va="center",fontsize=6,fontweight="bold",color="white" if abs(value)>=.55*vmax else "black")
   if q<.05:ax.add_patch(mpl.patches.Rectangle((j,i),1,1,fill=False,edgecolor="black",linewidth=.9))
 ax.set_title(title,pad=5,fontsize=9);ax.set_xlabel("");ax.set_ylabel("");ax.tick_params(axis="x",rotation=0,labelsize=7);ax.tick_params(axis="y",rotation=0,labelsize=6);bold(ax);cb=ax.collections[0].colorbar;cb.ax.tick_params(labelsize=6);cb.set_label("NES",fontsize=7,fontweight="bold");save(fig,out)
def relative_ssgsea(x,meta,sets,proc,out,n,width,height):
 import gseapy as gp
 z=x.loc[x.notna().sum(axis=1)>=6].apply(lambda r:r.fillna(r.median()),axis=1);ss=gp.ssgsea(data=z,gene_sets=sets,min_size=10,max_size=500,sample_norm_method="rank",outdir=None,threads=4,verbose=False).res2d.pivot(index="Term",columns="Name",values="NES");means=pd.DataFrame({str(r):ss[meta.loc[meta.rpm.eq(r),"sample_id"]].mean(axis=1) for r in RPM});rel=means.sub(means.mean(axis=1),axis=0);rel.to_csv(proc);mat=rel.loc[rel.var(axis=1).sort_values(ascending=False).head(n).index]
 if len(mat)>2:mat=mat.iloc[leaves_list(linkage(pdist(mat.values),method="average"))]
 fig,ax=plt.subplots(figsize=(width,height),layout="constrained");sns.heatmap(mat,cmap="vlag",center=0,cbar_kws={"label":"Relative score","shrink":.72,"pad":.015,"aspect":12},yticklabels=[clean(x) for x in mat.index],ax=ax);ax.set_title("Relative pathway activity",pad=5,fontsize=9);ax.set_xlabel("");ax.set_ylabel("");ax.tick_params(axis="x",rotation=0,labelsize=7);ax.tick_params(axis="y",labelsize=6);bold(ax);save(fig,out)
def main():
 a=cli();set_style();data=a.base/"data";proc=a.base/"processed"/VERSION;ana=a.base/"analysis"/VERSION
 for p in [proc/"pathways",proc/"statistics",proc/"pluripotency",ana/"pathways",ana/"pluripotency"]:p.mkdir(parents=True,exist_ok=True)
 pstats=platform_stats(data);x,meta=dynamic_data(data);dstats=dynamic_stats(x,meta);pstats.to_csv(proc/"statistics/platform_moderated_statistics.csv",index=False);dstats.to_csv(proc/"statistics/dynamic_moderated_statistics.csv",index=False);ppanel=full_panel_table(pstats,{"Well":"Well unique","Flask":"Flask unique","Bioreactor":"Bioreactor unique"});dpanel=full_panel_table(dstats,{20:"20 RPM unique",60:"60 RPM unique",100:"100 RPM unique"});ppanel.to_csv(proc/"pluripotency/platform_full_panel.csv",index=False);dpanel.to_csv(proc/"pluripotency/dynamic_full_panel.csv",index=False)
 pluripotency_barplot(ppanel,["Well","Flask","Bioreactor"],PLATFORM_COLORS,"Pluripotency-associated proteins across platforms","Relative log2 abundance",ana/"pluripotency/platform_full_panel",a.pluripotency_width,a.pluripotency_height);pluripotency_barplot(dpanel,[20,60,100],RPM_COLORS,"Pluripotency-associated proteins across agitation rates","Relative log2 abundance",ana/"pluripotency/dynamic_full_panel",a.pluripotency_width,a.pluripotency_height)
 sets=load_sets(ana/"pathways",a.no_download)
 if not sets:raise RuntimeError("No GMT gene sets available")
 groups={"platform_unique":(pstats,["Well unique","Flask unique","Bioreactor unique"],"Platform-unique pathways"),"platform_pairwise":(pstats,["Flask vs Well","Bioreactor vs Well","Bioreactor vs Flask"],"Platform pairwise pathways"),"dynamic_unique":(dstats,["20 RPM unique","60 RPM unique","100 RPM unique"],"RPM-unique pathways"),"dynamic_pairwise":(dstats,["60 vs 20 RPM","100 vs 60 RPM","100 vs 20 RPM"],"Dynamic pairwise pathways")};all_tabs=[]
 for key,(st,names,title) in groups.items():
  tab=run_gsea(st,names,sets);tab.to_csv(proc/f"pathways/{key}_GSEA_with_FDR.csv",index=False);pathway_heatmap(tab,names,title,ana/f"pathways/{key}_clustered_FDR_heatmap",a.top_pathways,a.pathway_width,a.pathway_height);all_tabs.append(tab.assign(analysis=key))
 pd.concat(all_tabs,ignore_index=True).to_csv(proc/"pathways/all_pathway_results_with_FDR.csv",index=False);relative_ssgsea(x,meta,sets,proc/"pathways/relative_pathway_score_20_60_100_RPM.csv",ana/"pathways/relative_pathway_score_20_60_100_RPM",a.top_pathways,a.pathway_width,a.pathway_height);summary={"version":"2.9.5","pluripotency_figure_size_inches":[a.pluripotency_width,a.pluripotency_height],"change_from_2_9_4":"Pluripotency typography, axes, error bars, and legend fonts doubled; compact pathway typography retained","pathway_figure_size_inches":[a.pathway_width,a.pathway_height],"missing_protein_behavior":"Retained at zero differential abundance with hatched bars"};(proc/"run_summary_2_9_5.json").write_text(json.dumps(summary,indent=2));print(f"Processed: {proc}\nFigures: {ana}")
if __name__=="__main__":main()
